/*     */ package xyz.apfelmus.cheeto.client.utils.skyblock;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.item.EntityArmorStand;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.scoreboard.Score;
/*     */ import net.minecraft.scoreboard.ScoreObjective;
/*     */ import net.minecraft.scoreboard.ScorePlayerTeam;
/*     */ import net.minecraft.scoreboard.Scoreboard;
/*     */ import net.minecraft.util.StringUtils;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class SkyblockUtils {
/*  21 */   private static Minecraft mc = Minecraft.func_71410_x();
/*  22 */   private static final ArrayList<Block> interactables = new ArrayList<>(Arrays.asList(new Block[] { Blocks.field_180410_as, Blocks.field_150467_bQ, (Block)Blocks.field_150461_bJ, Blocks.field_150324_C, Blocks.field_180412_aq, Blocks.field_150382_bo, Blocks.field_150483_bI, Blocks.field_150462_ai, (Block)Blocks.field_150486_ae, Blocks.field_180409_at, (Block)Blocks.field_150453_bW, (Block)Blocks.field_180402_cm, Blocks.field_150367_z, Blocks.field_150409_cd, Blocks.field_150381_bn, Blocks.field_150477_bB, Blocks.field_150460_al, (Block)Blocks.field_150438_bZ, Blocks.field_180411_ar, Blocks.field_150442_at, Blocks.field_150323_B, (Block)Blocks.field_150455_bV, (Block)Blocks.field_150441_bU, (Block)Blocks.field_150416_aS, (Block)Blocks.field_150413_aR, Blocks.field_150472_an, Blocks.field_150444_as, Blocks.field_150415_aT, Blocks.field_150447_bR, Blocks.field_150471_bO, Blocks.field_150430_aB, Blocks.field_180413_ao, (Block)Blocks.field_150465_bP }));
/*     */   
/*     */   public enum Location {
/*  25 */     ISLAND,
/*  26 */     HUB,
/*  27 */     LIFT,
/*  28 */     SKYBLOCK,
/*  29 */     LOBBY,
/*  30 */     LIMBO,
/*  31 */     NONE;
/*     */   }
/*     */   
/*     */   public static void ghostBlock() {
/*  35 */     if (mc.field_71476_x.func_178782_a() == null)
/*     */       return; 
/*  37 */     Block block = (Minecraft.func_71410_x()).field_71441_e.func_180495_p(mc.field_71476_x.func_178782_a()).func_177230_c();
/*  38 */     if (!interactables.contains(block)) {
/*  39 */       mc.field_71441_e.func_175698_g(mc.field_71476_x.func_178782_a());
/*     */     }
/*     */   }
/*     */   
/*     */   public static int getMobHp(EntityArmorStand aStand) {
/*  44 */     double mobHp = -1.0D;
/*  45 */     Pattern pattern = Pattern.compile(".+? ([.\\d]+)[Mk]?/[.\\d]+[Mk]?");
/*  46 */     String stripped = stripString(aStand.func_70005_c_());
/*  47 */     Matcher mat = pattern.matcher(stripped);
/*     */     
/*  49 */     if (mat.matches()) {
/*     */       try {
/*  51 */         mobHp = Double.parseDouble(mat.group(1));
/*  52 */       } catch (NumberFormatException numberFormatException) {}
/*     */     }
/*     */     
/*  55 */     return (int)Math.ceil(mobHp);
/*     */   }
/*     */   
/*     */   public static Entity getEntityCuttingOtherEntity(Entity e, Class<?> entityType) {
/*  59 */     List<Entity> possible = mc.field_71441_e.func_175674_a(e, e.func_174813_aQ().func_72314_b(0.3D, 2.0D, 0.3D), a -> (!a.field_70128_L && !a.equals(mc.field_71439_g) && !(a instanceof EntityArmorStand) && !(a instanceof net.minecraft.entity.projectile.EntityFireball) && !(a instanceof net.minecraft.entity.projectile.EntityFishHook) && (entityType == null || entityType.isInstance(a))));
/*  60 */     if (!possible.isEmpty()) {
/*  61 */       return Collections.<Entity>min(possible, Comparator.comparing(e2 -> Float.valueOf(e2.func_70032_d(e))));
/*     */     }
/*  63 */     return null;
/*     */   }
/*     */   
/*     */   public static Location getLocation() {
/*  67 */     if (isInIsland()) return Location.ISLAND;
/*     */     
/*  69 */     if (isInHub()) return Location.HUB;
/*     */     
/*  71 */     if (isAtLift()) return Location.LIFT;
/*     */     
/*  73 */     if (isInSkyblock()) return Location.SKYBLOCK;
/*     */     
/*  75 */     if (isInLobby()) return Location.LOBBY;
/*     */     
/*  77 */     IBlockState ibs = mc.field_71441_e.func_180495_p(mc.field_71439_g.func_180425_c().func_177977_b());
/*  78 */     if (ibs != null && 
/*  79 */       ibs.func_177230_c() == Blocks.field_150344_f) return Location.LIMBO;
/*     */ 
/*     */     
/*  82 */     return Location.NONE;
/*     */   }
/*     */   
/*     */   public static boolean isInIsland() {
/*  86 */     return hasLine("Your Island");
/*     */   }
/*     */   
/*     */   public static boolean isInHub() {
/*  90 */     return (hasLine("Village") && !hasLine("Dwarven"));
/*     */   }
/*     */   
/*     */   public static boolean isAtLift() {
/*  94 */     return hasLine("The Lift");
/*     */   }
/*     */   
/*     */   public static boolean isInDungeon() {
/*  98 */     return (hasLine("Dungeon Cleared:") || hasLine("Start"));
/*     */   }
/*     */   
/*     */   public static boolean isInFloor(String floor) {
/* 102 */     return hasLine("The Catacombs (" + floor + ")");
/*     */   }
/*     */   
/*     */   public static boolean isInSkyblock() {
/* 106 */     return hasLine("SKYBLOCK");
/*     */   }
/*     */   
/*     */   public static boolean isInLobby() {
/* 110 */     return (hasLine("HYPIXEL") || hasLine("PROTOTYPE"));
/*     */   }
/*     */   
/*     */   public static boolean hasLine(String sbString) {
/* 114 */     if (mc != null && mc.field_71439_g != null) {
/* 115 */       ScoreObjective sbo = mc.field_71441_e.func_96441_U().func_96539_a(1);
/* 116 */       if (sbo != null) {
/* 117 */         List<String> scoreboard = getSidebarLines();
/* 118 */         scoreboard.add(StringUtils.func_76338_a(sbo.func_96678_d()));
/* 119 */         for (String s : scoreboard) {
/* 120 */           String validated = stripString(s);
/*     */           
/* 122 */           if (validated.contains(sbString)) {
/* 123 */             return true;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 129 */     return false;
/*     */   }
/*     */   
/*     */   public static String stripString(String s) {
/* 133 */     char[] nonValidatedString = StringUtils.func_76338_a(s).toCharArray();
/* 134 */     StringBuilder validated = new StringBuilder();
/*     */     
/* 136 */     for (char a : nonValidatedString) {
/* 137 */       if (a < '' && a > '\024') {
/* 138 */         validated.append(a);
/*     */       }
/*     */     } 
/*     */     
/* 142 */     return validated.toString();
/*     */   }
/*     */   
/*     */   private static List<String> getSidebarLines() {
/* 146 */     List<String> lines = new ArrayList<>();
/* 147 */     Scoreboard scoreboard = (Minecraft.func_71410_x()).field_71441_e.func_96441_U();
/* 148 */     if (scoreboard == null) {
/* 149 */       return lines;
/*     */     }
/*     */     
/* 152 */     ScoreObjective objective = scoreboard.func_96539_a(1);
/*     */     
/* 154 */     if (objective == null) {
/* 155 */       return lines;
/*     */     }
/*     */     
/* 158 */     Collection<Score> scores = scoreboard.func_96534_i(objective);
/*     */     
/* 160 */     List<Score> list = new ArrayList<>();
/*     */     
/* 162 */     for (Score s : scores) {
/* 163 */       if (s != null && s.func_96653_e() != null && !s.func_96653_e().startsWith("#")) {
/* 164 */         list.add(s);
/*     */       }
/*     */     } 
/*     */     
/* 168 */     if (list.size() > 15) {
/* 169 */       scores = Lists.newArrayList(Iterables.skip(list, scores.size() - 15));
/*     */     } else {
/* 171 */       scores = list;
/*     */     } 
/*     */     
/* 174 */     for (Score score : scores) {
/* 175 */       ScorePlayerTeam team = scoreboard.func_96509_i(score.func_96653_e());
/* 176 */       lines.add(ScorePlayerTeam.func_96667_a((Team)team, score.func_96653_e()));
/*     */     } 
/*     */     
/* 179 */     return lines;
/*     */   }
/*     */   
/*     */   public static void silentUse(int mainSlot, int useSlot) {
/* 183 */     int oldSlot = mc.field_71439_g.field_71071_by.field_70461_c;
/*     */     
/* 185 */     if (useSlot > 0 && useSlot <= 9) {
/* 186 */       mc.field_71439_g.field_71071_by.field_70461_c = useSlot - 1;
/* 187 */       mc.field_71442_b.func_78769_a((EntityPlayer)mc.field_71439_g, (World)mc.field_71441_e, mc.field_71439_g.func_70694_bm());
/*     */     } 
/*     */     
/* 190 */     if (mainSlot > 0 && mainSlot <= 9) {
/* 191 */       mc.field_71439_g.field_71071_by.field_70461_c = mainSlot - 1;
/* 192 */     } else if (mainSlot == 0) {
/* 193 */       mc.field_71439_g.field_71071_by.field_70461_c = oldSlot;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\clien\\utils\skyblock\SkyblockUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */