/*     */ package xyz.apfelmus.cheeto.client.utils.render;
/*     */ 
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.Gui;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.WorldRenderer;
/*     */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ 
/*     */ public class Render2DUtils
/*     */ {
/*     */   public static void drawRectWH(int x, int y, int width, int height, int color) {
/*  14 */     drawRect(x, y, x + width, y + height, color);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void drawRect(int left, int top, int right, int bottom, int color) {
/*  19 */     if (left < right) {
/*  20 */       int j = left;
/*  21 */       left = right;
/*  22 */       right = j;
/*     */     } 
/*     */     
/*  25 */     if (top < bottom) {
/*  26 */       int j = top;
/*  27 */       top = bottom;
/*  28 */       bottom = j;
/*     */     } 
/*     */     
/*  31 */     float f3 = (color >> 24 & 0xFF) / 255.0F;
/*  32 */     float f = (color >> 16 & 0xFF) / 255.0F;
/*  33 */     float f1 = (color >> 8 & 0xFF) / 255.0F;
/*  34 */     float f2 = (color & 0xFF) / 255.0F;
/*  35 */     Tessellator tessellator = Tessellator.func_178181_a();
/*  36 */     WorldRenderer worldrenderer = tessellator.func_178180_c();
/*  37 */     GlStateManager.func_179147_l();
/*  38 */     GlStateManager.func_179090_x();
/*  39 */     GlStateManager.func_179120_a(770, 771, 1, 0);
/*  40 */     GlStateManager.func_179131_c(f, f1, f2, f3);
/*  41 */     worldrenderer.func_181668_a(7, DefaultVertexFormats.field_181705_e);
/*  42 */     worldrenderer.func_181662_b(left, bottom, 0.0D).func_181675_d();
/*  43 */     worldrenderer.func_181662_b(right, bottom, 0.0D).func_181675_d();
/*  44 */     worldrenderer.func_181662_b(right, top, 0.0D).func_181675_d();
/*  45 */     worldrenderer.func_181662_b(left, top, 0.0D).func_181675_d();
/*  46 */     tessellator.func_78381_a();
/*  47 */     GlStateManager.func_179098_w();
/*  48 */     GlStateManager.func_179084_k();
/*     */   }
/*     */   
/*     */   public static void drawLeftRoundedRect(float x, float y, float width, float height, float radius, int color) {
/*  52 */     width += x;
/*  53 */     x += radius;
/*  54 */     width -= radius;
/*  55 */     if (x < width) {
/*  56 */       float i = x;
/*  57 */       x = width;
/*  58 */       width = i;
/*     */     } 
/*  60 */     height += y;
/*  61 */     if (y < height) {
/*  62 */       float j = y;
/*  63 */       y = height;
/*  64 */       height = j;
/*     */     } 
/*  66 */     float f3 = (color >> 24 & 0xFF) / 255.0F;
/*  67 */     float f4 = (color >> 16 & 0xFF) / 255.0F;
/*  68 */     float f5 = (color >> 8 & 0xFF) / 255.0F;
/*  69 */     float f6 = (color & 0xFF) / 255.0F;
/*  70 */     Tessellator tessellator = Tessellator.func_178181_a();
/*  71 */     WorldRenderer worldrenderer = tessellator.func_178180_c();
/*  72 */     GlStateManager.func_179147_l();
/*  73 */     GlStateManager.func_179090_x();
/*  74 */     GlStateManager.func_179120_a(770, 771, 1, 0);
/*  75 */     GlStateManager.func_179131_c(f4, f5, f6, f3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  84 */     worldrenderer.func_181668_a(7, DefaultVertexFormats.field_181705_e);
/*  85 */     worldrenderer.func_181662_b((width - radius), (y - radius), 0.0D).func_181675_d();
/*  86 */     worldrenderer.func_181662_b(width, (y - radius), 0.0D).func_181675_d();
/*  87 */     worldrenderer.func_181662_b(width, (height + radius), 0.0D).func_181675_d();
/*  88 */     worldrenderer.func_181662_b((width - radius), (height + radius), 0.0D).func_181675_d();
/*  89 */     tessellator.func_78381_a();
/*  90 */     drawArc(width, height + radius, radius, 180);
/*  91 */     drawArc(width, y - radius, radius, 270);
/*  92 */     GlStateManager.func_179098_w();
/*  93 */     GlStateManager.func_179084_k();
/*     */   }
/*     */   
/*     */   public static void drawArc(float x, float y, float radius, int angleStart) {
/*  97 */     Tessellator tessellator = Tessellator.func_178181_a();
/*  98 */     WorldRenderer worldrenderer = tessellator.func_178180_c();
/*  99 */     worldrenderer.func_181668_a(6, DefaultVertexFormats.field_181705_e);
/* 100 */     GlStateManager.func_179137_b(x, y, 0.0D);
/* 101 */     worldrenderer.func_181662_b(0.0D, 0.0D, 0.0D).func_181675_d();
/* 102 */     int points = 21; double i;
/* 103 */     for (i = 0.0D; i < points; i++) {
/* 104 */       double radians = Math.toRadians(i / points * 90.0D + angleStart);
/* 105 */       worldrenderer.func_181662_b(radius * Math.sin(radians), radius * Math.cos(radians), 0.0D).func_181675_d();
/*     */     } 
/* 107 */     tessellator.func_78381_a();
/* 108 */     GlStateManager.func_179137_b(-x, -y, 0.0D);
/*     */   }
/*     */   
/*     */   public static void drawTexture(ResourceLocation resourceLocation, int x, int y, int width, int height, int textureWidth, int textureHeight, int textureX, int textureY) {
/* 112 */     Minecraft.func_71410_x().func_110434_K().func_110577_a(resourceLocation);
/* 113 */     GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/* 114 */     Gui.func_146110_a(x, y, textureX, textureY, width, height, textureWidth, textureHeight);
/*     */   }
/*     */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\clien\\utils\render\Render2DUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */