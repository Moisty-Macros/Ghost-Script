/*    */ package xyz.apfelmus.cheeto.client.utils.client;
/*    */ 
/*    */ import com.google.gson.Gson;
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonObject;
/*    */ import com.google.gson.JsonParser;
/*    */ import java.io.BufferedReader;
/*    */ import java.io.InputStreamReader;
/*    */ import java.net.URL;
/*    */ import java.net.URLConnection;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import xyz.apfelmus.cheeto.client.utils.fishing.FishingJson;
/*    */ import xyz.apfelmus.cheeto.client.utils.mining.MiningJson;
/*    */ 
/*    */ public class JsonUtils {
/* 17 */   private static Gson gson = new Gson();
/* 18 */   private static JsonParser parser = new JsonParser();
/*    */   
/*    */   public static MiningJson getMiningJson() {
/* 21 */     MiningJson mj = null;
/*    */     
/*    */     try {
/* 24 */       mj = (MiningJson)gson.fromJson(getContent("https://gist.githubusercontent.com/Apfelmus1337/db85f05991a60ef4f1a6059353120764/raw"), MiningJson.class);
/* 25 */     } catch (Exception e) {
/* 26 */       e.printStackTrace();
/*    */     } 
/*    */     
/* 29 */     return mj;
/*    */   }
/*    */   
/*    */   public static FishingJson getFishingJson() {
/* 33 */     FishingJson mj = null;
/*    */     
/*    */     try {
/* 36 */       mj = (FishingJson)gson.fromJson(getContent("https://gist.githubusercontent.com/Apfelmus1337/b4bbccd049846425cb89d76cc02eb29d/raw"), FishingJson.class);
/* 37 */     } catch (Exception e) {
/* 38 */       e.printStackTrace();
/*    */     } 
/*    */     
/* 41 */     return mj;
/*    */   }
/*    */   
/*    */   public static List<String> getListFromUrl(String url, String name) {
/* 45 */     List<String> ret = new ArrayList<>();
/*    */     
/*    */     try {
/* 48 */       JsonObject json = (JsonObject)parser.parse(getContent(url));
/* 49 */       json.getAsJsonArray(name).forEach(je -> ret.add(je.getAsString()));
/* 50 */     } catch (Exception e) {
/* 51 */       e.printStackTrace();
/*    */     } 
/*    */     
/* 54 */     return ret;
/*    */   }
/*    */   
/*    */   public static String getContent(String url) throws Exception {
/* 58 */     URL website = new URL(url);
/* 59 */     URLConnection connection = website.openConnection();
/* 60 */     BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
/* 61 */     StringBuilder response = new StringBuilder();
/*    */     
/*    */     String inputLine;
/* 64 */     while ((inputLine = in.readLine()) != null) {
/* 65 */       response.append(inputLine);
/*    */     }
/* 67 */     in.close();
/*    */     
/* 69 */     return response.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\clien\\utils\client\JsonUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */