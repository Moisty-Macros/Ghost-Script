/*    */ package xyz.apfelmus.cheeto.client.utils.client;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ 
/*    */ public class FontUtils
/*    */ {
/*  9 */   private static FontRenderer fr = (Minecraft.func_71410_x()).field_71466_p;
/*    */   
/*    */   public static void drawString(String text, int x, int y, int color) {
/* 12 */     fr.func_175065_a(text, x, y, color, true);
/*    */   }
/*    */   
/*    */   public static void drawVCenteredString(String text, int x, int y, int color) {
/* 16 */     fr.func_175065_a(text, x, (y - fr.field_78288_b / 2), color, true);
/*    */   }
/*    */   
/*    */   public static void drawHVCenteredString(String text, int x, int y, int color) {
/* 20 */     fr.func_175065_a(text, (x - fr.func_78256_a(text) / 2), (y - fr.field_78288_b / 2), color, true);
/*    */   }
/*    */   
/*    */   public static void drawHVCenteredChromaString(String text, int x, int y, int offset) {
/* 24 */     drawChromaString(text, x - fr.func_78256_a(text) / 2, y - fr.field_78288_b / 2, offset);
/*    */   }
/*    */   
/*    */   public static int getStringWidth(String text) {
/* 28 */     return fr.func_78256_a(text);
/*    */   }
/*    */   
/*    */   public static int getFontHeight() {
/* 32 */     return fr.field_78288_b;
/*    */   }
/*    */   
/*    */   public static void drawChromaString(String text, int x, int y, int offset) {
/* 36 */     double tmpX = x;
/* 37 */     for (char tc : text.toCharArray()) {
/* 38 */       long t = System.currentTimeMillis() - (int)tmpX * 10L - y - offset * 10L;
/* 39 */       int i = Color.HSBtoRGB((float)(t % 2000L) / 2000.0F, 0.88F, 0.88F);
/* 40 */       String tmp = String.valueOf(tc);
/* 41 */       fr.func_175065_a(tmp, (int)tmpX, y, i, true);
/* 42 */       tmpX += fr.func_78263_a(tc);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\clien\\utils\client\FontUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */