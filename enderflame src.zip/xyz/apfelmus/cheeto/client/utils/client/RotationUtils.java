/*     */ package xyz.apfelmus.cheeto.client.utils.client;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.util.Vec3;
/*     */ import org.lwjgl.util.vector.Vector3f;
/*     */ import xyz.apfelmus.cheeto.client.utils.math.RandomUtil;
/*     */ 
/*     */ public class RotationUtils {
/*  14 */   private static final Minecraft mc = Minecraft.func_71410_x();
/*     */   
/*     */   public static Rotation startRot;
/*     */   public static Rotation neededChange;
/*     */   public static Rotation endRot;
/*     */   public static long startTime;
/*     */   public static long endTime;
/*     */   public static boolean done = true;
/*  22 */   private static final float[][] BLOCK_SIDES = new float[][] { { 0.5F, 0.01F, 0.5F }, { 0.5F, 0.99F, 0.5F }, { 0.01F, 0.5F, 0.5F }, { 0.99F, 0.5F, 0.5F }, { 0.5F, 0.5F, 0.01F }, { 0.5F, 0.5F, 0.99F } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Rotation getRotation(Vec3 vec) {
/*  32 */     Vec3 eyes = mc.field_71439_g.func_174824_e(1.0F);
/*     */     
/*  34 */     return getRotation(eyes, vec);
/*     */   }
/*     */   
/*     */   public static Rotation getRotation(Vec3 from, Vec3 to) {
/*  38 */     double diffX = to.field_72450_a - from.field_72450_a;
/*  39 */     double diffY = to.field_72448_b - from.field_72448_b;
/*  40 */     double diffZ = to.field_72449_c - from.field_72449_c;
/*     */     
/*  42 */     return new Rotation(
/*  43 */         MathHelper.func_76142_g((float)(Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0D)), 
/*  44 */         (float)-Math.toDegrees(Math.atan2(diffY, Math.sqrt(diffX * diffX + diffZ * diffZ))));
/*     */   }
/*     */ 
/*     */   
/*     */   public static Rotation getRotation(BlockPos bp) {
/*  49 */     Vec3 vec = new Vec3(bp.func_177958_n() + 0.5D, bp.func_177956_o() + 0.5D, bp.func_177952_p() + 0.5D);
/*     */     
/*  51 */     return getRotation(vec);
/*     */   }
/*     */   
/*     */   public static void setup(Rotation rot, Long aimTime) {
/*  55 */     done = false;
/*  56 */     startRot = new Rotation(mc.field_71439_g.field_70177_z, mc.field_71439_g.field_70125_A);
/*  57 */     neededChange = getNeededChange(startRot, rot);
/*  58 */     endRot = new Rotation(startRot.getYaw() + neededChange.getYaw(), startRot.getPitch() + neededChange.getPitch());
/*  59 */     startTime = System.currentTimeMillis();
/*  60 */     endTime = System.currentTimeMillis() + aimTime.longValue();
/*     */   }
/*     */   
/*     */   public static void reset() {
/*  64 */     done = true;
/*  65 */     startRot = null;
/*  66 */     neededChange = null;
/*  67 */     endRot = null;
/*  68 */     startTime = 0L;
/*  69 */     endTime = 0L;
/*     */   }
/*     */   
/*     */   public static void update() {
/*  73 */     if (System.currentTimeMillis() <= endTime) {
/*  74 */       mc.field_71439_g.field_70177_z = interpolate(startRot.getYaw(), endRot.getYaw());
/*  75 */       mc.field_71439_g.field_70125_A = interpolate(startRot.getPitch(), endRot.getPitch());
/*     */     }
/*  77 */     else if (!done) {
/*  78 */       mc.field_71439_g.field_70177_z = endRot.getYaw();
/*  79 */       mc.field_71439_g.field_70125_A = endRot.getPitch();
/*  80 */       reset();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void snapAngles(Rotation rot) {
/*  86 */     mc.field_71439_g.field_70177_z = rot.getYaw();
/*  87 */     mc.field_71439_g.field_70125_A = rot.getPitch();
/*     */   }
/*     */   
/*     */   private static float interpolate(float start, float end) {
/*  91 */     float spentMillis = (float)(System.currentTimeMillis() - startTime);
/*  92 */     float relativeProgress = spentMillis / (float)(endTime - startTime);
/*  93 */     return (end - start) * easeOutCubic(relativeProgress) + start;
/*     */   }
/*     */   
/*     */   public static float easeOutCubic(double number) {
/*  97 */     return (float)(1.0D - Math.pow(1.0D - number, 3.0D));
/*     */   }
/*     */   
/*     */   public static Rotation getNeededChange(Rotation startRot, Rotation endRot) {
/* 101 */     float yawChng = MathHelper.func_76142_g(endRot.getYaw()) - MathHelper.func_76142_g(startRot.getYaw());
/*     */     
/* 103 */     if (yawChng <= -180.0F) {
/* 104 */       yawChng = 360.0F + yawChng;
/* 105 */     } else if (yawChng > 180.0F) {
/* 106 */       yawChng = -360.0F + yawChng;
/*     */     } 
/*     */     
/* 109 */     if (BloodCamp.godGamerMode.isEnabled()) {
/* 110 */       if (yawChng < 0.0F) {
/* 111 */         yawChng += 360.0F;
/*     */       } else {
/* 113 */         yawChng -= 360.0F;
/*     */       } 
/*     */     }
/*     */     
/* 117 */     return new Rotation(yawChng, endRot
/*     */         
/* 119 */         .getPitch() - startRot.getPitch());
/*     */   }
/*     */ 
/*     */   
/*     */   public static double fovFromEntity(Entity en) {
/* 124 */     return ((mc.field_71439_g.field_70177_z - fovToEntity(en)) % 360.0D + 540.0D) % 360.0D - 180.0D;
/*     */   }
/*     */   
/*     */   public static float fovToEntity(Entity ent) {
/* 128 */     double x = ent.field_70165_t - mc.field_71439_g.field_70165_t;
/* 129 */     double z = ent.field_70161_v - mc.field_71439_g.field_70161_v;
/* 130 */     double yaw = Math.atan2(x, z) * 57.2957795D;
/* 131 */     return (float)(yaw * -1.0D);
/*     */   }
/*     */   
/*     */   public static Rotation getNeededChange(Rotation endRot) {
/* 135 */     Rotation startRot = new Rotation(mc.field_71439_g.field_70177_z, mc.field_71439_g.field_70125_A);
/* 136 */     return getNeededChange(startRot, endRot);
/*     */   }
/*     */   
/*     */   public static List<Vec3> getBlockSides(BlockPos bp) {
/* 140 */     List<Vec3> ret = new ArrayList<>();
/*     */     
/* 142 */     for (float[] side : BLOCK_SIDES) {
/* 143 */       ret.add((new Vec3((Vec3i)bp)).func_72441_c(side[0], side[1], side[2]));
/*     */     }
/*     */     
/* 146 */     return ret;
/*     */   }
/*     */   
/*     */   public static boolean lookingAt(BlockPos blockPos, float range) {
/* 150 */     float stepSize = 0.15F;
/* 151 */     Vec3 position = new Vec3(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + mc.field_71439_g.func_70047_e(), mc.field_71439_g.field_70161_v);
/* 152 */     Vec3 look = mc.field_71439_g.func_70676_i(0.0F);
/* 153 */     Vector3f step = new Vector3f((float)look.field_72450_a, (float)look.field_72448_b, (float)look.field_72449_c);
/* 154 */     step.scale(stepSize / step.length());
/* 155 */     for (int i = 0; i < Math.floor((range / stepSize)) - 2.0D; i++) {
/* 156 */       BlockPos blockAtPos = new BlockPos(position.field_72450_a, position.field_72448_b, position.field_72449_c);
/* 157 */       if (blockAtPos.equals(blockPos))
/* 158 */         return true; 
/* 159 */       position = position.func_178787_e(new Vec3(step.x, step.y, step.z));
/*     */     } 
/* 161 */     return false;
/*     */   }
/*     */   
/*     */   public static Vec3 getVectorForRotation(float pitch, float yaw) {
/* 165 */     float f2 = -MathHelper.func_76134_b(-pitch * 0.017453292F);
/* 166 */     return new Vec3((MathHelper.func_76126_a(-yaw * 0.017453292F - 3.1415927F) * f2), MathHelper.func_76126_a(-pitch * 0.017453292F), (MathHelper.func_76134_b(-yaw * 0.017453292F - 3.1415927F) * f2));
/*     */   }
/*     */   
/*     */   public static Vec3 getLook(Vec3 vec) {
/* 170 */     double diffX = vec.field_72450_a - mc.field_71439_g.field_70165_t;
/* 171 */     double diffY = vec.field_72448_b - mc.field_71439_g.field_70163_u + mc.field_71439_g.func_70047_e();
/* 172 */     double diffZ = vec.field_72449_c - mc.field_71439_g.field_70161_v;
/* 173 */     double dist = MathHelper.func_76133_a(diffX * diffX + diffZ * diffZ);
/* 174 */     return getVectorForRotation((float)-(MathHelper.func_181159_b(diffY, dist) * 180.0D / Math.PI), (float)(MathHelper.func_181159_b(diffZ, diffX) * 180.0D / Math.PI - 90.0D));
/*     */   }
/*     */   
/*     */   public static EnumFacing calculateEnumfacing(Vec3 pos) {
/* 178 */     int x = MathHelper.func_76128_c(pos.field_72450_a);
/* 179 */     int y = MathHelper.func_76128_c(pos.field_72448_b);
/* 180 */     int z = MathHelper.func_76128_c(pos.field_72449_c);
/* 181 */     MovingObjectPosition position = calculateIntercept(new AxisAlignedBB(x, y, z, (x + 1), (y + 1), (z + 1)), pos, 50.0F);
/* 182 */     return (position != null) ? position.field_178784_b : null;
/*     */   }
/*     */   
/*     */   public static MovingObjectPosition calculateIntercept(AxisAlignedBB aabb, Vec3 block, float range) {
/* 186 */     Vec3 vec3 = mc.field_71439_g.func_174824_e(1.0F);
/* 187 */     Vec3 vec4 = getLook(block);
/* 188 */     return aabb.func_72327_a(vec3, vec3.func_72441_c(vec4.field_72450_a * range, vec4.field_72448_b * range, vec4.field_72449_c * range));
/*     */   }
/*     */   
/*     */   public static List<Vec3> getPointsOnBlock(BlockPos bp) {
/* 192 */     List<Vec3> ret = new ArrayList<>();
/*     */     
/* 194 */     for (float[] side : BLOCK_SIDES) {
/* 195 */       for (int i = 0; i < 20; i++) {
/* 196 */         float x = side[0];
/* 197 */         float y = side[1];
/* 198 */         float z = side[2];
/*     */         
/* 200 */         if (x == 0.5D) x = RandomUtil.randBetween(0.1F, 0.9F); 
/* 201 */         if (y == 0.5D) y = RandomUtil.randBetween(0.1F, 0.9F); 
/* 202 */         if (z == 0.5D) z = RandomUtil.randBetween(0.1F, 0.9F);
/*     */         
/* 204 */         ret.add((new Vec3((Vec3i)bp)).func_72441_c(x, y, z));
/*     */       } 
/*     */     } 
/*     */     
/* 208 */     return ret;
/*     */   }
/*     */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\clien\\utils\client\RotationUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */