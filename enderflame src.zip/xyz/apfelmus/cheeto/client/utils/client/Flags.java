/*   */ package xyz.apfelmus.cheeto.client.utils.client;
/*   */ 
/*   */ public class Flags {
/*   */   public static boolean silentUsing = false;
/*   */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\clien\\utils\client\Flags.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */