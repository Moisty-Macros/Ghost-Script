/*    */ package xyz.apfelmus.cheeto.client.utils.client;
/*    */ 
/*    */ import java.awt.Color;
/*    */ 
/*    */ public class ColorUtils {
/*  6 */   public static Color MENU_BG = new Color(22, 22, 22);
/*  7 */   public static Color TEXT_HOVERED = new Color(200, 200, 200);
/*  8 */   public static Color HUD_BG = new Color(0, 0, 0, 150);
/*  9 */   public static Color SELECT = new Color(132, 132, 132);
/* 10 */   public static Color LABEL = new Color(150, 150, 150);
/* 11 */   public static Color SUB_LABEL = new Color(100, 100, 100);
/* 12 */   public static Color SELECTED = new Color(55, 174, 160);
/* 13 */   public static Color M_BORDER = new Color(42, 42, 42);
/* 14 */   public static Color C_BORDER = new Color(55, 174, 160, 100);
/*    */   
/*    */   public static int getChroma(float speed, int offset) {
/* 17 */     return Color.HSBtoRGB((float)((System.currentTimeMillis() - offset * 10L) % (long)speed) / speed, 0.88F, 0.88F);
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\clien\\utils\client\ColorUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */