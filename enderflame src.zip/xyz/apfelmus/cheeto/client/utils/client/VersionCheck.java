/*    */ package xyz.apfelmus.cheeto.client.utils.client;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStreamReader;
/*    */ import java.net.HttpURLConnection;
/*    */ import java.net.URL;
/*    */ import java.util.List;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import org.apache.commons.codec.digest.DigestUtils;
/*    */ import xyz.apfelmus.cheeto.Cheeto;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VersionCheck
/*    */ {
/* 18 */   private static Minecraft mc = Minecraft.func_71410_x();
/*    */   public static boolean fuckNiggers = true;
/*    */   
/*    */   public static void check() {
/* 22 */     List<String> blacks = JsonUtils.getListFromUrl("https://gist.githubusercontent.com/Apfelmus1337/514d0bc111377f0a77ba9dac6b931057/raw", "uuids");
/* 23 */     if (!blacks.isEmpty() && !blacks.contains(DigestUtils.sha1Hex(mc.func_110432_I().func_148255_b()))) {
/* 24 */       fuckNiggers = false;
/*    */     }
/* 26 */     (new Thread(() -> {
/*    */           double version = getVersion(); String msg = (version == -1.0D) ? "There was an error during Update Check" : ((version > Cheeto.clientVersion) ? "There's a newer version of Cheeto available! Download it from the Discord if you haven't already!" : "Latest version, Cheeto on top"); while (true) {
/*    */             try {
/*    */               while (true) {
/*    */                 Thread.sleep(100L);
/*    */                 if (mc.field_71441_e != null) {
/*    */                   Thread.sleep(1000L);
/*    */                   ChatUtils.send(msg, new String[0]);
/*    */                   return;
/*    */                 } 
/*    */               } 
/* 37 */             } catch (InterruptedException e) {
/*    */               
/*    */               e.printStackTrace();
/*    */             }
/*    */           
/*    */           } 
/* 43 */         })).start();
/*    */   }
/*    */   
/*    */   private static double getVersion() {
/*    */     try {
/* 48 */       HttpURLConnection a = (HttpURLConnection)(new URL("http://apfelmus.xyz:6969/cheeto/version")).openConnection();
/* 49 */       a.setRequestProperty("User-Agent", "Cheeto/6.9");
/* 50 */       a.setRequestProperty("Content-Type", "application/json");
/* 51 */       a.setRequestMethod("GET");
/* 52 */       InputStreamReader i = new InputStreamReader(a.getInputStream());
/* 53 */       BufferedReader br = new BufferedReader(i);
/* 54 */       return Double.parseDouble(br.readLine());
/*    */     }
/* 56 */     catch (IOException e) {
/* 57 */       return -1.0D;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\clien\\utils\client\VersionCheck.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */