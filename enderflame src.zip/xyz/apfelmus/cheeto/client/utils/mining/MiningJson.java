package xyz.apfelmus.cheeto.client.utils.mining;

import java.util.List;

public class MiningJson {
  public List<Location> locations;
}


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\clien\\utils\mining\MiningJson.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */