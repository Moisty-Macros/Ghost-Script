/*    */ package xyz.apfelmus.cheeto.client.utils.fishing;
/*    */ 
/*    */ public class PathPoint
/*    */ {
/*    */   public double x;
/*    */   public double y;
/*    */   public double z;
/*    */   
/*    */   public String toString() {
/* 10 */     return this.x + "," + this.y + "," + this.z;
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\clien\\utils\fishing\PathPoint.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */