/*    */ package xyz.apfelmus.cheeto.client.utils.fishing;
/*    */ 
/*    */ import java.util.List;
/*    */ import xyz.apfelmus.cheeto.client.utils.client.Rotation;
/*    */ 
/*    */ 
/*    */ public class Location
/*    */ {
/*    */   public String name;
/*    */   public List<PathPoint> path;
/*    */   public Rotation rotation;
/*    */   
/*    */   public String toString() {
/* 14 */     return this.name;
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\clien\\utils\fishing\Location.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */