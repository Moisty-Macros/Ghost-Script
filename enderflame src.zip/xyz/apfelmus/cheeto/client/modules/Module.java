package xyz.apfelmus.cheeto.client.modules;

import xyz.apfelmus.cf4m.annotation.module.extend.Extend;

@Extend
public class Module {
  long activated;
}


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\modules\Module.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */