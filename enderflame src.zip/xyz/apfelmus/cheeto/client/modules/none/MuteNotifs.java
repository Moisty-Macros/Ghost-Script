package xyz.apfelmus.cheeto.client.modules.none;

import xyz.apfelmus.cf4m.annotation.module.Module;

@Module(name = "MuteNotifs")
public class MuteNotifs {}


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\modules\none\MuteNotifs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */