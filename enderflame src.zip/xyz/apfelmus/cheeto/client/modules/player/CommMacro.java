/*     */ package xyz.apfelmus.cheeto.client.modules.player;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.settings.KeyBinding;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.item.EntityArmorStand;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.StringUtils;
/*     */ import net.minecraft.world.World;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import xyz.apfelmus.cf4m.CF4M;
/*     */ import xyz.apfelmus.cf4m.annotation.Event;
/*     */ import xyz.apfelmus.cf4m.annotation.Setting;
/*     */ import xyz.apfelmus.cf4m.annotation.module.Disable;
/*     */ import xyz.apfelmus.cf4m.annotation.module.Module;
/*     */ import xyz.apfelmus.cheeto.client.events.ClientChatReceivedEvent;
/*     */ import xyz.apfelmus.cheeto.client.events.ClientTickEvent;
/*     */ import xyz.apfelmus.cheeto.client.events.Render3DEvent;
/*     */ import xyz.apfelmus.cheeto.client.settings.BooleanSetting;
/*     */ import xyz.apfelmus.cheeto.client.settings.IntegerSetting;
/*     */ import xyz.apfelmus.cheeto.client.utils.client.ChadUtils;
/*     */ import xyz.apfelmus.cheeto.client.utils.client.ChatUtils;
/*     */ import xyz.apfelmus.cheeto.client.utils.client.JsonUtils;
/*     */ import xyz.apfelmus.cheeto.client.utils.client.RotationUtils;
/*     */ import xyz.apfelmus.cheeto.client.utils.math.RandomUtil;
/*     */ import xyz.apfelmus.cheeto.client.utils.math.TimeHelper;
/*     */ import xyz.apfelmus.cheeto.client.utils.mining.Location;
/*     */ import xyz.apfelmus.cheeto.client.utils.mining.MiningJson;
/*     */ import xyz.apfelmus.cheeto.client.utils.mining.PathPoint;
/*     */ import xyz.apfelmus.cheeto.client.utils.skyblock.InventoryUtils;
/*     */ import xyz.apfelmus.cheeto.client.utils.skyblock.SkyblockUtils;
/*     */ 
/*     */ @Module(name = "CommMacro", category = Category.PLAYER)
/*     */ public class CommMacro {
/*     */   @Setting(name = "LookTime", description = "Set higher if low mana or bad ping")
/*  45 */   private IntegerSetting lookTime = new IntegerSetting(
/*  46 */       Integer.valueOf(500), Integer.valueOf(0), Integer.valueOf(2500)); @Setting(name = "WarpTime", description = "Set higher if low mana or bad ping")
/*  47 */   private IntegerSetting warpTime = new IntegerSetting(
/*  48 */       Integer.valueOf(250), Integer.valueOf(0), Integer.valueOf(1000)); @Setting(name = "MaxPlayerRange")
/*  49 */   private IntegerSetting maxPlayerRange = new IntegerSetting(
/*  50 */       Integer.valueOf(5), Integer.valueOf(0), Integer.valueOf(10)); @Setting(name = "PickSlot")
/*  51 */   private IntegerSetting pickSlot = new IntegerSetting(
/*  52 */       Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(8)); @Setting(name = "AotvSlot")
/*  53 */   private IntegerSetting aotvSlot = new IntegerSetting(
/*  54 */       Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(8)); @Setting(name = "PigeonSlot")
/*  55 */   private IntegerSetting pigeonSlot = new IntegerSetting(
/*  56 */       Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(8)); @Setting(name = "Ungrab", description = "Automatically tabs out")
/*  57 */   private BooleanSetting ungrab = new BooleanSetting(true);
/*     */ 
/*     */   
/*  60 */   private static Minecraft mc = Minecraft.func_71410_x();
/*     */   
/*  62 */   public static MiningJson miningJson = JsonUtils.getMiningJson();
/*  63 */   private static Quest currentQuest = null;
/*  64 */   private static Location currentLocation = null;
/*  65 */   private static List<PathPoint> path = null;
/*  66 */   private static TimeHelper pigeonTimer = new TimeHelper();
/*  67 */   private static TimeHelper warpTimer = new TimeHelper();
/*  68 */   private static TimeHelper recoverTimer = new TimeHelper();
/*  69 */   private static TimeHelper boostTimer = new TimeHelper();
/*     */   
/*  71 */   private static BlockPos oldPos = null;
/*     */   
/*     */   public static boolean hugeTits = false;
/*     */   public static boolean mithril = false;
/*  75 */   private static int oldDrillSlot = -1;
/*     */   
/*     */   private enum CommState {
/*  78 */     CLICK_PIGEON,
/*  79 */     IN_PIGEON,
/*  80 */     WARP_FORGE,
/*  81 */     NAVIGATE,
/*  82 */     COMMIT,
/*  83 */     COMMITTING;
/*     */   }
/*     */   
/*     */   private enum WarpState {
/*  87 */     SETUP,
/*  88 */     LOOK,
/*  89 */     WARP;
/*     */   }
/*     */   
/*     */   private enum RefuelState {
/*  93 */     CLICK_MERCHANT,
/*  94 */     CLICK_DRILL_IN,
/*  95 */     CLICK_FUEL_IN,
/*  96 */     REFUEL_DRILL,
/*  97 */     CLICK_DRILL_OUT,
/*  98 */     DONE_REFUELING;
/*     */   }
/*     */   
/* 101 */   private static CommState commState = CommState.CLICK_PIGEON;
/* 102 */   private static WarpState warpState = WarpState.SETUP;
/* 103 */   private static RefuelState refuelState = RefuelState.CLICK_MERCHANT;
/*     */   
/*     */   private enum Quest {
/* 106 */     MITHRIL_MINER("Mithril Miner"),
/* 107 */     TITANIUM_MINER("Titanium Miner"),
/* 108 */     UPPER_MINES_MITHRIL("Upper Mines Mithril"),
/* 109 */     ROYAL_MINES_MITHRIL("Royal Mines Mithril"),
/* 110 */     LAVA_SPRINGS_MITHRIL("Lava Springs Mithril"),
/* 111 */     CLIFFSIDE_VEINS_MITHRIL("Cliffside Veins Mithril"),
/* 112 */     RAMPARTS_QUARRY_MITHRIL("Rampart's Quarry Mithril"),
/* 113 */     UPPER_MINES_TITANIUM("Upper Mines Titanium"),
/* 114 */     ROYAL_MINES_TITANIUM("Royal Mines Titanium"),
/* 115 */     LAVA_SPRINGS_TITANIUM("Lava Springs Titanium"),
/* 116 */     CLIFFSIDE_VEINS_TITANIUM("Cliffside Veins Titanium"),
/* 117 */     RAMPARTS_QUARRY_TITANIUM("Rampart's Quarry Titanium"),
/* 118 */     GOBLIN_SLAYER("Goblin Slayer"),
/* 119 */     ICE_WALKER_SLAYER("Ice Walker Slayer");
/*     */     
/*     */     String questName;
/*     */     
/*     */     Quest(String questName) {
/* 124 */       this.questName = questName;
/*     */     }
/*     */   }
/*     */   
/*     */   @Enable
/*     */   public void onEnable() {
/* 130 */     pigeonTimer.reset();
/* 131 */     warpTimer.reset();
/* 132 */     recoverTimer.reset();
/* 133 */     boostTimer.reset();
/* 134 */     commState = CommState.CLICK_PIGEON;
/* 135 */     warpState = WarpState.SETUP;
/* 136 */     refuelState = RefuelState.CLICK_MERCHANT;
/*     */     
/* 138 */     if (miningJson == null) {
/* 139 */       ChatUtils.send("An error occured while getting Mining Locations, reloading...", new String[0]);
/* 140 */       miningJson = JsonUtils.getMiningJson();
/* 141 */       CF4M.INSTANCE.moduleManager.toggle(this);
/*     */       
/*     */       return;
/*     */     } 
/* 145 */     if (this.pickSlot.getCurrent().intValue() == 0 || this.aotvSlot.getCurrent().intValue() == 0 || this.pigeonSlot.getCurrent().intValue() == 0) {
/* 146 */       ChatUtils.send("Configure your fucking Item Slots retard", new String[0]);
/* 147 */       CF4M.INSTANCE.moduleManager.toggle(this);
/*     */     } 
/*     */     
/* 150 */     if (this.ungrab.isEnabled())
/* 151 */       ChadUtils.ungrabMouse(); 
/*     */   }
/*     */   
/*     */   @Disable
/*     */   public void onDisable() {
/* 156 */     hugeTits = false;
/* 157 */     mithril = false;
/* 158 */     KeyBinding.func_74506_a();
/* 159 */     if (CF4M.INSTANCE.moduleManager.isEnabled("AutoMithril"))
/* 160 */       CF4M.INSTANCE.moduleManager.toggle("AutoMithril"); 
/* 161 */     if (CF4M.INSTANCE.moduleManager.isEnabled("IceGoblinSlayer"))
/* 162 */       CF4M.INSTANCE.moduleManager.toggle("IceGoblinSlayer"); 
/* 163 */     if (this.ungrab.isEnabled())
/* 164 */       ChadUtils.regrabMouse(); 
/*     */   }
/*     */   
/*     */   @Event
/*     */   public void onTick(ClientTickEvent event) {
/* 169 */     if (mc.field_71462_r instanceof net.minecraft.client.gui.inventory.GuiChest && 
/* 170 */       currentLocation != null && currentLocation.name.equals("REFUEL") && "Drill Anvil".equals(InventoryUtils.getInventoryName())) {
/* 171 */       ItemStack aboveDrill; ItemStack hopper; ItemStack oldDrill; switch (refuelState) {
/*     */         case MITHRIL_MINER:
/* 173 */           oldDrillSlot = InventoryUtils.getSlotForItem("Drill", Items.field_179562_cC);
/* 174 */           mc.field_71442_b.func_78753_a(mc.field_71439_g.field_71070_bA.field_75152_c, oldDrillSlot, 0, 1, (EntityPlayer)mc.field_71439_g);
/* 175 */           refuelState = RefuelState.CLICK_FUEL_IN;
/*     */           break;
/*     */         
/*     */         case TITANIUM_MINER:
/* 179 */           aboveDrill = InventoryUtils.getStackInOpenContainerSlot(20);
/* 180 */           if (aboveDrill != null && aboveDrill.func_77952_i() == 5) {
/* 181 */             int fuelSlot = InventoryUtils.getSlotForItem("Volta", Items.field_151144_bL);
/* 182 */             if (fuelSlot == -1) {
/* 183 */               fuelSlot = InventoryUtils.getSlotForItem("Oil Barrel", Items.field_151144_bL);
/*     */             }
/* 185 */             if (fuelSlot == -1) {
/* 186 */               ChatUtils.send("Bozo you don't have any fuel", new String[0]);
/* 187 */               CF4M.INSTANCE.moduleManager.toggle(this);
/* 188 */               mc.field_71439_g.func_71053_j();
/*     */               break;
/*     */             } 
/* 191 */             mc.field_71442_b.func_78753_a(mc.field_71439_g.field_71070_bA.field_75152_c, fuelSlot, 0, 1, (EntityPlayer)mc.field_71439_g);
/* 192 */             refuelState = RefuelState.REFUEL_DRILL;
/*     */           } 
/*     */           break;
/*     */         
/*     */         case null:
/* 197 */           hopper = InventoryUtils.getStackInOpenContainerSlot(22);
/* 198 */           if (hopper != null && hopper.func_77948_v()) {
/* 199 */             mc.field_71442_b.func_78753_a(mc.field_71439_g.field_71070_bA.field_75152_c, 22, 0, 0, (EntityPlayer)mc.field_71439_g);
/* 200 */             refuelState = RefuelState.CLICK_DRILL_OUT;
/*     */           } 
/*     */           break;
/*     */ 
/*     */         
/*     */         case null:
/* 206 */           oldDrill = InventoryUtils.getStackInOpenContainerSlot(29);
/*     */           
/* 208 */           if (oldDrill == null) {
/* 209 */             mc.field_71442_b.func_78753_a(mc.field_71439_g.field_71070_bA.field_75152_c, 13, 0, 1, (EntityPlayer)mc.field_71439_g);
/* 210 */             refuelState = RefuelState.DONE_REFUELING;
/*     */           } 
/*     */           break;
/*     */         
/*     */         case null:
/* 215 */           mc.field_71439_g.func_71053_j();
/* 216 */           commState = CommState.CLICK_PIGEON;
/* 217 */           refuelState = RefuelState.CLICK_MERCHANT;
/* 218 */           recoverTimer.reset();
/*     */           break;
/*     */       } 
/*     */ 
/*     */     
/*     */     } 
/* 224 */     if (recoverTimer.hasReached(5000L)) {
/* 225 */       boolean warpOut; int rongo; SkyblockUtils.Location curLoc = SkyblockUtils.getLocation();
/*     */ 
/*     */       
/* 228 */       switch (curLoc) {
/*     */         case MITHRIL_MINER:
/* 230 */           switch (commState) {
/*     */             case MITHRIL_MINER:
/* 232 */               if (pigeonTimer.hasReached(5000L)) {
/* 233 */                 SkyblockUtils.silentUse(0, this.pigeonSlot.getCurrent().intValue());
/* 234 */                 commState = CommState.IN_PIGEON;
/* 235 */                 pigeonTimer.reset();
/*     */               } 
/*     */               break;
/*     */             
/*     */             case TITANIUM_MINER:
/* 240 */               if (pigeonTimer.hasReached(1000L) && mc.field_71462_r instanceof net.minecraft.client.gui.inventory.GuiChest) {
/* 241 */                 int complSlot = getCompletedSlot();
/* 242 */                 if (complSlot != -1) {
/* 243 */                   InventoryUtils.clickOpenContainerSlot(complSlot);
/* 244 */                   pigeonTimer.reset();
/*     */                   return;
/*     */                 } 
/* 247 */                 List<Integer> questSlots = getQuestSlots();
/* 248 */                 if (questSlots.isEmpty())
/*     */                   return; 
/* 250 */                 for (Iterator<Integer> iterator = questSlots.iterator(); iterator.hasNext(); ) { int i = ((Integer)iterator.next()).intValue();
/* 251 */                   ItemStack is = InventoryUtils.getStackInOpenContainerSlot(i);
/* 252 */                   List<String> itemLore = getLore(is);
/* 253 */                   if (itemLore.size() > 4) {
/* 254 */                     String lore = itemLore.get(4);
/* 255 */                     currentQuest = getQuest(lore);
/* 256 */                     if (currentQuest == null) {
/*     */                       continue;
/*     */                     }
/* 259 */                     currentLocation = getLocation(currentQuest);
/* 260 */                     if (currentLocation == null)
/*     */                       continue; 
/*     */                     break;
/*     */                   }  }
/*     */                 
/* 265 */                 mc.field_71439_g.func_71053_j();
/* 266 */                 commState = CommState.WARP_FORGE; break;
/* 267 */               }  if (pigeonTimer.hasReached(1000L)) {
/* 268 */                 commState = CommState.CLICK_PIGEON;
/*     */               }
/*     */               break;
/*     */             
/*     */             case null:
/* 273 */               if (currentLocation == null) {
/* 274 */                 ChatUtils.send("Couldn't determine Commission", new String[0]);
/* 275 */                 pigeonTimer.reset();
/* 276 */                 commState = CommState.CLICK_PIGEON;
/*     */                 
/*     */                 break;
/*     */               } 
/* 280 */               ChatUtils.send("Navigating to: " + currentLocation.name, new String[0]);
/* 281 */               mc.field_71439_g.func_71165_d("/warp forge");
/* 282 */               path = null;
/* 283 */               commState = CommState.NAVIGATE;
/*     */               break;
/*     */             
/*     */             case null:
/* 287 */               if (mc.field_71439_g.func_180425_c().equals(new BlockPos(1, 149, -68)) && path == null) {
/* 288 */                 path = new ArrayList<>(currentLocation.path);
/* 289 */                 warpTimer.reset();
/* 290 */                 oldPos = null;
/* 291 */                 KeyBinding.func_74510_a(mc.field_71474_y.field_74311_E.func_151463_i(), true);
/* 292 */                 warpState = WarpState.SETUP;
/*     */               } 
/*     */               break;
/*     */             
/*     */             case null:
/* 297 */               if (currentQuest == Quest.GOBLIN_SLAYER || currentQuest == Quest.ICE_WALKER_SLAYER) {
/* 298 */                 CF4M.INSTANCE.moduleManager.toggle("IceGoblinSlayer");
/* 299 */                 commState = CommState.COMMITTING; break;
/* 300 */               }  if (currentLocation != null && currentLocation.name.equals("REFUEL") && refuelState == RefuelState.CLICK_MERCHANT) {
/* 301 */                 List<Entity> possible = mc.field_71441_e.func_175674_a((Entity)mc.field_71439_g, mc.field_71439_g.func_174813_aQ().func_72314_b(5.0D, 3.0D, 5.0D), a -> a.func_70005_c_().contains("Jotraeline Greatforge"));
/* 302 */                 if (!possible.isEmpty()) {
/* 303 */                   mc.field_71442_b.func_78768_b((EntityPlayer)mc.field_71439_g, possible.get(0));
/* 304 */                   refuelState = RefuelState.CLICK_DRILL_IN;
/*     */                 }  break;
/*     */               } 
/* 307 */               if (this.pickSlot.getCurrent().intValue() > 0 && this.pickSlot.getCurrent().intValue() <= 8) {
/* 308 */                 mc.field_71439_g.field_71071_by.field_70461_c = this.pickSlot.getCurrent().intValue() - 1;
/*     */               }
/* 310 */               hugeTits = currentQuest.questName.contains("Titanium");
/* 311 */               mithril = currentQuest.questName.contains("Mithril");
/* 312 */               CF4M.INSTANCE.moduleManager.toggle("AutoMithril");
/* 313 */               commState = CommState.COMMITTING;
/*     */               break;
/*     */ 
/*     */             
/*     */             case null:
/* 318 */               warpOut = false;
/* 319 */               rongo = this.maxPlayerRange.getCurrent().intValue();
/*     */               
/* 321 */               if (currentQuest != Quest.GOBLIN_SLAYER && currentQuest != Quest.ICE_WALKER_SLAYER) {
/* 322 */                 if (boostTimer.hasReached(125000L)) {
/* 323 */                   mc.field_71442_b.func_78769_a((EntityPlayer)mc.field_71439_g, (World)mc.field_71441_e, mc.field_71439_g.func_70694_bm());
/* 324 */                   boostTimer.reset();
/*     */                 } 
/*     */                 
/* 327 */                 if (rongo == 0)
/*     */                   break; 
/* 329 */                 String warpName = "";
/* 330 */                 for (Entity e : mc.field_71441_e.func_175674_a((Entity)mc.field_71439_g, mc.field_71439_g.func_174813_aQ().func_72314_b(rongo, (rongo >> 1), rongo), a -> (a instanceof net.minecraft.client.entity.EntityOtherPlayerMP || a instanceof EntityArmorStand))) {
/* 331 */                   if (e instanceof EntityArmorStand) {
/* 332 */                     ItemStack bushSlot = ((EntityArmorStand)e).func_71124_b(4);
/* 333 */                     if (bushSlot != null && Item.func_150898_a((Block)Blocks.field_150330_I) == bushSlot.func_77973_b()) {
/* 334 */                       warpOut = true;
/* 335 */                       warpName = "Dead Bush"; break;
/*     */                     }  continue;
/*     */                   } 
/* 338 */                   if (!(e instanceof net.minecraft.client.entity.EntityOtherPlayerMP) || 
/* 339 */                     e.func_70005_c_().equals("Goblin ") || e.func_70005_c_().contains("Treasuer Hunter") || e.func_70005_c_().contains("Crystal Sentry"))
/* 340 */                     continue;  String formatted = e.func_145748_c_().func_150254_d();
/* 341 */                   if (StringUtils.func_76338_a(formatted).equals(formatted)) {
/*     */                     continue;
/*     */                   }
/* 344 */                   if (formatted.startsWith("§r") && !formatted.startsWith("§r§")) {
/*     */                     continue;
/*     */                   }
/* 347 */                   warpOut = true;
/* 348 */                   warpName = e.func_70005_c_();
/*     */                 } 
/*     */                 
/* 351 */                 if (warpOut) {
/* 352 */                   ChatUtils.send("Switching lobbies cause a nice person is near you: " + warpName, new String[0]);
/* 353 */                   mc.field_71439_g.func_71165_d("/warp home");
/* 354 */                   if (CF4M.INSTANCE.moduleManager.isEnabled("AutoMithril"))
/* 355 */                     CF4M.INSTANCE.moduleManager.toggle("AutoMithril"); 
/* 356 */                   if (CF4M.INSTANCE.moduleManager.isEnabled("IceGoblinSlayer"))
/* 357 */                     CF4M.INSTANCE.moduleManager.toggle("IceGoblinSlayer"); 
/* 358 */                   KeyBinding.func_74506_a();
/* 359 */                   recoverTimer.reset();
/* 360 */                   commState = CommState.CLICK_PIGEON;
/*     */                 } 
/*     */               } 
/*     */               break;
/*     */           } 
/*     */           
/*     */           break;
/*     */         case TITANIUM_MINER:
/* 368 */           ChatUtils.send("Detected player in Island, re-warping", new String[0]);
/* 369 */           mc.field_71439_g.func_71165_d("/warp forge");
/*     */           break;
/*     */         
/*     */         case null:
/* 373 */           ChatUtils.send("Detected player in Hub, re-warping", new String[0]);
/* 374 */           mc.field_71439_g.func_71165_d("/warp forge");
/*     */           break;
/*     */         
/*     */         case null:
/* 378 */           ChatUtils.send("Detected player at Lift, re-warping", new String[0]);
/* 379 */           mc.field_71439_g.func_71165_d("/warp forge");
/*     */           break;
/*     */         
/*     */         case null:
/* 383 */           ChatUtils.send("Detected player in Lobby, re-warping", new String[0]);
/* 384 */           mc.field_71439_g.func_71165_d("/play skyblock");
/*     */           break;
/*     */         
/*     */         case null:
/* 388 */           ChatUtils.send("Detected player in Limbo, re-warping", new String[0]);
/* 389 */           mc.field_71439_g.func_71165_d("/l");
/*     */           break;
/*     */       } 
/*     */       
/* 393 */       if (curLoc != SkyblockUtils.Location.SKYBLOCK) {
/* 394 */         if (CF4M.INSTANCE.moduleManager.isEnabled("AutoMithril"))
/* 395 */           CF4M.INSTANCE.moduleManager.toggle("AutoMithril"); 
/* 396 */         if (CF4M.INSTANCE.moduleManager.isEnabled("IceGoblinSlayer"))
/* 397 */           CF4M.INSTANCE.moduleManager.toggle("IceGoblinSlayer"); 
/* 398 */         commState = CommState.CLICK_PIGEON;
/* 399 */         KeyBinding.func_74506_a();
/* 400 */         recoverTimer.reset();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private int getCompletedSlot() {
/* 406 */     for (int i = 9; i < 18; i++) {
/* 407 */       ItemStack is = InventoryUtils.getStackInOpenContainerSlot(i);
/* 408 */       if (is != null && 
/* 409 */         SkyblockUtils.stripString(is.func_82833_r()).startsWith("Commission #")) {
/* 410 */         List<String> itemLore = getLore(is);
/* 411 */         if (itemLore.stream().anyMatch(v -> v.toLowerCase().contains("completed"))) {
/* 412 */           return i;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 417 */     return -1;
/*     */   }
/*     */   
/*     */   private List<Integer> getQuestSlots() {
/* 421 */     List<Integer> ret = new ArrayList<>();
/* 422 */     for (int i = 9; i < 18; i++) {
/* 423 */       ItemStack is = InventoryUtils.getStackInOpenContainerSlot(i);
/* 424 */       if (is != null && 
/* 425 */         SkyblockUtils.stripString(is.func_82833_r()).startsWith("Commission #")) {
/* 426 */         List<String> itemLore = getLore(is);
/* 427 */         if (itemLore.stream().noneMatch(v -> v.toLowerCase().contains("completed"))) {
/* 428 */           ret.add(Integer.valueOf(i));
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 433 */     return ret;
/*     */   }
/*     */   
/*     */   @Event
/*     */   public void onChatReceived(ClientChatReceivedEvent event) {
/* 438 */     String msg = event.message.func_150260_c();
/* 439 */     if (commState == CommState.COMMITTING) {
/* 440 */       if (msg.startsWith("Mining Speed Boost is now available!")) {
/* 441 */         mc.field_71442_b.func_78769_a((EntityPlayer)mc.field_71439_g, (World)mc.field_71441_e, mc.field_71439_g.func_70694_bm());
/* 442 */         boostTimer.reset();
/* 443 */       } else if (msg.contains("Commission Complete! Visit the King to claim your rewards!") && !msg.contains(":")) {
/* 444 */         if (CF4M.INSTANCE.moduleManager.isEnabled("AutoMithril"))
/* 445 */           CF4M.INSTANCE.moduleManager.toggle("AutoMithril"); 
/* 446 */         if (CF4M.INSTANCE.moduleManager.isEnabled("IceGoblinSlayer"))
/* 447 */           CF4M.INSTANCE.moduleManager.toggle("IceGoblinSlayer"); 
/* 448 */         commState = CommState.CLICK_PIGEON;
/* 449 */       } else if (msg.startsWith("Your") && msg.contains("is empty! Refuel it by talking to a Drill Mechanic!")) {
/* 450 */         if (CF4M.INSTANCE.moduleManager.isEnabled("AutoMithril"))
/* 451 */           CF4M.INSTANCE.moduleManager.toggle("AutoMithril"); 
/* 452 */         if (CF4M.INSTANCE.moduleManager.isEnabled("IceGoblinSlayer"))
/* 453 */           CF4M.INSTANCE.moduleManager.toggle("IceGoblinSlayer"); 
/* 454 */         currentLocation = miningJson.locations.get(miningJson.locations.size() - 1);
/* 455 */         commState = CommState.WARP_FORGE;
/*     */       } 
/*     */     }
/* 458 */     if (msg.contains("You can't fast travel while in combat!")) {
/* 459 */       ChatUtils.send("Detected travel in combat, evacuating", new String[0]);
/* 460 */       mc.field_71439_g.func_71165_d("/l");
/* 461 */       recoverTimer.reset();
/* 462 */       commState = CommState.CLICK_PIGEON;
/*     */     } 
/*     */   }
/*     */   
/*     */   @Event
/*     */   public void onRenderTick(Render3DEvent event) {
/* 468 */     if (commState == CommState.NAVIGATE && path != null) {
/* 469 */       switch (warpState) {
/*     */         case MITHRIL_MINER:
/* 471 */           if (path.size() > 0) {
/* 472 */             if (warpTimer.hasReached(this.warpTime.getCurrent().intValue()) && !mc.field_71439_g.func_180425_c().equals(oldPos)) {
/* 473 */               PathPoint a = path.get(0);
/* 474 */               path.remove(0);
/* 475 */               RotationUtils.setup(RotationUtils.getRotation(new Vec3(a.x, a.y, a.z)), Long.valueOf(this.lookTime.getCurrent().intValue()));
/* 476 */               oldPos = mc.field_71439_g.func_180425_c();
/* 477 */               warpState = WarpState.LOOK; break;
/* 478 */             }  if (warpTimer.hasReached(2500L)) {
/* 479 */               ChatUtils.send("Got stuck while tp'ing, re-navigating", new String[0]);
/* 480 */               mc.field_71439_g.func_71165_d("/l");
/* 481 */               recoverTimer.reset();
/* 482 */               warpTimer.reset();
/* 483 */               commState = CommState.CLICK_PIGEON;
/*     */             }  break;
/*     */           } 
/* 486 */           KeyBinding.func_74510_a(mc.field_71474_y.field_74311_E.func_151463_i(), false);
/* 487 */           commState = CommState.COMMIT;
/*     */           break;
/*     */ 
/*     */         
/*     */         case TITANIUM_MINER:
/* 492 */           if (System.currentTimeMillis() <= RotationUtils.endTime) {
/* 493 */             RotationUtils.update(); break;
/*     */           } 
/* 495 */           RotationUtils.update();
/* 496 */           warpTimer.reset();
/* 497 */           warpState = WarpState.WARP;
/*     */           break;
/*     */ 
/*     */         
/*     */         case null:
/* 502 */           if (warpTimer.hasReached(this.warpTime.getCurrent().intValue())) {
/* 503 */             SkyblockUtils.silentUse(0, this.aotvSlot.getCurrent().intValue());
/* 504 */             warpTimer.reset();
/* 505 */             warpState = WarpState.SETUP;
/*     */           } 
/*     */           break;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Event
/*     */   public void onWorldUnload(WorldUnloadEvent event) {}
/*     */ 
/*     */   
/*     */   public List<String> getLore(ItemStack is) {
/* 518 */     List<String> lore = new ArrayList<>();
/* 519 */     if (is == null || !is.func_77942_o()) {
/* 520 */       return lore;
/*     */     }
/* 522 */     NBTTagCompound nbt = is.func_77978_p();
/* 523 */     if (nbt.func_74775_l("display") != null) {
/* 524 */       NBTTagCompound display = nbt.func_74775_l("display");
/* 525 */       if (display.func_150295_c("Lore", 8) != null) {
/* 526 */         NBTTagList nbtLore = display.func_150295_c("Lore", 8);
/* 527 */         for (int i = 0; i < nbtLore.func_74745_c(); i++) {
/* 528 */           lore.add(SkyblockUtils.stripString(nbtLore.func_179238_g(i).toString()).replaceAll("\"", ""));
/*     */         }
/*     */       } 
/*     */     } 
/* 532 */     return lore;
/*     */   }
/*     */   
/*     */   public static Quest getQuest(String lore) {
/* 536 */     for (Quest q : Quest.values()) {
/* 537 */       if (q.questName.equalsIgnoreCase(lore)) {
/* 538 */         return q;
/*     */       }
/*     */     } 
/* 541 */     return null;
/*     */   }
/*     */   public static Location getLocation(Quest quest) {
/*     */     List<Location> sub;
/* 545 */     switch (quest)
/*     */     { case MITHRIL_MINER:
/*     */       case TITANIUM_MINER:
/* 548 */         sub = miningJson.locations.subList(0, miningJson.locations.size() - 5);
/* 549 */         if (sub.size() > 0) {
/* 550 */           return sub.get(RandomUtil.randBetween(0, sub.size() - 1));
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 579 */         return null; }  List<Location> possible = new ArrayList<>(); for (Location loc : miningJson.locations) { if (quest.questName.toLowerCase().contains(loc.name.toLowerCase())) { possible.add(loc); continue; }  String name = null; if (loc.name.contains("COMMISSION")) { name = StringUtils.substringBefore(loc.name, " COMMISSION"); } else if (loc.name.contains(" (")) { name = StringUtils.substringBefore(loc.name, " ("); }  if (name != null && quest.questName.toLowerCase().contains(name.toLowerCase())) possible.add(loc);  }  if (possible.size() > 0) return possible.get(RandomUtil.randBetween(0, possible.size() - 1));  return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\modules\player\CommMacro.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */