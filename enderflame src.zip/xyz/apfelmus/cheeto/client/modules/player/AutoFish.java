/*     */ package xyz.apfelmus.cheeto.client.modules.player;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.stream.Collectors;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.settings.KeyBinding;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.item.EntityArmorStand;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.projectile.EntityFishHook;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.play.server.S2APacketParticles;
/*     */ import net.minecraft.util.EnumParticleTypes;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.World;
/*     */ import xyz.apfelmus.cf4m.CF4M;
/*     */ import xyz.apfelmus.cf4m.annotation.Event;
/*     */ import xyz.apfelmus.cf4m.annotation.Setting;
/*     */ import xyz.apfelmus.cf4m.annotation.module.Disable;
/*     */ import xyz.apfelmus.cf4m.annotation.module.Enable;
/*     */ import xyz.apfelmus.cf4m.annotation.module.Module;
/*     */ import xyz.apfelmus.cheeto.client.events.ClientTickEvent;
/*     */ import xyz.apfelmus.cheeto.client.events.Render3DEvent;
/*     */ import xyz.apfelmus.cheeto.client.settings.BooleanSetting;
/*     */ import xyz.apfelmus.cheeto.client.settings.IntegerSetting;
/*     */ import xyz.apfelmus.cheeto.client.settings.ModeSetting;
/*     */ import xyz.apfelmus.cheeto.client.utils.client.ChadUtils;
/*     */ import xyz.apfelmus.cheeto.client.utils.client.ChatUtils;
/*     */ import xyz.apfelmus.cheeto.client.utils.client.JsonUtils;
/*     */ import xyz.apfelmus.cheeto.client.utils.client.KeybindUtils;
/*     */ import xyz.apfelmus.cheeto.client.utils.client.Rotation;
/*     */ import xyz.apfelmus.cheeto.client.utils.client.RotationUtils;
/*     */ import xyz.apfelmus.cheeto.client.utils.fishing.Location;
/*     */ import xyz.apfelmus.cheeto.client.utils.fishing.PathPoint;
/*     */ import xyz.apfelmus.cheeto.client.utils.math.RandomUtil;
/*     */ import xyz.apfelmus.cheeto.client.utils.math.TimeHelper;
/*     */ import xyz.apfelmus.cheeto.client.utils.math.VecUtils;
/*     */ import xyz.apfelmus.cheeto.client.utils.skyblock.SkyblockUtils;
/*     */ 
/*     */ @Module(name = "AutoFish", category = Category.PLAYER)
/*     */ public class AutoFish {
/*  46 */   private static FishingJson fishingJson = JsonUtils.getFishingJson(); @Setting(name = "FishingSpot", description = "Spot to fish at, requires Etherwarp")
/*  47 */   private ModeSetting fishingSpot = new ModeSetting("None", 
/*  48 */       getFishingSpotNames()); @Setting(name = "RecastDelay")
/*  49 */   private IntegerSetting recastDelay = new IntegerSetting(
/*  50 */       Integer.valueOf(250), Integer.valueOf(0), Integer.valueOf(2000)); @Setting(name = "AntiAfk")
/*  51 */   private BooleanSetting antiAfk = new BooleanSetting(true);
/*     */   @Setting(name = "RodSlot")
/*  53 */   private IntegerSetting rodSlot = new IntegerSetting(
/*  54 */       Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(8)); @Setting(name = "WhipSlot", description = "Configure for Automatic SC Killing")
/*  55 */   private IntegerSetting whipSlot = new IntegerSetting(
/*  56 */       Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(8)); @Setting(name = "KillMode", description = "Left or Right Click")
/*  57 */   private ModeSetting killMode = new ModeSetting("Right", 
/*  58 */       Arrays.asList(new String[] { "Left", "Right" })); @Setting(name = "KillPrio", description = "Kill SC before Re-casting (Sword)")
/*  59 */   private BooleanSetting killPrio = new BooleanSetting(false);
/*     */   @Setting(name = "SCRange", description = "Range for Sea Creature Killing")
/*  61 */   private IntegerSetting scRange = new IntegerSetting(
/*  62 */       Integer.valueOf(10), Integer.valueOf(0), Integer.valueOf(20)); @Setting(name = "PetSwap", description = "Activates PetSwap on bobber in water")
/*  63 */   private BooleanSetting petSwap = new BooleanSetting(false);
/*     */   @Setting(name = "AotvSlot")
/*  65 */   private IntegerSetting aotvSlot = new IntegerSetting(
/*  66 */       Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(8)); @Setting(name = "WarpLookTime", description = "Set higher if low mana or bad ping")
/*  67 */   private IntegerSetting warpLookTime = new IntegerSetting(
/*  68 */       Integer.valueOf(500), Integer.valueOf(0), Integer.valueOf(2500)); @Setting(name = "WarpTime", description = "Set higher if low mana or bad ping")
/*  69 */   private IntegerSetting warpTime = new IntegerSetting(
/*  70 */       Integer.valueOf(250), Integer.valueOf(0), Integer.valueOf(1000)); @Setting(name = "MaxPlayerRange", description = "Range the bot will warp out at")
/*  71 */   private IntegerSetting maxPlayerRange = new IntegerSetting(
/*  72 */       Integer.valueOf(5), Integer.valueOf(0), Integer.valueOf(10)); @Setting(name = "Sneak", description = "Makes the player sneak while fishing")
/*  73 */   private BooleanSetting sneak = new BooleanSetting(false);
/*     */   @Setting(name = "Ungrab", description = "Automatically tabs out")
/*  75 */   private BooleanSetting ungrab = new BooleanSetting(true);
/*     */ 
/*     */   
/*  78 */   private static Minecraft mc = Minecraft.func_71410_x();
/*     */   
/*  80 */   private static List<String> fishingMobs = JsonUtils.getListFromUrl("https://gist.githubusercontent.com/Apfelmus1337/da641d3805bddf800eef170cbb0068ec/raw", "mobs");
/*     */   
/*  82 */   private static TimeHelper warpTimer = new TimeHelper();
/*  83 */   private static TimeHelper throwTimer = new TimeHelper();
/*  84 */   private static TimeHelper inWaterTimer = new TimeHelper();
/*  85 */   private static TimeHelper killTimer = new TimeHelper();
/*  86 */   private static TimeHelper recoverTimer = new TimeHelper();
/*  87 */   private static EntityArmorStand curScStand = null;
/*  88 */   private static Entity curSc = null;
/*     */   
/*     */   private static boolean killing = false;
/*  91 */   private static Location currentLocation = null;
/*  92 */   private static List<PathPoint> path = null;
/*  93 */   private static BlockPos oldPos = null;
/*     */   
/*  95 */   private static double oldBobberPosY = 0.0D;
/*     */   private static boolean oldBobberInWater = false;
/*  97 */   private static int ticks = 0;
/*  98 */   private static Vec3 startPos = null;
/*  99 */   private static Rotation startRot = null;
/*     */   
/* 101 */   private static List<ParticleEntry> particleList = new ArrayList<>();
/*     */   
/*     */   private enum AutoFishState {
/* 104 */     WARP_ISLAND,
/* 105 */     WARP_SPOT,
/* 106 */     NAVIGATING,
/* 107 */     THROWING,
/* 108 */     IN_WATER,
/* 109 */     FISH_BITE;
/*     */   }
/*     */   
/*     */   private enum WarpState {
/* 113 */     SETUP,
/* 114 */     LOOK,
/* 115 */     WARP;
/*     */   }
/*     */   
/*     */   private enum AAState {
/* 119 */     AWAY,
/* 120 */     BACK;
/*     */   }
/*     */   
/* 123 */   private AutoFishState afs = AutoFishState.THROWING;
/* 124 */   private WarpState warpState = WarpState.SETUP;
/* 125 */   private AAState aaState = AAState.AWAY;
/*     */   
/*     */   @Enable
/*     */   public void onEnable() {
/* 129 */     this.afs = AutoFishState.THROWING;
/* 130 */     this.aaState = AAState.AWAY;
/* 131 */     throwTimer.reset();
/* 132 */     inWaterTimer.reset();
/* 133 */     warpTimer.reset();
/* 134 */     ticks = 0;
/* 135 */     oldBobberPosY = 0.0D;
/* 136 */     oldBobberInWater = false;
/* 137 */     curScStand = null;
/* 138 */     curSc = null;
/* 139 */     killing = true;
/* 140 */     particleList.clear();
/*     */     
/* 142 */     RotationUtils.reset();
/*     */     
/* 144 */     if (this.rodSlot.getCurrent().intValue() == 0) {
/* 145 */       ChatUtils.send("Configure your RodSlot pls ty", new String[0]);
/* 146 */       CF4M.INSTANCE.moduleManager.toggle(this);
/*     */       
/*     */       return;
/*     */     } 
/* 150 */     if (this.whipSlot.getCurrent().intValue() != 0 && fishingMobs.isEmpty()) {
/* 151 */       ChatUtils.send("An error occured while getting Fishing Mobs, reloading...", new String[0]);
/* 152 */       fishingMobs = JsonUtils.getListFromUrl("https://gist.githubusercontent.com/Apfelmus1337/da641d3805bddf800eef170cbb0068ec/raw", "mobs");
/* 153 */       CF4M.INSTANCE.moduleManager.toggle(this);
/*     */       
/*     */       return;
/*     */     } 
/* 157 */     if (!this.fishingSpot.getCurrent().equals("None")) {
/* 158 */       if (fishingJson == null) {
/* 159 */         ChatUtils.send("An error occured while getting Fishing Locations, reloading...", new String[0]);
/* 160 */         fishingJson = JsonUtils.getFishingJson();
/* 161 */         CF4M.INSTANCE.moduleManager.toggle(this);
/*     */         
/*     */         return;
/*     */       } 
/* 165 */       if (this.aotvSlot.getCurrent().intValue() == 0) {
/* 166 */         ChatUtils.send("Configure your AotvSlot pls ty", new String[0]);
/* 167 */         CF4M.INSTANCE.moduleManager.toggle(this);
/*     */         
/*     */         return;
/*     */       } 
/* 171 */       this.afs = AutoFishState.WARP_ISLAND;
/* 172 */       this.warpState = WarpState.SETUP;
/*     */     } 
/*     */     
/* 175 */     startPos = mc.field_71439_g.func_174791_d();
/* 176 */     startRot = new Rotation(mc.field_71439_g.field_70177_z, mc.field_71439_g.field_70125_A);
/* 177 */     KeyBinding.func_74510_a(mc.field_71474_y.field_74311_E.func_151463_i(), this.sneak.isEnabled());
/*     */     
/* 179 */     if (this.ungrab.isEnabled())
/* 180 */       ChadUtils.ungrabMouse(); 
/*     */   }
/*     */   
/*     */   @Disable
/*     */   public void onDisable() {
/* 185 */     if (this.sneak.isEnabled())
/* 186 */       KeyBinding.func_74510_a(mc.field_71474_y.field_74311_E.func_151463_i(), false); 
/* 187 */     KeybindUtils.stopMovement();
/* 188 */     RotationUtils.reset();
/*     */     
/* 190 */     if (this.ungrab.isEnabled())
/* 191 */       ChadUtils.regrabMouse(); 
/*     */   }
/*     */   @Event
/*     */   public void onTick(ClientTickEvent event) {
/*     */     ItemStack heldItem;
/* 196 */     if (mc.field_71462_r != null && !(mc.field_71462_r instanceof net.minecraft.client.gui.GuiChat)) {
/*     */       return;
/*     */     }
/* 199 */     KeybindUtils.stopMovement();
/*     */     
/* 201 */     if (this.antiAfk.isEnabled() && this.afs != AutoFishState.WARP_ISLAND && this.afs != AutoFishState.WARP_SPOT && this.afs != AutoFishState.NAVIGATING && ++ticks > 40) {
/* 202 */       ticks = 0;
/*     */       
/* 204 */       List<KeyBinding> neededPresses = VecUtils.getNeededKeyPresses(mc.field_71439_g.func_174791_d(), startPos);
/* 205 */       neededPresses.forEach(v -> KeyBinding.func_74510_a(v.func_151463_i(), true));
/*     */       
/* 207 */       if (RotationUtils.done) {
/* 208 */         Rotation afk; switch (this.aaState) {
/*     */           case SETUP:
/* 210 */             afk = new Rotation(startRot.getYaw(), startRot.getPitch());
/* 211 */             afk.addYaw((float)(Math.random() * 4.0D - 2.0D));
/* 212 */             afk.addPitch((float)(Math.random() * 4.0D - 2.0D));
/* 213 */             RotationUtils.setup(afk, Long.valueOf(RandomUtil.randBetween(400, 600)));
/* 214 */             this.aaState = AAState.BACK;
/*     */             break;
/*     */           
/*     */           case LOOK:
/* 218 */             RotationUtils.setup(startRot, Long.valueOf(RandomUtil.randBetween(400, 600)));
/* 219 */             this.aaState = AAState.AWAY;
/*     */             break;
/*     */         } 
/*     */ 
/*     */       
/*     */       } 
/*     */     } 
/* 226 */     particleList.removeIf(v -> (System.currentTimeMillis() - v.timeAdded > 1000L));
/*     */     
/* 228 */     if (this.whipSlot.getCurrent().intValue() != 0) {
/* 229 */       if (curScStand != null && 
/* 230 */         SkyblockUtils.getMobHp(curScStand) <= 0) {
/* 231 */         if (this.rodSlot.getCurrent().intValue() > 0 && this.rodSlot.getCurrent().intValue() <= 8) {
/* 232 */           mc.field_71439_g.field_71071_by.field_70461_c = this.rodSlot.getCurrent().intValue() - 1;
/*     */         }
/*     */         
/* 235 */         curScStand = null;
/* 236 */         curSc = null;
/*     */       } 
/*     */ 
/*     */       
/* 240 */       if (curSc == null && killing) {
/* 241 */         RotationUtils.setup(startRot, Long.valueOf(RandomUtil.randBetween(400, 600)));
/* 242 */         killing = false;
/*     */       } 
/*     */     } 
/*     */     
/* 246 */     SkyblockUtils.Location sbLoc = SkyblockUtils.getLocation();
/*     */     
/* 248 */     if (recoverTimer.hasReached(5000L)) {
/* 249 */       String recoverMsg = "";
/*     */       
/* 251 */       switch (sbLoc) {
/*     */         case SETUP:
/* 253 */           ChatUtils.send("Detected player in Lobby, re-warping", new String[0]);
/* 254 */           recoverMsg = "/play skyblock";
/*     */           break;
/*     */         
/*     */         case LOOK:
/* 258 */           ChatUtils.send("Detected player in Limbo, re-warping", new String[0]);
/* 259 */           recoverMsg = "/l";
/*     */           break;
/*     */       } 
/*     */       
/* 263 */       if (!recoverMsg.equals("")) {
/* 264 */         this.afs = AutoFishState.THROWING;
/* 265 */         this.aaState = AAState.AWAY;
/* 266 */         throwTimer.reset();
/* 267 */         inWaterTimer.reset();
/* 268 */         warpTimer.reset();
/* 269 */         recoverTimer.reset();
/* 270 */         ticks = 0;
/* 271 */         oldBobberPosY = 0.0D;
/* 272 */         oldBobberInWater = false;
/* 273 */         curScStand = null;
/* 274 */         curSc = null;
/* 275 */         killing = true;
/* 276 */         particleList.clear();
/*     */         
/* 278 */         RotationUtils.reset();
/* 279 */         mc.field_71439_g.func_71165_d(recoverMsg);
/* 280 */         this.afs = AutoFishState.WARP_ISLAND;
/* 281 */         this.warpState = WarpState.SETUP;
/*     */       } 
/* 283 */       recoverTimer.reset();
/*     */     } 
/*     */     
/* 286 */     if (this.afs == AutoFishState.THROWING || this.afs == AutoFishState.IN_WATER || this.afs == AutoFishState.FISH_BITE) {
/* 287 */       int rongo = this.maxPlayerRange.getCurrent().intValue();
/* 288 */       if (rongo != 0) {
/* 289 */         String warpName = "";
/* 290 */         boolean warpOut = false;
/*     */         
/* 292 */         for (Entity e : mc.field_71441_e.func_175674_a((Entity)mc.field_71439_g, mc.field_71439_g.func_174813_aQ().func_72314_b(rongo, (rongo >> 1), rongo), a -> (a instanceof net.minecraft.client.entity.EntityOtherPlayerMP || a instanceof EntityArmorStand))) {
/* 293 */           if (e instanceof EntityArmorStand) {
/* 294 */             ItemStack bushSlot = ((EntityArmorStand)e).func_71124_b(4);
/* 295 */             if (bushSlot != null && Item.func_150898_a((Block)Blocks.field_150330_I) == bushSlot.func_77973_b()) {
/* 296 */               warpOut = true;
/* 297 */               warpName = "Dead Bush"; break;
/*     */             }  continue;
/*     */           } 
/* 300 */           if (e instanceof net.minecraft.client.entity.EntityOtherPlayerMP) {
/*     */             
/* 302 */             String formatted = e.func_145748_c_().func_150254_d();
/* 303 */             if (StringUtils.func_76338_a(formatted).equals(formatted)) {
/*     */               continue;
/*     */             }
/* 306 */             if (formatted.startsWith("§r") && !formatted.startsWith("§r§")) {
/*     */               continue;
/*     */             }
/* 309 */             warpOut = true;
/* 310 */             warpName = e.func_70005_c_();
/*     */           } 
/*     */         } 
/*     */         
/* 314 */         if (warpOut) {
/* 315 */           if (!this.fishingSpot.getCurrent().equals("None")) {
/* 316 */             ChatUtils.send("Switching lobbies cause a nice person is near you: " + warpName, new String[0]);
/* 317 */             this.afs = AutoFishState.THROWING;
/* 318 */             this.aaState = AAState.AWAY;
/* 319 */             throwTimer.reset();
/* 320 */             inWaterTimer.reset();
/* 321 */             warpTimer.reset();
/* 322 */             recoverTimer.reset();
/* 323 */             ticks = 0;
/* 324 */             oldBobberPosY = 0.0D;
/* 325 */             oldBobberInWater = false;
/* 326 */             curScStand = null;
/* 327 */             curSc = null;
/* 328 */             killing = true;
/* 329 */             particleList.clear();
/*     */             
/* 331 */             RotationUtils.reset();
/* 332 */             this.afs = AutoFishState.WARP_ISLAND;
/* 333 */             this.warpState = WarpState.SETUP;
/*     */           } else {
/* 335 */             mc.field_71439_g.func_71165_d("/warp home");
/* 336 */             ChatUtils.send("A nice person was near you (" + warpName + "), but you didn't configure a fishing spot, so I evacuated you", new String[0]);
/*     */           } 
/*     */         }
/*     */       } 
/*     */       
/* 341 */       if (this.sneak.isEnabled()) {
/* 342 */         KeyBinding.func_74510_a(mc.field_71474_y.field_74311_E.func_151463_i(), true);
/*     */       }
/* 344 */       if (this.killPrio.isEnabled()) {
/* 345 */         findAndSetCurrentSeaCreature();
/*     */         
/* 347 */         if (curSc != null) {
/* 348 */           throwTimer.reset();
/*     */         }
/* 350 */       } else if (curScStand != null && 
/* 351 */         SkyblockUtils.getMobHp(curScStand) <= 0) {
/* 352 */         curScStand = null;
/* 353 */         curSc = null;
/*     */         
/* 355 */         if (this.rodSlot.getCurrent().intValue() > 0 && this.rodSlot.getCurrent().intValue() <= 8) {
/* 356 */           mc.field_71439_g.field_71071_by.field_70461_c = this.rodSlot.getCurrent().intValue() - 1;
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 362 */     switch (this.afs) {
/*     */       case SETUP:
/* 364 */         if (warpTimer.hasReached(5000L)) {
/* 365 */           Optional<Location> loc = fishingJson.locations.stream().filter(v -> v.name.equals(this.fishingSpot.getCurrent())).findFirst();
/* 366 */           loc.ifPresent(location -> currentLocation = location);
/* 367 */           if (currentLocation != null) {
/* 368 */             ChatUtils.send("Navigating to: " + currentLocation.name.split(" - ")[1], new String[0]);
/* 369 */             mc.field_71439_g.func_71165_d("/warp home");
/* 370 */             warpTimer.reset();
/* 371 */             this.afs = AutoFishState.WARP_SPOT; break;
/*     */           } 
/* 373 */           ChatUtils.send("Couldn't determine location, very weird", new String[0]);
/* 374 */           CF4M.INSTANCE.moduleManager.toggle(this);
/*     */         } 
/*     */         break;
/*     */ 
/*     */       
/*     */       case LOOK:
/* 380 */         if (warpTimer.hasReached(5000L)) {
/* 381 */           String warpLoc = currentLocation.name.split(" - ")[0];
/* 382 */           mc.field_71439_g.func_71165_d(warpLoc);
/* 383 */           warpTimer.reset();
/* 384 */           path = null;
/* 385 */           this.afs = AutoFishState.NAVIGATING;
/*     */         } 
/*     */         break;
/*     */       
/*     */       case WARP:
/* 390 */         if (warpTimer.hasReached(5000L) && path == null) {
/* 391 */           path = new ArrayList<>(currentLocation.path);
/* 392 */           oldPos = null;
/* 393 */           KeyBinding.func_74510_a(mc.field_71474_y.field_74311_E.func_151463_i(), true);
/* 394 */           warpTimer.reset();
/* 395 */           this.warpState = WarpState.SETUP;
/*     */         } 
/*     */         break;
/*     */       
/*     */       case null:
/* 400 */         if (mc.field_71439_g.field_71104_cf == null && throwTimer.hasReached(this.recastDelay.getCurrent().intValue())) {
/* 401 */           if (this.rodSlot.getCurrent().intValue() > 0 && this.rodSlot.getCurrent().intValue() <= 8) {
/* 402 */             mc.field_71439_g.field_71071_by.field_70461_c = this.rodSlot.getCurrent().intValue() - 1;
/*     */           }
/* 404 */           mc.field_71442_b.func_78769_a((EntityPlayer)mc.field_71439_g, (World)mc.field_71441_e, mc.field_71439_g.func_70694_bm());
/* 405 */           throwTimer.reset();
/* 406 */           inWaterTimer.reset();
/* 407 */           this.afs = AutoFishState.IN_WATER; break;
/* 408 */         }  if (throwTimer.hasReached(2500L) && mc.field_71439_g.field_71104_cf != null) {
/* 409 */           this.afs = AutoFishState.FISH_BITE;
/*     */         }
/*     */         break;
/*     */       
/*     */       case null:
/* 414 */         heldItem = mc.field_71439_g.func_70694_bm();
/* 415 */         if (heldItem != null && heldItem.func_77973_b() == Items.field_151112_aM) {
/* 416 */           if (throwTimer.hasReached(500L) && mc.field_71439_g.field_71104_cf != null) {
/* 417 */             if (mc.field_71439_g.field_71104_cf.func_70090_H() || mc.field_71439_g.field_71104_cf.func_180799_ab()) {
/*     */               
/* 419 */               if (!this.killPrio.isEnabled()) {
/* 420 */                 findAndSetCurrentSeaCreature();
/*     */               }
/*     */ 
/*     */               
/* 424 */               if (!oldBobberInWater) {
/* 425 */                 if (this.petSwap.isEnabled()) {
/* 426 */                   KeybindUtils.stopMovement();
/* 427 */                   CF4M.INSTANCE.moduleManager.toggle("PetSwap");
/*     */                 } 
/*     */                 
/* 430 */                 oldBobberInWater = true;
/* 431 */                 inWaterTimer.reset();
/*     */               } 
/*     */               
/* 434 */               EntityFishHook bobber = mc.field_71439_g.field_71104_cf;
/*     */               
/* 436 */               if (inWaterTimer.hasReached(2500L) && Math.abs(bobber.field_70159_w) < 0.01D && Math.abs(bobber.field_70179_y) < 0.01D) {
/* 437 */                 double movement = bobber.field_70163_u - oldBobberPosY;
/* 438 */                 oldBobberPosY = bobber.field_70163_u;
/*     */                 
/* 440 */                 if ((movement < -0.04D && bobberIsNearParticles(bobber)) || bobber.field_146043_c != null)
/* 441 */                   this.afs = AutoFishState.FISH_BITE; 
/*     */               }  break;
/*     */             } 
/* 444 */             if (inWaterTimer.hasReached(2500L))
/* 445 */               this.afs = AutoFishState.FISH_BITE;  break;
/*     */           } 
/* 447 */           if (throwTimer.hasReached(1000L) && mc.field_71439_g.field_71104_cf == null) {
/* 448 */             throwTimer.reset();
/* 449 */             this.afs = AutoFishState.THROWING;
/*     */           }  break;
/* 451 */         }  if (this.rodSlot.getCurrent().intValue() > 0 && this.rodSlot.getCurrent().intValue() <= 8) {
/* 452 */           mc.field_71439_g.field_71071_by.field_70461_c = this.rodSlot.getCurrent().intValue() - 1;
/*     */         }
/*     */         break;
/*     */       
/*     */       case null:
/* 457 */         if (this.rodSlot.getCurrent().intValue() > 0 && this.rodSlot.getCurrent().intValue() <= 8) {
/* 458 */           mc.field_71439_g.field_71071_by.field_70461_c = this.rodSlot.getCurrent().intValue() - 1;
/*     */         }
/* 460 */         mc.field_71442_b.func_78769_a((EntityPlayer)mc.field_71439_g, (World)mc.field_71441_e, mc.field_71439_g.func_70694_bm());
/* 461 */         RotationUtils.setup(startRot, Long.valueOf(this.recastDelay.getCurrent().intValue()));
/* 462 */         oldBobberInWater = false;
/* 463 */         throwTimer.reset();
/* 464 */         this.afs = AutoFishState.THROWING;
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void findAndSetCurrentSeaCreature() {
/* 470 */     if (this.whipSlot.getCurrent().intValue() != 0) {
/* 471 */       int ranga = this.scRange.getCurrent().intValue();
/* 472 */       List<Entity> mobs = mc.field_71441_e.func_175674_a((Entity)mc.field_71439_g, mc.field_71439_g.func_174813_aQ().func_72314_b(ranga, (ranga >> 1), ranga), e -> e instanceof EntityArmorStand);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 477 */       Optional<Entity> filtered = mobs.stream().filter(v -> (v.func_70032_d((Entity)mc.field_71439_g) < ranga && !v.func_70005_c_().contains(mc.field_71439_g.func_70005_c_()) && fishingMobs.stream().anyMatch(()))).min(Comparator.comparing(v -> Float.valueOf(v.func_70032_d((Entity)mc.field_71439_g))));
/*     */       
/* 479 */       if (filtered.isPresent()) {
/* 480 */         curScStand = (EntityArmorStand)filtered.get();
/* 481 */         curSc = SkyblockUtils.getEntityCuttingOtherEntity((Entity)curScStand, null);
/* 482 */         if (curSc != null && SkyblockUtils.getMobHp(curScStand) > 0) {
/* 483 */           killing = true;
/* 484 */           if (this.killMode.getCurrent().equals("Right")) {
/* 485 */             RotationUtils.setup(RotationUtils.getRotation(curSc.func_174791_d()), Long.valueOf(250L));
/*     */           } else {
/* 487 */             RotationUtils.setup(RotationUtils.getRotation(curSc.func_174791_d().func_72441_c(0.0D, curSc.func_70047_e(), 0.0D)), Long.valueOf(250L));
/*     */           } 
/* 489 */         } else if (SkyblockUtils.getMobHp(curScStand) <= 0) {
/* 490 */           curScStand = null;
/* 491 */           curSc = null;
/*     */           
/* 493 */           if (this.rodSlot.getCurrent().intValue() > 0 && this.rodSlot.getCurrent().intValue() <= 8) {
/* 494 */             mc.field_71439_g.field_71071_by.field_70461_c = this.rodSlot.getCurrent().intValue() - 1;
/*     */           }
/*     */         } 
/* 497 */       } else if (RotationUtils.done) {
/* 498 */         curScStand = null;
/* 499 */         curSc = null;
/*     */         
/* 501 */         if (this.rodSlot.getCurrent().intValue() > 0 && this.rodSlot.getCurrent().intValue() <= 8) {
/* 502 */           mc.field_71439_g.field_71071_by.field_70461_c = this.rodSlot.getCurrent().intValue() - 1;
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @Event
/*     */   public void onRenderTick(Render3DEvent event) {
/* 510 */     if (curSc != null) {
/* 511 */       Render3DUtils.renderBoundingBox(curSc, event.partialTicks, -16776961);
/*     */     }
/* 513 */     if (mc.field_71462_r != null && !(mc.field_71462_r instanceof net.minecraft.client.gui.GuiChat))
/*     */       return; 
/* 515 */     if (!RotationUtils.done) {
/* 516 */       RotationUtils.update();
/*     */     }
/*     */     
/* 519 */     if (this.afs == AutoFishState.NAVIGATING && path != null) {
/* 520 */       switch (this.warpState) {
/*     */         case SETUP:
/* 522 */           if (path.size() > 0) {
/* 523 */             if (warpTimer.hasReached(this.warpTime.getCurrent().intValue()) && !mc.field_71439_g.func_180425_c().equals(oldPos)) {
/* 524 */               PathPoint a = path.get(0);
/* 525 */               path.remove(0);
/* 526 */               RotationUtils.setup(RotationUtils.getRotation(new Vec3(a.x, a.y, a.z)), Long.valueOf(this.warpLookTime.getCurrent().intValue()));
/* 527 */               oldPos = mc.field_71439_g.func_180425_c();
/* 528 */               this.warpState = WarpState.LOOK; break;
/* 529 */             }  if (warpTimer.hasReached(2500L)) {
/* 530 */               ChatUtils.send("Got stuck while tp'ing, re-navigating", new String[0]);
/* 531 */               mc.field_71439_g.func_71165_d("/l");
/* 532 */               recoverTimer.reset();
/* 533 */               warpTimer.reset();
/*     */             }  break;
/*     */           } 
/* 536 */           if (warpTimer.hasReached(1000L)) {
/* 537 */             if (!this.sneak.isEnabled()) {
/* 538 */               KeyBinding.func_74510_a(mc.field_71474_y.field_74311_E.func_151463_i(), false);
/*     */             }
/*     */             
/* 541 */             startRot = currentLocation.rotation;
/* 542 */             startPos = mc.field_71439_g.func_174791_d();
/* 543 */             RotationUtils.setup(startRot, Long.valueOf(this.recastDelay.getCurrent().intValue()));
/*     */             
/* 545 */             throwTimer.reset();
/* 546 */             this.afs = AutoFishState.THROWING;
/*     */           } 
/*     */           break;
/*     */ 
/*     */         
/*     */         case LOOK:
/* 552 */           if (System.currentTimeMillis() <= RotationUtils.endTime) {
/* 553 */             RotationUtils.update(); break;
/*     */           } 
/* 555 */           RotationUtils.update();
/* 556 */           warpTimer.reset();
/* 557 */           this.warpState = WarpState.WARP;
/*     */           break;
/*     */ 
/*     */         
/*     */         case WARP:
/* 562 */           if (warpTimer.hasReached(this.warpTime.getCurrent().intValue())) {
/* 563 */             SkyblockUtils.silentUse(0, this.aotvSlot.getCurrent().intValue());
/* 564 */             warpTimer.reset();
/* 565 */             this.warpState = WarpState.SETUP;
/*     */           } 
/*     */           break;
/*     */       } 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/* 573 */     if (curSc != null && 
/* 574 */       killTimer.hasReached(125L)) {
/* 575 */       if (this.whipSlot.getCurrent().intValue() > 0 && this.whipSlot.getCurrent().intValue() <= 8) {
/* 576 */         mc.field_71439_g.field_71071_by.field_70461_c = this.whipSlot.getCurrent().intValue() - 1;
/*     */       }
/* 578 */       switch (this.killMode.getCurrent()) {
/*     */         case "Left":
/* 580 */           KeybindUtils.leftClick();
/*     */           break;
/*     */         
/*     */         case "Right":
/* 584 */           KeybindUtils.rightClick();
/*     */           break;
/*     */       } 
/* 587 */       killTimer.reset();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Event
/*     */   public void onWorldUnload(WorldUnloadEvent event) {
/* 594 */     if (CF4M.INSTANCE.moduleManager.isEnabled(this) && this.fishingSpot.getCurrent().equals("None")) {
/* 595 */       ChatUtils.send("Your server closed and you didn't have a Spot configured, stopping AutoFish", new String[0]);
/* 596 */       CF4M.INSTANCE.moduleManager.toggle(this);
/*     */       
/*     */       return;
/*     */     } 
/* 600 */     if (!this.fishingSpot.getCurrent().equals("None") && this.afs != AutoFishState.WARP_ISLAND && this.afs != AutoFishState.WARP_SPOT && this.afs != AutoFishState.NAVIGATING) {
/* 601 */       this.afs = AutoFishState.THROWING;
/* 602 */       this.aaState = AAState.AWAY;
/* 603 */       throwTimer.reset();
/* 604 */       inWaterTimer.reset();
/* 605 */       warpTimer.reset();
/* 606 */       recoverTimer.reset();
/* 607 */       ticks = 0;
/* 608 */       oldBobberPosY = 0.0D;
/* 609 */       oldBobberInWater = false;
/* 610 */       curScStand = null;
/* 611 */       curSc = null;
/* 612 */       killing = true;
/* 613 */       particleList.clear();
/*     */       
/* 615 */       RotationUtils.reset();
/* 616 */       this.afs = AutoFishState.WARP_ISLAND;
/* 617 */       this.warpState = WarpState.SETUP;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void handleParticles(S2APacketParticles packet) {
/* 622 */     if (packet.func_179749_a() == EnumParticleTypes.WATER_WAKE || packet.func_179749_a() == EnumParticleTypes.SMOKE_NORMAL) {
/* 623 */       particleList.add(new ParticleEntry(new Vec3(packet.func_149220_d(), packet.func_149226_e(), packet.func_149225_f()), System.currentTimeMillis()));
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean bobberIsNearParticles(EntityFishHook bobber) {
/* 628 */     return particleList.stream().anyMatch(v -> (VecUtils.getHorizontalDistance(bobber.func_174791_d(), v.position) < 0.2D));
/*     */   }
/*     */   
/*     */   private static class ParticleEntry {
/*     */     public Vec3 position;
/*     */     public long timeAdded;
/*     */     
/*     */     public ParticleEntry(Vec3 position, long timeAdded) {
/* 636 */       this.position = position;
/* 637 */       this.timeAdded = timeAdded;
/*     */     }
/*     */   }
/*     */   
/*     */   private List<String> getFishingSpotNames() {
/* 642 */     List<String> ret = new ArrayList<>();
/* 643 */     ret.add("None");
/* 644 */     ret.addAll((Collection<? extends String>)fishingJson.locations.stream()
/* 645 */         .map(v -> v.name)
/* 646 */         .collect(Collectors.toList()));
/* 647 */     return ret;
/*     */   }
/*     */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\modules\player\AutoFish.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */