/*    */ package xyz.apfelmus.cheeto.client.modules.render;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import xyz.apfelmus.cf4m.annotation.Event;
/*    */ import xyz.apfelmus.cf4m.annotation.Setting;
/*    */ import xyz.apfelmus.cf4m.annotation.module.Module;
/*    */ import xyz.apfelmus.cf4m.module.Category;
/*    */ import xyz.apfelmus.cheeto.client.events.Render2DEvent;
/*    */ import xyz.apfelmus.cheeto.client.settings.BooleanSetting;
/*    */ import xyz.apfelmus.cheeto.client.settings.FloatSetting;
/*    */ import xyz.apfelmus.cheeto.client.settings.IntegerSetting;
/*    */ import xyz.apfelmus.cheeto.client.utils.client.FontUtils;
/*    */ 
/*    */ @Module(name = "ShieldCD", category = Category.RENDER)
/*    */ public class ShieldCD
/*    */ {
/*    */   @Setting(name = "xPos")
/* 20 */   private IntegerSetting xPos = new IntegerSetting(
/* 21 */       Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(1000)); @Setting(name = "yPos")
/* 22 */   private IntegerSetting yPos = new IntegerSetting(
/* 23 */       Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(1000)); @Setting(name = "RGB")
/* 24 */   private BooleanSetting rgb = new BooleanSetting(true);
/*    */   @Setting(name = "Scale")
/* 26 */   private FloatSetting scale = new FloatSetting(
/* 27 */       Float.valueOf(1.0F), Float.valueOf(0.0F), Float.valueOf(2.5F));
/*    */   
/* 29 */   public static long LastShield = 0L;
/*    */   
/*    */   @Event
/*    */   public void onRender(Render2DEvent event) {
/* 33 */     long timeDiffy = System.currentTimeMillis() - LastShield;
/*    */     
/* 35 */     if (!((Minecraft.func_71410_x()).field_71462_r instanceof xyz.apfelmus.cheeto.client.clickgui.ConfigGUI) && (Minecraft.func_71410_x()).field_71462_r != null)
/*    */       return; 
/* 37 */     GlStateManager.func_179094_E();
/* 38 */     GlStateManager.func_179152_a(this.scale.getCurrent().floatValue(), this.scale.getCurrent().floatValue(), this.scale.getCurrent().floatValue());
/* 39 */     if (timeDiffy >= 5000L) {
/* 40 */       if (this.rgb.isEnabled()) {
/* 41 */         FontUtils.drawHVCenteredChromaString("Shield: Ready", this.xPos.getCurrent().intValue(), this.yPos.getCurrent().intValue(), 0);
/*    */       } else {
/* 43 */         FontUtils.drawHVCenteredString("Shield: Ready", this.xPos.getCurrent().intValue(), this.yPos.getCurrent().intValue(), Color.GREEN.getRGB());
/*    */       } 
/*    */     } else {
/* 46 */       FontUtils.drawHVCenteredString(String.format("Shield: %.3fs", new Object[] { Float.valueOf((float)(5000L - timeDiffy) / 1000.0F) }), this.xPos.getCurrent().intValue(), this.yPos.getCurrent().intValue(), Color.ORANGE.getRGB());
/*    */     } 
/* 48 */     GlStateManager.func_179121_F();
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\modules\render\ShieldCD.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */