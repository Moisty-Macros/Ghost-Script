package xyz.apfelmus.cheeto.client.modules.render;

import xyz.apfelmus.cf4m.annotation.module.Module;
import xyz.apfelmus.cf4m.module.Category;

@Module(name = "SnowballHider", category = Category.RENDER)
public class SnowballHider {}


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\modules\render\SnowballHider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */