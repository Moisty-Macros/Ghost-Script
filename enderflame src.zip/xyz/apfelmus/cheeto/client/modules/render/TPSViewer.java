/*    */ package xyz.apfelmus.cheeto.client.modules.render;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.minecraft.network.play.server.S03PacketTimeUpdate;
/*    */ import xyz.apfelmus.cf4m.annotation.Event;
/*    */ import xyz.apfelmus.cf4m.annotation.Setting;
/*    */ import xyz.apfelmus.cf4m.annotation.module.Enable;
/*    */ import xyz.apfelmus.cf4m.annotation.module.Module;
/*    */ import xyz.apfelmus.cf4m.module.Category;
/*    */ import xyz.apfelmus.cheeto.client.events.PacketReceivedEvent;
/*    */ import xyz.apfelmus.cheeto.client.events.Render2DEvent;
/*    */ import xyz.apfelmus.cheeto.client.events.WorldUnloadEvent;
/*    */ import xyz.apfelmus.cheeto.client.settings.BooleanSetting;
/*    */ import xyz.apfelmus.cheeto.client.settings.IntegerSetting;
/*    */ import xyz.apfelmus.cheeto.client.utils.client.FontUtils;
/*    */ 
/*    */ @Module(name = "TPSViewer", category = Category.RENDER)
/*    */ public class TPSViewer {
/*    */   @Setting(name = "xPos")
/* 21 */   private IntegerSetting xPos = new IntegerSetting(
/* 22 */       Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(1000)); @Setting(name = "yPos")
/* 23 */   private IntegerSetting yPos = new IntegerSetting(
/* 24 */       Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(1000)); @Setting(name = "RGB")
/* 25 */   private BooleanSetting rgb = new BooleanSetting(true);
/*    */ 
/*    */   
/* 28 */   public static List<Float> serverTPS = new ArrayList<>();
/* 29 */   private static long systemTime = 0L;
/* 30 */   private static long serverTime = 0L;
/*    */   
/*    */   @Enable
/*    */   public void onEnable() {
/* 34 */     serverTPS.clear();
/* 35 */     systemTime = 0L;
/* 36 */     serverTime = 0L;
/*    */   }
/*    */   
/*    */   @Event
/*    */   public void onRender(Render2DEvent event) {
/* 41 */     if (this.rgb.isEnabled()) {
/* 42 */       FontUtils.drawHVCenteredChromaString(String.format("TPS: %.1f", new Object[] { Double.valueOf(calcTps()) }), this.xPos.getCurrent().intValue(), this.yPos.getCurrent().intValue(), 0);
/*    */     } else {
/* 44 */       FontUtils.drawHVCenteredString(String.format("TPS: %.1f", new Object[] { Double.valueOf(calcTps()) }), this.xPos.getCurrent().intValue(), this.yPos.getCurrent().intValue(), -1);
/*    */     } 
/*    */   }
/*    */   
/*    */   @Event
/*    */   public void onPacket(PacketReceivedEvent event) {
/* 50 */     if (event.packet instanceof S03PacketTimeUpdate) {
/* 51 */       S03PacketTimeUpdate s03packet = (S03PacketTimeUpdate)event.packet;
/*    */       
/* 53 */       if (systemTime == 0L) {
/* 54 */         systemTime = System.currentTimeMillis();
/* 55 */         serverTime = s03packet.func_149366_c();
/*    */       } else {
/* 57 */         long newSystemTime = System.currentTimeMillis();
/* 58 */         long newServerTime = s03packet.func_149366_c();
/* 59 */         float tps = (float)(serverTime - newServerTime) / (float)(systemTime - newSystemTime) / 50.0F * 20.0F;
/* 60 */         if (tps <= 20.0F)
/* 61 */           serverTPS.add(Float.valueOf(tps)); 
/* 62 */         systemTime = newSystemTime;
/* 63 */         serverTime = newServerTime;
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   @Event
/*    */   public void onServerJoin(WorldUnloadEvent event) {
/* 70 */     serverTPS.clear();
/* 71 */     systemTime = 0L;
/* 72 */     serverTime = 0L;
/*    */   }
/*    */   
/*    */   private double calcTps() {
/* 76 */     for (; serverTPS.size() > 10; serverTPS.remove(0));
/* 77 */     return (new ArrayList(serverTPS)).stream().mapToDouble(x -> x.floatValue()).sum() / serverTPS.size();
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\modules\render\TPSViewer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */