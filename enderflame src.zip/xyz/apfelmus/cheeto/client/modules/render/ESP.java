/*     */ package xyz.apfelmus.cheeto.client.modules.render;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.monster.EntityEnderman;
/*     */ import net.minecraft.entity.monster.EntitySpider;
/*     */ import net.minecraft.entity.monster.EntityZombie;
/*     */ import net.minecraft.entity.passive.EntityWolf;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import xyz.apfelmus.cf4m.annotation.Event;
/*     */ import xyz.apfelmus.cf4m.annotation.Setting;
/*     */ import xyz.apfelmus.cf4m.annotation.module.Module;
/*     */ import xyz.apfelmus.cf4m.module.Category;
/*     */ import xyz.apfelmus.cheeto.client.events.Render3DEvent;
/*     */ import xyz.apfelmus.cheeto.client.settings.BooleanSetting;
/*     */ import xyz.apfelmus.cheeto.client.settings.FloatSetting;
/*     */ import xyz.apfelmus.cheeto.client.utils.client.ColorUtils;
/*     */ import xyz.apfelmus.cheeto.client.utils.render.Render3DUtils;
/*     */ import xyz.apfelmus.cheeto.client.utils.skyblock.SkyblockUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Module(name = "ESP", category = Category.RENDER)
/*     */ public class ESP
/*     */ {
/*     */   @Setting(name = "StarredMobs")
/*  31 */   private BooleanSetting starredMobs = new BooleanSetting(true);
/*     */   @Setting(name = "Bats")
/*  33 */   private BooleanSetting bats = new BooleanSetting(true);
/*     */   @Setting(name = "Dragon")
/*  35 */   private BooleanSetting dragon = new BooleanSetting(true);
/*     */   @Setting(name = "Arrows")
/*  37 */   private BooleanSetting arrows = new BooleanSetting(true);
/*     */   @Setting(name = "CrystalHollows")
/*  39 */   private BooleanSetting crystalHollows = new BooleanSetting(true);
/*     */   @Setting(name = "Voidgloom")
/*  41 */   private BooleanSetting voidgloom = new BooleanSetting(true);
/*     */   @Setting(name = "Sven")
/*  43 */   private BooleanSetting sven = new BooleanSetting(true);
/*     */   @Setting(name = "Tarantula")
/*  45 */   private BooleanSetting tarantula = new BooleanSetting(true);
/*     */   @Setting(name = "Revenant")
/*  47 */   private BooleanSetting revenant = new BooleanSetting(true);
/*     */   @Setting(name = "BoxOpacity")
/*  49 */   public FloatSetting boxOpacity = new FloatSetting(
/*  50 */       Float.valueOf(0.3F), Float.valueOf(0.0F), Float.valueOf(1.0F));
/*     */   
/*  52 */   private static Minecraft mc = Minecraft.func_71410_x();
/*     */   
/*  54 */   private static Map<String, Integer> voidglooms = new HashMap<String, Integer>()
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */   
/*  60 */   private static Map<String, Integer> svens = new HashMap<String, Integer>()
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */   
/*  66 */   private static Map<String, Integer> tarantulas = new HashMap<String, Integer>()
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */   
/*  72 */   private static Map<String, Integer> revenants = new HashMap<String, Integer>()
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Event
/*     */   public void onESP(Render3DEvent event) {
/*  82 */     if (this.starredMobs.isEnabled() || this.bats.isEnabled() || this.dragon.isEnabled() || this.arrows.isEnabled()) {
/*  83 */       for (Iterator<Entity> iterator = mc.field_71441_e.field_72996_f.iterator(); iterator.hasNext(); ) { Entity e = iterator.next();
/*  84 */         if (this.starredMobs.isEnabled() && 
/*  85 */           e instanceof net.minecraft.entity.item.EntityArmorStand && !e.field_70128_L && e.func_95999_t().contains("✯")) {
/*  86 */           Render3DUtils.renderStarredMobBoundingBox(e, event.partialTicks);
/*     */         }
/*     */ 
/*     */         
/*  90 */         if (this.bats.isEnabled() && 
/*  91 */           e instanceof net.minecraft.entity.passive.EntityBat && !e.field_70128_L) {
/*  92 */           Render3DUtils.renderBoundingBox(e, event.partialTicks, -10335698);
/*     */         }
/*     */ 
/*     */         
/*  96 */         if (this.dragon.isEnabled() && 
/*  97 */           e instanceof net.minecraft.entity.boss.EntityDragon) {
/*  98 */           for (Entity part : e.func_70021_al()) {
/*  99 */             Render3DUtils.renderBoundingBox(part, event.partialTicks, ColorUtils.getChroma(3000.0F, 0));
/*     */           }
/*     */         }
/*     */ 
/*     */         
/* 104 */         if (this.arrows.isEnabled() && 
/* 105 */           e instanceof net.minecraft.entity.projectile.EntityArrow) {
/* 106 */           Render3DUtils.renderBoundingBox(e, event.partialTicks, -1);
/*     */         }
/*     */ 
/*     */         
/* 110 */         if (e instanceof net.minecraft.entity.item.EntityArmorStand) {
/* 111 */           if (this.voidgloom.isEnabled()) {
/* 112 */             voidglooms.forEach((k, v) -> {
/*     */                   if (!e.field_70128_L && e.func_95999_t().contains(k)) {
/*     */                     Entity yep = SkyblockUtils.getEntityCuttingOtherEntity(e, EntityEnderman.class);
/*     */                     
/*     */                     if (yep != null) {
/*     */                       Render3DUtils.renderMiniBoundingBox(yep, event.partialTicks, v.intValue());
/*     */                     }
/*     */                   } 
/*     */                 });
/*     */           }
/* 122 */           if (this.sven.isEnabled()) {
/* 123 */             svens.forEach((k, v) -> {
/*     */                   if (!e.field_70128_L && e.func_95999_t().contains(k)) {
/*     */                     Entity yep = SkyblockUtils.getEntityCuttingOtherEntity(e, EntityWolf.class);
/*     */                     
/*     */                     if (yep != null) {
/*     */                       Render3DUtils.renderMiniBoundingBox(yep, event.partialTicks, v.intValue());
/*     */                     }
/*     */                   } 
/*     */                 });
/*     */           }
/* 133 */           if (this.tarantula.isEnabled()) {
/* 134 */             tarantulas.forEach((k, v) -> {
/*     */                   if (!e.field_70128_L && e.func_95999_t().contains(k)) {
/*     */                     Entity yep = SkyblockUtils.getEntityCuttingOtherEntity(e, EntitySpider.class);
/*     */                     
/*     */                     if (yep != null) {
/*     */                       Render3DUtils.renderMiniBoundingBox(yep, event.partialTicks, v.intValue());
/*     */                     }
/*     */                   } 
/*     */                 });
/*     */           }
/* 144 */           if (this.revenant.isEnabled()) {
/* 145 */             revenants.forEach((k, v) -> {
/*     */                   if (!e.field_70128_L && e.func_95999_t().contains(k)) {
/*     */                     Entity yep = SkyblockUtils.getEntityCuttingOtherEntity(e, EntityZombie.class);
/*     */                     
/*     */                     if (yep != null) {
/*     */                       Render3DUtils.renderMiniBoundingBox(yep, event.partialTicks, v.intValue());
/*     */                     }
/*     */                   } 
/*     */                 });
/*     */           }
/*     */         }  }
/*     */     
/*     */     }
/* 158 */     if (this.crystalHollows.isEnabled())
/* 159 */       for (TileEntity te : (Minecraft.func_71410_x()).field_71441_e.field_147482_g) {
/* 160 */         if (te instanceof net.minecraft.tileentity.TileEntityChest)
/* 161 */           Render3DUtils.drawChestOutline(te.func_174877_v()); 
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\modules\render\ESP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */