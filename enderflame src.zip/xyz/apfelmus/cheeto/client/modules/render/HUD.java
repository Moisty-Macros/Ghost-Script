/*    */ package xyz.apfelmus.cheeto.client.modules.render;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.stream.Collectors;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.ScaledResolution;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import xyz.apfelmus.cf4m.CF4M;
/*    */ import xyz.apfelmus.cf4m.annotation.Event;
/*    */ import xyz.apfelmus.cf4m.annotation.Setting;
/*    */ import xyz.apfelmus.cf4m.annotation.module.Module;
/*    */ import xyz.apfelmus.cf4m.module.Category;
/*    */ import xyz.apfelmus.cheeto.Cheeto;
/*    */ import xyz.apfelmus.cheeto.client.events.Render2DEvent;
/*    */ import xyz.apfelmus.cheeto.client.settings.BooleanSetting;
/*    */ import xyz.apfelmus.cheeto.client.settings.ModeSetting;
/*    */ import xyz.apfelmus.cheeto.client.utils.client.ColorUtils;
/*    */ import xyz.apfelmus.cheeto.client.utils.client.FontUtils;
/*    */ import xyz.apfelmus.cheeto.client.utils.client.RotationUtils;
/*    */ import xyz.apfelmus.cheeto.client.utils.render.Render2DUtils;
/*    */ 
/*    */ @Module(name = "HUD", category = Category.RENDER)
/*    */ public class HUD {
/*    */   @Setting(name = "Watermark")
/* 27 */   private BooleanSetting watermark = new BooleanSetting(true);
/*    */   @Setting(name = "ModuleList")
/* 29 */   private BooleanSetting moduleList = new BooleanSetting(true);
/*    */   @Setting(name = "Logo")
/* 31 */   private ModeSetting logo = new ModeSetting("bing_chilling", 
/* 32 */       Arrays.asList(new String[] { "smirk_cat", "bing_chilling" }));
/*    */   
/*    */   @Event
/*    */   public void onRender(Render2DEvent event) {
/* 36 */     if (this.watermark.isEnabled()) renderTopString();
/*    */     
/* 38 */     if (!this.moduleList.isEnabled()) {
/*    */       return;
/*    */     }
/*    */ 
/*    */     
/* 43 */     List<Object> modules = (List<Object>)CF4M.INSTANCE.moduleManager.getModules().stream().filter(v -> CF4M.INSTANCE.moduleManager.isEnabled(v)).sorted((o1, o2) -> FontUtils.getStringWidth(getModuleName(o2)) - FontUtils.getStringWidth(getModuleName(o1))).collect(Collectors.toList());
/*    */     
/* 45 */     renderModuleList(modules);
/*    */   }
/*    */   
/*    */   private void renderTopString() {
/* 49 */     GlStateManager.func_179139_a(2.0D, 2.0D, 2.0D);
/* 50 */     ClickGUI click = (ClickGUI)CF4M.INSTANCE.moduleManager.getModule("ClickGUI");
/* 51 */     if (click.theme.getCurrent().equals("Femboy")) {
/* 52 */       FontUtils.drawString(Cheeto.name, 2 + FontUtils.getFontHeight(), 2, ColorUtils.SELECTED.getRGB());
/*    */     } else {
/* 54 */       FontUtils.drawChromaString(Cheeto.name, 2 + FontUtils.getFontHeight(), 2, 0);
/*    */     } 
/* 56 */     GlStateManager.func_179139_a(0.5D, 0.5D, 0.5D);
/* 57 */     int nameLength = FontUtils.getStringWidth(Cheeto.name);
/* 58 */     if (click.theme.getCurrent().equals("Femboy")) {
/* 59 */       FontUtils.drawString(" v" + Cheeto.version, 2 + nameLength * 2 + FontUtils.getFontHeight() * 2, 2 + FontUtils.getFontHeight(), ColorUtils.SELECTED.getRGB());
/*    */     } else {
/* 61 */       FontUtils.drawChromaString(" v" + Cheeto.version, 2 + nameLength * 2 + FontUtils.getFontHeight() * 2, 2 + FontUtils.getFontHeight(), nameLength);
/*    */     } 
/* 63 */     Render2DUtils.drawTexture(new ResourceLocation("chromahud:" + this.logo.getCurrent() + ".png"), 2, 2, FontUtils.getFontHeight() * 2, FontUtils.getFontHeight() * 2, FontUtils.getFontHeight() * 2, FontUtils.getFontHeight() * 2, 0, 0);
/*    */   }
/*    */   
/*    */   private void renderModuleList(List<Object> modules) {
/* 67 */     int yStart = 0;
/* 68 */     ScaledResolution sr = new ScaledResolution(Minecraft.func_71410_x());
/* 69 */     for (Object module : modules) {
/* 70 */       int sw = FontUtils.getStringWidth(getModuleName(module));
/* 71 */       int startX = sr.func_78326_a() - sw - 6;
/*    */       
/* 73 */       int animStartX = sr.func_78326_a();
/*    */       
/* 75 */       long start = CF4M.INSTANCE.moduleManager.getActivatedTime(module);
/* 76 */       float spentMillis = (float)(System.currentTimeMillis() - start);
/* 77 */       float relativeProgress = spentMillis / 500.0F;
/* 78 */       int relativeX = (int)((startX - animStartX) * RotationUtils.easeOutCubic(relativeProgress) + animStartX);
/* 79 */       relativeX = Math.max(startX, relativeX);
/* 80 */       int relativeHeight = (int)Math.ceil((13.0F * RotationUtils.easeOutCubic(relativeProgress)));
/* 81 */       relativeHeight = Math.min(relativeHeight, 13);
/*    */       
/* 83 */       ClickGUI click = (ClickGUI)CF4M.INSTANCE.moduleManager.getModule("ClickGUI");
/* 84 */       Render2DUtils.drawRectWH(relativeX - 1, yStart, sr.func_78326_a() - startX + 1, relativeHeight, ColorUtils.HUD_BG.getRGB());
/* 85 */       Render2DUtils.drawLeftRoundedRect((relativeX - 1), yStart, 2.0F, relativeHeight, 2.0F, click.theme.getCurrent().equals("Femboy") ? ColorUtils.SELECTED.getRGB() : ColorUtils.getChroma(2000.0F, yStart / 2));
/* 86 */       FontUtils.drawString(getModuleName(module), relativeX + 2, yStart + 3, ColorUtils.TEXT_HOVERED.getRGB());
/*    */       
/* 88 */       yStart += relativeHeight;
/*    */     } 
/*    */   }
/*    */   
/*    */   private String getModuleName(Object module) {
/* 93 */     return CF4M.INSTANCE.moduleManager.getName(module);
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\modules\render\HUD.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */