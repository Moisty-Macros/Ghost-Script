/*    */ package xyz.apfelmus.cheeto.client.modules.render;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.util.Arrays;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.GuiScreen;
/*    */ import xyz.apfelmus.cf4m.annotation.Setting;
/*    */ import xyz.apfelmus.cf4m.annotation.module.Enable;
/*    */ import xyz.apfelmus.cf4m.annotation.module.Module;
/*    */ import xyz.apfelmus.cf4m.module.Category;
/*    */ import xyz.apfelmus.cheeto.client.clickgui.ConfigGUI;
/*    */ import xyz.apfelmus.cheeto.client.settings.ModeSetting;
/*    */ import xyz.apfelmus.cheeto.client.utils.client.ColorUtils;
/*    */ 
/*    */ @Module(name = "ClickGUI", category = Category.RENDER, key = 157, silent = true)
/*    */ public class ClickGUI {
/*    */   @Setting(name = "Theme", description = "Re-open your GUI to update theme")
/* 18 */   public ModeSetting theme = new ModeSetting("Classic", 
/* 19 */       Arrays.asList(new String[] { "Classic", "Femboy" }));
/*    */   
/* 21 */   private String lastTheme = this.theme.getCurrent();
/*    */   
/*    */   @Enable
/*    */   public void onEnable() {
/* 25 */     if (!this.theme.getCurrent().equals(this.lastTheme)) {
/* 26 */       if (this.theme.getCurrent().equals("Classic")) {
/* 27 */         ColorUtils.MENU_BG = new Color(22, 22, 22);
/* 28 */         ColorUtils.TEXT_HOVERED = new Color(200, 200, 200);
/* 29 */         ColorUtils.HUD_BG = new Color(0, 0, 0, 150);
/* 30 */         ColorUtils.SELECT = new Color(132, 132, 132);
/* 31 */         ColorUtils.LABEL = new Color(150, 150, 150);
/* 32 */         ColorUtils.SUB_LABEL = new Color(100, 100, 100);
/* 33 */         ColorUtils.SELECTED = new Color(55, 174, 160);
/* 34 */         ColorUtils.M_BORDER = new Color(42, 42, 42);
/* 35 */         ColorUtils.C_BORDER = new Color(55, 174, 160, 100);
/*    */       } else {
/* 37 */         ColorUtils.MENU_BG = new Color(22, 22, 22);
/* 38 */         ColorUtils.TEXT_HOVERED = new Color(200, 200, 200);
/* 39 */         ColorUtils.HUD_BG = new Color(0, 0, 0, 150);
/* 40 */         ColorUtils.SELECT = new Color(215, 173, 255, 100);
/* 41 */         ColorUtils.LABEL = new Color(150, 150, 150);
/* 42 */         ColorUtils.SUB_LABEL = new Color(100, 100, 100);
/* 43 */         ColorUtils.SELECTED = new Color(211, 165, 255);
/* 44 */         ColorUtils.M_BORDER = new Color(181, 140, 236);
/* 45 */         ColorUtils.C_BORDER = new Color(215, 173, 255, 100);
/*    */       } 
/*    */       
/* 48 */       this.lastTheme = this.theme.getCurrent();
/*    */     } 
/*    */     
/* 51 */     Minecraft.func_71410_x().func_147108_a((GuiScreen)new ConfigGUI());
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\modules\render\ClickGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */