/*    */ package xyz.apfelmus.cheeto.client.modules.world;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import org.lwjgl.input.Keyboard;
/*    */ import xyz.apfelmus.cf4m.CF4M;
/*    */ import xyz.apfelmus.cf4m.annotation.Event;
/*    */ import xyz.apfelmus.cf4m.annotation.Setting;
/*    */ import xyz.apfelmus.cf4m.annotation.module.Enable;
/*    */ import xyz.apfelmus.cf4m.annotation.module.Module;
/*    */ import xyz.apfelmus.cf4m.module.Category;
/*    */ import xyz.apfelmus.cheeto.client.events.Render3DEvent;
/*    */ import xyz.apfelmus.cheeto.client.settings.BooleanSetting;
/*    */ import xyz.apfelmus.cheeto.client.utils.skyblock.SkyblockUtils;
/*    */ 
/*    */ @Module(name = "GhostBlock", category = Category.WORLD)
/*    */ public class GhostBlock {
/*    */   @Setting(name = "BrrrMode")
/* 17 */   public BooleanSetting brrrMode = new BooleanSetting(true);
/*    */ 
/*    */   
/* 20 */   private static Minecraft mc = Minecraft.func_71410_x();
/*    */   
/*    */   @Enable
/*    */   public void onEnable() {
/* 24 */     if (!this.brrrMode.isEnabled()) {
/* 25 */       SkyblockUtils.ghostBlock();
/* 26 */       CF4M.INSTANCE.moduleManager.toggle(this);
/*    */     } 
/*    */   }
/*    */   
/*    */   @Event
/*    */   public void onTick(Render3DEvent event) {
/* 32 */     if (this.brrrMode.isEnabled() && Keyboard.isKeyDown(CF4M.INSTANCE.moduleManager.getKey(this))) {
/* 33 */       if (mc.field_71462_r == null) {
/* 34 */         SkyblockUtils.ghostBlock();
/*    */       }
/*    */     } else {
/* 37 */       CF4M.INSTANCE.moduleManager.toggle(this);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\modules\world\GhostBlock.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */