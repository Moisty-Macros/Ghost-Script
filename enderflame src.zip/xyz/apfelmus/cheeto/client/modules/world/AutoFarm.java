/*     */ package xyz.apfelmus.cheeto.client.modules.world;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.audio.SoundCategory;
/*     */ import net.minecraft.client.gui.GuiDisconnected;
/*     */ import net.minecraft.client.settings.KeyBinding;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.IChatComponent;
/*     */ import net.minecraft.util.Session;
/*     */ import net.minecraft.util.StringUtils;
/*     */ import net.minecraftforge.fml.common.ObfuscationReflectionHelper;
/*     */ import xyz.apfelmus.cf4m.annotation.Event;
/*     */ import xyz.apfelmus.cf4m.annotation.Setting;
/*     */ import xyz.apfelmus.cf4m.annotation.module.Module;
/*     */ import xyz.apfelmus.cheeto.client.events.ClientChatReceivedEvent;
/*     */ import xyz.apfelmus.cheeto.client.events.ClientTickEvent;
/*     */ import xyz.apfelmus.cheeto.client.events.Render3DEvent;
/*     */ import xyz.apfelmus.cheeto.client.settings.BooleanSetting;
/*     */ import xyz.apfelmus.cheeto.client.settings.IntegerSetting;
/*     */ import xyz.apfelmus.cheeto.client.settings.ModeSetting;
/*     */ import xyz.apfelmus.cheeto.client.settings.StringSetting;
/*     */ import xyz.apfelmus.cheeto.client.utils.client.ChadUtils;
/*     */ import xyz.apfelmus.cheeto.client.utils.client.ChatUtils;
/*     */ import xyz.apfelmus.cheeto.client.utils.client.Rotation;
/*     */ import xyz.apfelmus.cheeto.client.utils.client.RotationUtils;
/*     */ import xyz.apfelmus.cheeto.client.utils.math.RandomUtil;
/*     */ import xyz.apfelmus.cheeto.client.utils.math.TimeHelper;
/*     */ import xyz.apfelmus.cheeto.client.utils.skyblock.InventoryUtils;
/*     */ import xyz.apfelmus.cheeto.client.utils.skyblock.SkyblockUtils;
/*     */ 
/*     */ @Module(name = "AutoFarm", category = Category.WORLD)
/*     */ public class AutoFarm {
/*     */   @Setting(name = "HoeSlot")
/*  47 */   private IntegerSetting hoeSlot = new IntegerSetting(
/*  48 */       Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(8)); @Setting(name = "FailSafeDelay")
/*  49 */   private IntegerSetting failSafeDelay = new IntegerSetting(
/*  50 */       Integer.valueOf(5000), Integer.valueOf(0), Integer.valueOf(10000)); @Setting(name = "CPUSaver")
/*  51 */   private BooleanSetting cpuSaver = new BooleanSetting(true);
/*     */   @Setting(name = "AutoTab")
/*  53 */   private BooleanSetting autoTab = new BooleanSetting(true);
/*     */   @Setting(name = "SoundAlerts")
/*  55 */   private BooleanSetting soundAlerts = new BooleanSetting(true);
/*     */   @Setting(name = "WebhookUpdates")
/*  57 */   private BooleanSetting webhookUpdates = new BooleanSetting(false);
/*     */   @Setting(name = "WebhookURL")
/*  59 */   private StringSetting webhookUrl = new StringSetting("");
/*     */   @Setting(name = "Direction")
/*  61 */   private ModeSetting direction = new ModeSetting("NORTH", new ArrayList(
/*  62 */         Arrays.asList((Object[])new String[] { "NORTH", "EAST", "SOUTH", "WEST" })));
/*     */   
/*  64 */   private Minecraft mc = Minecraft.func_71410_x();
/*     */   
/*  66 */   private int stuckTicks = 0;
/*     */   
/*     */   private BlockPos oldPos;
/*     */   private BlockPos curPos;
/*     */   private boolean invFull = false;
/*     */   private List<ItemStack> oldInv;
/*  72 */   private int oldInvCount = 0;
/*     */   
/*  74 */   private final int GREEN = 3066993;
/*  75 */   private final int ORANGE = 15439360;
/*  76 */   private final int RED = 15158332;
/*  77 */   private final int BLUE = 1689596; private boolean banned; private FarmingState farmingState; private FarmingDirection farmingDirection;
/*     */   private AlertState alertState;
/*     */   private SameInvState sameInvState;
/*     */   private IsRebootState isRebootState;
/*     */   
/*  82 */   enum FarmingState { START_FARMING,
/*  83 */     SET_ANGLES,
/*  84 */     PRESS_KEYS,
/*  85 */     FARMING,
/*  86 */     STOP_FARMING,
/*  87 */     RECOVER; }
/*     */ 
/*     */   
/*     */   enum FarmingDirection {
/*  91 */     LEFT,
/*  92 */     RIGHT;
/*     */   }
/*     */   
/*     */   enum AlertState {
/*  96 */     CHILLING,
/*  97 */     TURNUP,
/*  98 */     PLAY,
/*  99 */     TURNDOWN;
/*     */   }
/*     */   
/*     */   enum SameInvState {
/* 103 */     CHILLING,
/* 104 */     UNPRESS,
/* 105 */     PRESS;
/*     */   }
/*     */   
/*     */   enum IsRebootState {
/* 109 */     ISLAND,
/* 110 */     HUB;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 119 */   private TimeHelper alertTimer = new TimeHelper();
/* 120 */   private TimeHelper sameInvTimer = new TimeHelper();
/* 121 */   private TimeHelper recoverTimer = new TimeHelper();
/*     */   
/* 123 */   private Map<SoundCategory, Float> oldSounds = new HashMap<>();
/* 124 */   private String recoverStr = " ";
/*     */   
/*     */   private boolean recoverBool = false;
/*     */   private boolean islandReboot;
/* 128 */   private List<String> msgs = new ArrayList<>(Arrays.asList(new String[] { "hey?", "wtf?? why am i here", "What is this place!", "Hello?", "helpp where am i?" }));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enable
/*     */   public void onEnable() {
/* 138 */     this.farmingState = FarmingState.START_FARMING;
/* 139 */     this.farmingDirection = FarmingDirection.LEFT;
/* 140 */     this.alertState = AlertState.CHILLING;
/* 141 */     this.sameInvState = SameInvState.CHILLING;
/* 142 */     this.isRebootState = IsRebootState.ISLAND;
/*     */     
/* 144 */     this.islandReboot = false;
/* 145 */     this.banned = false;
/*     */     
/* 147 */     if (this.autoTab.isEnabled()) {
/* 148 */       ChadUtils.ungrabMouse();
/*     */     }
/*     */     
/* 151 */     if (this.cpuSaver.isEnabled()) {
/* 152 */       ChadUtils.improveCpuUsage();
/*     */     }
/*     */   }
/*     */   
/*     */   @Disable
/*     */   public void onDisable() {
/* 158 */     KeyBinding.func_74506_a();
/*     */     
/* 160 */     if (this.autoTab.isEnabled()) {
/* 161 */       ChadUtils.regrabMouse();
/*     */     }
/*     */     
/* 164 */     if (this.cpuSaver.isEnabled()) {
/* 165 */       ChadUtils.revertCpuUsage();
/*     */     }
/*     */     
/* 168 */     if (this.soundAlerts.isEnabled() && this.alertState != AlertState.CHILLING) {
/* 169 */       for (SoundCategory category : SoundCategory.values()) {
/* 170 */         this.mc.field_71474_y.func_151439_a(category, ((Float)this.oldSounds.get(category)).floatValue());
/*     */       }
/* 172 */       this.alertState = AlertState.CHILLING;
/*     */     } 
/*     */   }
/*     */   @Event
/*     */   public void onTick(ClientTickEvent event) {
/*     */     Rotation rot;
/* 178 */     switch (this.farmingState) {
/*     */       case LEFT:
/* 180 */         this.oldInv = null;
/*     */         
/* 182 */         rot = new Rotation(0.0F, 3.0F);
/*     */         
/* 184 */         switch (this.direction.getCurrent()) {
/*     */           case "WEST":
/* 186 */             rot.setYaw(90.0F);
/*     */             break;
/*     */           
/*     */           case "NORTH":
/* 190 */             rot.setYaw(180.0F);
/*     */             break;
/*     */           
/*     */           case "EAST":
/* 194 */             rot.setYaw(-90.0F);
/*     */             break;
/*     */         } 
/*     */         
/* 198 */         RotationUtils.setup(rot, Long.valueOf(1000L));
/*     */         
/* 200 */         this.farmingState = FarmingState.SET_ANGLES;
/*     */         break;
/*     */ 
/*     */       
/*     */       case RIGHT:
/* 205 */         if (this.hoeSlot.getCurrent().intValue() > 0 && this.hoeSlot.getCurrent().intValue() <= 8)
/* 206 */           this.mc.field_71439_g.field_71071_by.field_70461_c = this.hoeSlot.getCurrent().intValue() - 1; 
/* 207 */         pressKeys();
/* 208 */         this.farmingState = FarmingState.FARMING;
/*     */         break;
/*     */ 
/*     */       
/*     */       case null:
/* 213 */         if (!this.banned && 
/* 214 */           this.mc.field_71462_r instanceof GuiDisconnected) {
/* 215 */           GuiDisconnected gd = (GuiDisconnected)this.mc.field_71462_r;
/* 216 */           IChatComponent message = (IChatComponent)ObfuscationReflectionHelper.getPrivateValue(GuiDisconnected.class, gd, new String[] { "message", "field_146304_f" });
/* 217 */           StringBuilder reason = new StringBuilder();
/*     */           
/* 219 */           for (IChatComponent cc : message.func_150253_a()) {
/* 220 */             reason.append(cc.func_150260_c());
/*     */           }
/*     */           
/* 223 */           String re = reason.toString();
/*     */           
/* 225 */           re = re.replace("\r", "\\r").replace("\n", "\\n");
/*     */           
/* 227 */           if (re.contains("banned")) {
/* 228 */             this.banned = true;
/*     */             
/* 230 */             sendWebhook("BEAMED", "You got beamed shitter!\\r\\n" + re, 15158332, true);
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 236 */         if (this.recoverTimer.hasReached(2000L)) {
/* 237 */           BlockPos standing; IBlockState standBs; int[] mods; BlockPos sideBlock; IBlockState sideBs; ItemStack heldItem; List<ItemStack> inv; switch (SkyblockUtils.getLocation()) {
/*     */             case LEFT:
/* 239 */               KeyBinding.func_74506_a();
/*     */               break;
/*     */             
/*     */             case RIGHT:
/* 243 */               if (this.recoverBool) {
/* 244 */                 ChatUtils.send("Recovered! Starting to farm again!", new String[0]);
/* 245 */                 sendWebhook("RECOVERED", "Recovered!\\r\\nStarting to farm again!", 3066993, false);
/* 246 */                 this.recoverBool = false;
/*     */               } 
/*     */               
/* 249 */               standing = new BlockPos(this.mc.field_71439_g.field_70165_t, this.mc.field_71439_g.field_70163_u - 1.0D, this.mc.field_71439_g.field_70161_v);
/* 250 */               standBs = this.mc.field_71441_e.func_180495_p(standing);
/*     */               
/* 252 */               mods = getModifiers(this.direction.getCurrent());
/*     */ 
/*     */               
/* 255 */               if (this.farmingDirection == FarmingDirection.LEFT) {
/* 256 */                 sideBlock = new BlockPos(this.mc.field_71439_g.field_70165_t + mods[0], this.mc.field_71439_g.field_70163_u, this.mc.field_71439_g.field_70161_v + mods[1]);
/*     */               } else {
/* 258 */                 sideBlock = new BlockPos(this.mc.field_71439_g.field_70165_t + (mods[0] * -1), this.mc.field_71439_g.field_70163_u, this.mc.field_71439_g.field_70161_v + (mods[1] * -1));
/*     */               } 
/*     */               
/* 261 */               sideBs = this.mc.field_71441_e.func_180495_p(sideBlock);
/* 262 */               if (sideBs != null && sideBs.func_177230_c() != Blocks.field_150350_a)
/*     */               {
/* 264 */                 if (standBs != null && standBs.func_177230_c() != Blocks.field_150350_a) {
/* 265 */                   this.farmingDirection = (this.farmingDirection == FarmingDirection.LEFT) ? FarmingDirection.RIGHT : FarmingDirection.LEFT;
/* 266 */                   pressKeys();
/*     */                 } 
/*     */               }
/*     */ 
/*     */               
/* 271 */               if (standBs != null && standBs.func_177230_c() == Blocks.field_150357_h) {
/* 272 */                 sendWebhook("ADMIN CHECK", "Stopped Farming:\\r\\nBitch you are getting Admin checked - do something!", 15158332, true);
/* 273 */                 if (this.alertState == AlertState.CHILLING)
/* 274 */                   this.alertState = AlertState.TURNUP; 
/* 275 */                 (new Thread(() -> {
/*     */                       try {
/*     */                         Thread.sleep(1500L);
/*     */                         this.farmingState = FarmingState.STOP_FARMING;
/*     */                         Thread.sleep(2500L);
/*     */                         this.mc.field_71439_g.func_71165_d(this.msgs.get(RandomUtil.randBetween(0, this.msgs.size() - 1)));
/* 281 */                       } catch (InterruptedException e) {
/*     */                         e.printStackTrace();
/*     */                       } 
/* 284 */                     })).start();
/*     */               } 
/*     */ 
/*     */ 
/*     */               
/* 289 */               heldItem = this.mc.field_71439_g.func_70694_bm();
/* 290 */               if (heldItem != null && (
/* 291 */                 heldItem.func_77973_b() == Items.field_151098_aY || heldItem.func_77973_b() == Items.field_151148_bJ)) {
/* 292 */                 sendWebhook("MAPTCHA", "Stopped Farming:\\r\\nShitter you got a Maptcha, you should probably solve it!", 15158332, true);
/* 293 */                 if (this.alertState == AlertState.CHILLING)
/* 294 */                   this.alertState = AlertState.TURNUP; 
/* 295 */                 this.farmingState = FarmingState.STOP_FARMING;
/*     */               } 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 301 */               if (++this.stuckTicks >= 100) {
/* 302 */                 this.curPos = this.mc.field_71439_g.func_180425_c();
/* 303 */                 if (this.oldPos != null && Math.sqrt(this.curPos.func_177951_i((Vec3i)this.oldPos)) <= 2.0D && !this.invFull) {
/* 304 */                   sendWebhook("I AM STUCK", "Oh no - I'm stuck, Step Bro come help me! >_<", 15158332, true);
/* 305 */                   if (this.alertState == AlertState.CHILLING)
/* 306 */                     this.alertState = AlertState.TURNUP; 
/*     */                 } 
/* 308 */                 this.oldPos = this.curPos;
/* 309 */                 this.stuckTicks = 0;
/*     */               } 
/*     */ 
/*     */ 
/*     */               
/* 314 */               switch (this.sameInvState) {
/*     */                 case LEFT:
/* 316 */                   inv = InventoryUtils.getInventoryStacks();
/* 317 */                   if (inv.equals(this.oldInv)) {
/* 318 */                     if (++this.oldInvCount >= 240) {
/* 319 */                       if (this.alertState == AlertState.CHILLING) {
/* 320 */                         this.alertState = AlertState.TURNUP;
/*     */                       }
/* 322 */                       this.sameInvState = SameInvState.UNPRESS;
/* 323 */                       this.sameInvTimer.reset();
/* 324 */                       this.oldInvCount = 0;
/*     */                     }  break;
/*     */                   } 
/* 327 */                   this.oldInv = InventoryUtils.getInventoryStacks();
/* 328 */                   this.oldInvCount = 0;
/*     */                   break;
/*     */ 
/*     */                 
/*     */                 case RIGHT:
/* 333 */                   KeyBinding.func_74506_a();
/* 334 */                   this.sameInvState = SameInvState.PRESS;
/* 335 */                   this.sameInvTimer.reset();
/*     */                   break;
/*     */                 
/*     */                 case null:
/* 339 */                   if (this.sameInvTimer.hasReached(30000L)) {
/* 340 */                     pressKeys();
/* 341 */                     this.sameInvState = SameInvState.CHILLING;
/*     */                   } 
/*     */                   break;
/*     */               } 
/*     */ 
/*     */ 
/*     */               
/* 348 */               if (this.mc.field_71439_g.field_71071_by.func_70447_i() == -1 && !this.invFull) {
/* 349 */                 sendWebhook("FULL INVENTORY", "Stopped Farming:\\r\\nInventory Full!", 15439360, false);
/* 350 */                 if (this.alertState == AlertState.CHILLING)
/* 351 */                   this.alertState = AlertState.TURNUP; 
/* 352 */                 this.invFull = true;
/* 353 */                 KeyBinding.func_74506_a(); break;
/* 354 */               }  if (this.mc.field_71439_g.field_71071_by.func_70447_i() != -1 && this.invFull) {
/* 355 */                 sendWebhook("INVENTORY NOT FULL", "Continued Farming:\\r\\nInventory not full anymore!", 3066993, false);
/* 356 */                 this.invFull = false;
/* 357 */                 pressKeys();
/*     */               } 
/*     */               break;
/*     */ 
/*     */             
/*     */             case null:
/* 363 */               ChatUtils.send("Player isn't in Island!", new String[0]);
/* 364 */               ChatUtils.send("Re-warping in " + this.failSafeDelay.getCurrent() + "ms", new String[0]);
/* 365 */               sendWebhook("NOT IN ISLAND", "Player isn't in Island!\\r\\nRecovering...", 15439360, false);
/* 366 */               this.recoverStr = "/warp home";
/* 367 */               this.recoverBool = true;
/* 368 */               this.farmingState = FarmingState.RECOVER;
/* 369 */               this.recoverTimer.reset();
/* 370 */               KeyBinding.func_74506_a();
/*     */               break;
/*     */             
/*     */             case null:
/* 374 */               ChatUtils.send("Player isn't in Skyblock!", new String[0]);
/* 375 */               ChatUtils.send("Joining Skyblock in " + this.failSafeDelay.getCurrent() + "ms", new String[0]);
/* 376 */               sendWebhook("NOT IN SKYBLOCK", "Player isn't in Island!\\r\\nRecovering...", 15439360, false);
/* 377 */               this.recoverStr = "/play skyblock";
/* 378 */               this.recoverBool = true;
/* 379 */               this.farmingState = FarmingState.RECOVER;
/* 380 */               this.recoverTimer.reset();
/* 381 */               KeyBinding.func_74506_a();
/*     */               break;
/*     */             
/*     */             case null:
/* 385 */               ChatUtils.send("Player is in Limbo!", new String[0]);
/* 386 */               ChatUtils.send("Escaping in " + this.failSafeDelay.getCurrent() + "ms", new String[0]);
/* 387 */               sendWebhook("PLAYER IN LIMBO", "Player isn't in Island!\\r\\nRecovering...", 15439360, false);
/* 388 */               this.recoverStr = "/l";
/* 389 */               this.recoverBool = true;
/* 390 */               this.farmingState = FarmingState.RECOVER;
/* 391 */               this.recoverTimer.reset();
/* 392 */               KeyBinding.func_74506_a();
/*     */               break;
/*     */           } 
/*     */         
/*     */         } 
/*     */         break;
/*     */       case null:
/* 399 */         if (this.islandReboot) {
/* 400 */           switch (this.isRebootState) {
/*     */             case LEFT:
/* 402 */               if (this.recoverTimer.hasReached(this.failSafeDelay.getCurrent().intValue())) {
/* 403 */                 this.mc.field_71439_g.func_71165_d(this.recoverStr);
/* 404 */                 this.recoverStr = "/warp home";
/* 405 */                 this.isRebootState = IsRebootState.HUB;
/* 406 */                 this.recoverTimer.reset();
/*     */               } 
/*     */               break;
/*     */             
/*     */             case RIGHT:
/* 411 */               if (this.recoverTimer.hasReached(15000L)) {
/* 412 */                 this.mc.field_71439_g.func_71165_d(this.recoverStr);
/* 413 */                 this.farmingState = FarmingState.FARMING;
/* 414 */                 this.recoverTimer.reset();
/* 415 */                 this.islandReboot = false;
/*     */               }  break;
/*     */           }  break;
/*     */         } 
/* 419 */         if (this.recoverTimer.hasReached(this.failSafeDelay.getCurrent().intValue()) && SkyblockUtils.getLocation() != SkyblockUtils.Location.NONE) {
/* 420 */           this.mc.field_71439_g.func_71165_d(this.recoverStr);
/* 421 */           this.farmingState = FarmingState.FARMING;
/* 422 */           this.recoverTimer.reset();
/*     */         } 
/*     */         break;
/*     */       
/*     */       case null:
/* 427 */         if (this.autoTab.isEnabled()) {
/* 428 */           ChadUtils.regrabMouse();
/*     */         }
/*     */         
/* 431 */         if (this.cpuSaver.isEnabled()) {
/* 432 */           ChadUtils.revertCpuUsage();
/*     */         }
/*     */         
/* 435 */         KeyBinding.func_74506_a();
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 440 */     if (this.soundAlerts.isEnabled()) {
/* 441 */       switch (this.alertState) {
/*     */         case LEFT:
/* 443 */           for (SoundCategory category : SoundCategory.values()) {
/* 444 */             this.oldSounds.put(category, Float.valueOf(this.mc.field_71474_y.func_151438_a(category)));
/* 445 */             this.mc.field_71474_y.func_151439_a(category, 0.5F);
/*     */           } 
/* 447 */           this.alertState = AlertState.PLAY;
/* 448 */           this.alertTimer.reset();
/*     */           break;
/*     */         
/*     */         case RIGHT:
/* 452 */           if (this.alertTimer.hasReached(100L)) {
/* 453 */             this.mc.field_71439_g.func_85030_a("mob.enderdragon.growl", 1.0F, 1.0F);
/* 454 */             this.alertState = AlertState.TURNDOWN;
/* 455 */             this.alertTimer.reset();
/*     */           } 
/*     */           break;
/*     */         
/*     */         case null:
/* 460 */           if (this.alertTimer.hasReached(2500L)) {
/* 461 */             for (SoundCategory category : SoundCategory.values()) {
/* 462 */               this.mc.field_71474_y.func_151439_a(category, ((Float)this.oldSounds.get(category)).floatValue());
/*     */             }
/* 464 */             this.alertState = AlertState.CHILLING;
/*     */           } 
/*     */           break;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Event
/*     */   public void onRenderWorld(Render3DEvent event) {
/* 474 */     if (this.farmingState == FarmingState.SET_ANGLES) {
/* 475 */       if (System.currentTimeMillis() <= RotationUtils.endTime) {
/* 476 */         RotationUtils.update();
/*     */       } else {
/* 478 */         RotationUtils.update();
/* 479 */         this.farmingDirection = determineDirection();
/* 480 */         this.farmingState = FarmingState.PRESS_KEYS;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   @Event
/*     */   public void onChat(ClientChatReceivedEvent event) {
/* 487 */     if (event.type == 2)
/*     */       return; 
/* 489 */     if (this.farmingState == FarmingState.FARMING) {
/* 490 */       String msg = StringUtils.func_76338_a(event.message.func_150260_c());
/*     */       
/* 492 */       if (msg.startsWith("From") || msg.matches("\\[SkyBlock] .*? is visiting Your Island!.*") || msg.contains("has invited you to join their party!")) {
/* 493 */         this.alertState = AlertState.TURNUP;
/*     */         
/* 495 */         if (msg.startsWith("From")) {
/* 496 */           sendWebhook("MESSAGE", "Received Message:\\r\\n" + msg, 1689596, true);
/* 497 */         } else if (msg.matches("\\[SkyBlock] .*? is visiting Your Island!.*")) {
/* 498 */           Pattern pat = Pattern.compile("\\[SkyBlock] (.*?) is visiting Your Island!.*");
/* 499 */           Matcher mat = pat.matcher(msg);
/*     */           
/* 501 */           if (mat.matches()) {
/* 502 */             sendWebhook("GETTING VISITED", "Player is visiting you:\\r\\n" + mat.group(1), 1689596, true);
/*     */           }
/* 504 */         } else if (msg.contains("has invited you to join their party!")) {
/* 505 */           String[] split = msg.split("\n");
/*     */           
/* 507 */           if (split.length == 4) {
/* 508 */             String mm = split[1];
/* 509 */             Pattern pat = Pattern.compile("(.*?) has invited you to join their party!.*");
/* 510 */             Matcher mat = pat.matcher(mm);
/*     */             
/* 512 */             if (mat.matches()) {
/* 513 */               sendWebhook("PARTY REQUEST", "Player partied you:\\r\\n" + mat.group(1), 1689596, true);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 519 */       if (msg.startsWith("[Important] This server will restart soon:")) {
/* 520 */         this.alertState = AlertState.TURNUP;
/* 521 */         this.mc.field_71439_g.func_71165_d("/setspawn");
/* 522 */         this.islandReboot = true;
/* 523 */         this.isRebootState = IsRebootState.ISLAND;
/* 524 */         ChatUtils.send("Server is rebooting!", new String[0]);
/* 525 */         ChatUtils.send("Escaping in " + this.failSafeDelay.getCurrent() + "ms", new String[0]);
/* 526 */         this.recoverStr = "/warp hub";
/* 527 */         this.farmingState = FarmingState.RECOVER;
/* 528 */         this.recoverTimer.reset();
/* 529 */         KeyBinding.func_74506_a();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private FarmingDirection determineDirection() {
/* 535 */     int[] mod = getModifiers(this.direction.getCurrent());
/*     */     int i;
/* 537 */     for (i = 0; i < 160; i++) {
/* 538 */       BlockPos further = new BlockPos(this.mc.field_71439_g.field_70165_t + (mod[0] * (i + 1)), this.mc.field_71439_g.field_70163_u, this.mc.field_71439_g.field_70161_v + (mod[1] * (i + 1)));
/* 539 */       BlockPos down = new BlockPos(this.mc.field_71439_g.field_70165_t + (mod[0] * i), this.mc.field_71439_g.field_70163_u - 1.0D, this.mc.field_71439_g.field_70161_v + (mod[1] * i));
/*     */       
/* 541 */       IBlockState upBs = this.mc.field_71441_e.func_180495_p(further);
/* 542 */       IBlockState downBs = this.mc.field_71441_e.func_180495_p(down);
/*     */       
/* 544 */       if (downBs != null && downBs.func_177230_c() == Blocks.field_150350_a && 
/* 545 */         upBs != null && upBs.func_177230_c() != Blocks.field_150350_a) {
/* 546 */         return FarmingDirection.LEFT;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 551 */     for (i = 0; i < 160; i++) {
/* 552 */       BlockPos further = new BlockPos(this.mc.field_71439_g.field_70165_t - (mod[0] * (i + 1)), this.mc.field_71439_g.field_70163_u, this.mc.field_71439_g.field_70161_v - (mod[1] * (i + 1)));
/* 553 */       BlockPos down = new BlockPos(this.mc.field_71439_g.field_70165_t - (mod[0] * i), this.mc.field_71439_g.field_70163_u - 1.0D, this.mc.field_71439_g.field_70161_v - (mod[1] * i));
/*     */       
/* 555 */       IBlockState upBs = this.mc.field_71441_e.func_180495_p(further);
/* 556 */       IBlockState downBs = this.mc.field_71441_e.func_180495_p(down);
/*     */       
/* 558 */       if (downBs != null && downBs.func_177230_c() == Blocks.field_150350_a && 
/* 559 */         upBs != null && upBs.func_177230_c() != Blocks.field_150350_a) {
/* 560 */         return FarmingDirection.RIGHT;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 565 */     return FarmingDirection.LEFT;
/*     */   }
/*     */   
/*     */   private int[] getModifiers(String direction) {
/* 569 */     int[] ret = new int[2];
/*     */     
/* 571 */     switch (direction) {
/*     */       case "SOUTH":
/* 573 */         ret[0] = 1;
/*     */         break;
/*     */       
/*     */       case "WEST":
/* 577 */         ret[1] = 1;
/*     */         break;
/*     */       
/*     */       case "NORTH":
/* 581 */         ret[0] = -1;
/*     */         break;
/*     */       
/*     */       case "EAST":
/* 585 */         ret[1] = -1;
/*     */         break;
/*     */     } 
/*     */     
/* 589 */     return ret;
/*     */   }
/*     */   
/*     */   private void pressKeys() {
/* 593 */     this.mc.field_71462_r = null;
/* 594 */     this.mc.field_71415_G = true;
/* 595 */     KeyBinding.func_74510_a(this.mc.field_71474_y.field_74351_w.func_151463_i(), true);
/* 596 */     KeyBinding.func_74510_a(this.mc.field_71474_y.field_74312_F.func_151463_i(), true);
/*     */     
/* 598 */     switch (this.farmingDirection) {
/*     */       case LEFT:
/* 600 */         KeyBinding.func_74510_a(this.mc.field_71474_y.field_74366_z.func_151463_i(), false);
/* 601 */         KeyBinding.func_74510_a(this.mc.field_71474_y.field_74370_x.func_151463_i(), true);
/*     */         break;
/*     */       
/*     */       case RIGHT:
/* 605 */         KeyBinding.func_74510_a(this.mc.field_71474_y.field_74370_x.func_151463_i(), false);
/* 606 */         KeyBinding.func_74510_a(this.mc.field_71474_y.field_74366_z.func_151463_i(), true);
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void sendWebhook(String title, String updateReason, int color, boolean ping) {
/* 612 */     if (this.webhookUpdates.isEnabled())
/*     */       try {
/* 614 */         HttpURLConnection con = (HttpURLConnection)(new URL(this.webhookUrl.getCurrent())).openConnection();
/* 615 */         con.setDoOutput(true);
/* 616 */         con.setRequestMethod("POST");
/* 617 */         con.setRequestProperty("Content-Type", "application/json");
/* 618 */         con.setRequestProperty("User-Agent", "Mozilla/5.0");
/*     */         
/* 620 */         Session session = this.mc.func_110432_I();
/* 621 */         String json = "{ \"content\": " + (ping ? "\"@everyone\"" : "null") + ", \"embeds\": [ { \"title\": \"" + title + "\", \"description\": \"**Account Info**\\nIGN: " + session.func_111285_a() + "\", \"color\": " + color + ", \"fields\": [ { \"name\": \"Update Reason:\", \"value\": \"" + updateReason + "\" } ], \"footer\": { \"text\": \"Made by Apfelsaft#0002\", \"icon_url\": \"https://visage.surgeplay.com/face/128/7c224caeaea249a49783053b9bcf4ed1\" } } ], \"username\": \"" + session.func_111285_a() + "\", \"avatar_url\": \"https://visage.surgeplay.com/face/128/" + session.func_148255_b() + "\" }";
/*     */         
/* 623 */         try (OutputStream output = con.getOutputStream()) {
/* 624 */           output.write(json.getBytes(StandardCharsets.UTF_8));
/*     */         } 
/*     */         
/* 627 */         int resp = con.getResponseCode();
/*     */         
/* 629 */         if (resp == 200 || resp == 204) {
/* 630 */           ChatUtils.send("Webhook sent successfully", new String[0]);
/*     */         } else {
/* 632 */           ChatUtils.send("Error while sending Webhook", new String[0]);
/*     */         } 
/* 634 */       } catch (IOException e) {
/* 635 */         e.printStackTrace();
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\modules\world\AutoFarm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */