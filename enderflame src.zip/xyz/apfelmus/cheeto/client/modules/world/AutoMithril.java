/*     */ package xyz.apfelmus.cheeto.client.modules.world;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.stream.Collectors;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockColored;
/*     */ import net.minecraft.block.BlockStone;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.settings.KeyBinding;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.item.EntityArmorStand;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.EnumDyeColor;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.World;
/*     */ import xyz.apfelmus.cf4m.CF4M;
/*     */ import xyz.apfelmus.cf4m.annotation.Event;
/*     */ import xyz.apfelmus.cf4m.annotation.Setting;
/*     */ import xyz.apfelmus.cf4m.annotation.module.Module;
/*     */ import xyz.apfelmus.cheeto.client.events.ClientChatReceivedEvent;
/*     */ import xyz.apfelmus.cheeto.client.events.ClientTickEvent;
/*     */ import xyz.apfelmus.cheeto.client.events.Render3DEvent;
/*     */ import xyz.apfelmus.cheeto.client.modules.player.CommMacro;
/*     */ import xyz.apfelmus.cheeto.client.settings.BooleanSetting;
/*     */ import xyz.apfelmus.cheeto.client.settings.IntegerSetting;
/*     */ import xyz.apfelmus.cheeto.client.settings.ModeSetting;
/*     */ import xyz.apfelmus.cheeto.client.utils.client.ChadUtils;
/*     */ import xyz.apfelmus.cheeto.client.utils.client.ChatUtils;
/*     */ import xyz.apfelmus.cheeto.client.utils.client.Rotation;
/*     */ import xyz.apfelmus.cheeto.client.utils.client.RotationUtils;
/*     */ import xyz.apfelmus.cheeto.client.utils.math.RandomUtil;
/*     */ import xyz.apfelmus.cheeto.client.utils.math.TimeHelper;
/*     */ import xyz.apfelmus.cheeto.client.utils.mining.Location;
/*     */ import xyz.apfelmus.cheeto.client.utils.mining.PathPoint;
/*     */ import xyz.apfelmus.cheeto.client.utils.render.Render3DUtils;
/*     */ import xyz.apfelmus.cheeto.client.utils.skyblock.InventoryUtils;
/*     */ import xyz.apfelmus.cheeto.client.utils.skyblock.SkyblockUtils;
/*     */ 
/*     */ @Module(name = "AutoMithril", category = Category.WORLD)
/*     */ public class AutoMithril implements Runnable {
/*     */   @Setting(name = "MiningSpot", description = "Spot to mine at, requires Etherwarp")
/*  53 */   private ModeSetting miningSpot = new ModeSetting("None", 
/*  54 */       getMiningSpotNames()); @Setting(name = "PickSlot")
/*  55 */   private IntegerSetting pickSlot = new IntegerSetting(
/*  56 */       Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(8)); @Setting(name = "Sneak", description = "Makes the player sneak while mining")
/*  57 */   private BooleanSetting sneak = new BooleanSetting(false);
/*     */   @Setting(name = "BlueWool")
/*  59 */   private BooleanSetting blueWool = new BooleanSetting(true);
/*     */   @Setting(name = "Prismarine")
/*  61 */   private BooleanSetting prismarine = new BooleanSetting(true);
/*     */   @Setting(name = "Titanium")
/*  63 */   private BooleanSetting titanium = new BooleanSetting(true);
/*     */   @Setting(name = "GrayShit")
/*  65 */   private BooleanSetting grayShit = new BooleanSetting(true);
/*     */   @Setting(name = "LookTime")
/*  67 */   private IntegerSetting lookTime = new IntegerSetting(
/*  68 */       Integer.valueOf(500), Integer.valueOf(0), Integer.valueOf(2500)); @Setting(name = "MaxMineTime", description = "Set to slightly more than it takes to mine")
/*  69 */   private IntegerSetting maxMineTime = new IntegerSetting(
/*  70 */       Integer.valueOf(5000), Integer.valueOf(0), Integer.valueOf(10000)); @Setting(name = "AotvSlot")
/*  71 */   private IntegerSetting aotvSlot = new IntegerSetting(
/*  72 */       Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(8)); @Setting(name = "WarpLookTime", description = "Set higher if low mana or bad ping")
/*  73 */   private IntegerSetting warpLookTime = new IntegerSetting(
/*  74 */       Integer.valueOf(500), Integer.valueOf(0), Integer.valueOf(2500)); @Setting(name = "WarpTime", description = "Set higher if low mana or bad ping")
/*  75 */   private IntegerSetting warpTime = new IntegerSetting(
/*  76 */       Integer.valueOf(250), Integer.valueOf(0), Integer.valueOf(1000)); @Setting(name = "MaxPlayerRange", description = "Range the bot will warp out at")
/*  77 */   private IntegerSetting maxPlayerRange = new IntegerSetting(
/*  78 */       Integer.valueOf(5), Integer.valueOf(0), Integer.valueOf(10)); @Setting(name = "Ungrab", description = "Automatically tabs out")
/*  79 */   private BooleanSetting ungrab = new BooleanSetting(true);
/*     */ 
/*     */   
/*  82 */   private static Minecraft mc = Minecraft.func_71410_x();
/*  83 */   private static Location currentLocation = null;
/*  84 */   private static List<PathPoint> path = null;
/*     */   private Thread thread;
/*  86 */   private List<BetterBlockPos> blocksNear = new ArrayList<>();
/*  87 */   private List<BlockPos> blacklist = new ArrayList<>();
/*  88 */   private int delayMs = 500;
/*     */   
/*     */   private BlockPos curBlockPos;
/*     */   private Block curBlock;
/*     */   private TimeHelper mineTimer;
/*     */   private Vec3 startRot;
/*     */   private Vec3 endRot;
/*  95 */   private static TimeHelper warpTimer = new TimeHelper();
/*  96 */   private static TimeHelper recoverTimer = new TimeHelper();
/*  97 */   private static TimeHelper boostTimer = new TimeHelper();
/*     */   
/*  99 */   private static BlockPos oldPos = null;
/* 100 */   private static int oldDrillSlot = -1;
/*     */   
/* 102 */   private static String fsMsg = "";
/*     */   
/*     */   enum MineState {
/* 105 */     WARP_FORGE,
/* 106 */     NAVIGATING,
/* 107 */     REFUEL,
/* 108 */     CHOOSE,
/* 109 */     LOOK,
/* 110 */     MINE;
/*     */   }
/*     */   
/*     */   private enum WarpState {
/* 114 */     SETUP,
/* 115 */     LOOK,
/* 116 */     WARP;
/*     */   }
/*     */   
/*     */   private enum RefuelState {
/* 120 */     CLICK_MERCHANT,
/* 121 */     CLICK_DRILL_IN,
/* 122 */     CLICK_FUEL_IN,
/* 123 */     REFUEL_DRILL,
/* 124 */     CLICK_DRILL_OUT,
/* 125 */     DONE_REFUELING;
/*     */   }
/*     */   
/* 128 */   private MineState mineState = MineState.CHOOSE;
/* 129 */   private WarpState warpState = WarpState.SETUP;
/* 130 */   private RefuelState refuelState = RefuelState.CLICK_MERCHANT;
/*     */   
/*     */   @Enable
/*     */   public void onEnable() {
/* 134 */     if (this.miningSpot.getCurrent().equals("None") || CF4M.INSTANCE.moduleManager.isEnabled("CommMacro")) {
/* 135 */       this.mineState = MineState.CHOOSE;
/*     */     }
/* 137 */     else if (this.aotvSlot.getCurrent().intValue() > 0 && this.pickSlot.getCurrent().intValue() > 0) {
/* 138 */       this.mineState = MineState.WARP_FORGE;
/* 139 */       this.refuelState = RefuelState.CLICK_MERCHANT;
/* 140 */       currentLocation = null;
/* 141 */       warpTimer.reset();
/* 142 */       recoverTimer.reset();
/* 143 */       boostTimer.reset();
/*     */     } else {
/* 145 */       ChatUtils.send("Configure your fucking Slots if you want FailSafes retard", new String[0]);
/* 146 */       CF4M.INSTANCE.moduleManager.toggle(this);
/*     */     } 
/*     */ 
/*     */     
/* 150 */     this.warpState = WarpState.SETUP;
/* 151 */     this.blocksNear.clear();
/* 152 */     this.blacklist.clear();
/* 153 */     this.mineTimer = new TimeHelper();
/* 154 */     this.curBlockPos = null;
/* 155 */     this.curBlock = null;
/* 156 */     this.startRot = null;
/* 157 */     this.endRot = null;
/* 158 */     KeyBinding.func_74510_a(mc.field_71474_y.field_74311_E.func_151463_i(), this.sneak.isEnabled());
/*     */     
/* 160 */     if (this.ungrab.isEnabled())
/* 161 */       ChadUtils.ungrabMouse(); 
/*     */   }
/*     */   
/*     */   @Disable
/*     */   public void onDisable() {
/* 166 */     KeyBinding.func_74510_a(mc.field_71474_y.field_74312_F.func_151463_i(), false);
/* 167 */     KeyBinding.func_74510_a(mc.field_71474_y.field_74311_E.func_151463_i(), false);
/* 168 */     mc.field_71442_b.func_78767_c();
/*     */     
/* 170 */     if (this.ungrab.isEnabled())
/* 171 */       ChadUtils.regrabMouse(); 
/*     */   }
/*     */   
/*     */   @Event
/*     */   public void onTick(ClientTickEvent event) {
/* 176 */     if (this.mineState == MineState.REFUEL && mc.field_71462_r instanceof net.minecraft.client.gui.inventory.GuiChest) {
/* 177 */       if (currentLocation != null && currentLocation.name.equals("REFUEL") && "Drill Anvil".equals(InventoryUtils.getInventoryName())) {
/* 178 */         ItemStack aboveDrill; ItemStack hopper; ItemStack oldDrill; switch (this.refuelState) {
/*     */           case SETUP:
/* 180 */             oldDrillSlot = InventoryUtils.getSlotForItem("Drill", Items.field_179562_cC);
/* 181 */             mc.field_71442_b.func_78753_a(mc.field_71439_g.field_71070_bA.field_75152_c, oldDrillSlot, 0, 1, (EntityPlayer)mc.field_71439_g);
/* 182 */             this.refuelState = RefuelState.CLICK_FUEL_IN;
/*     */             break;
/*     */           
/*     */           case LOOK:
/* 186 */             aboveDrill = InventoryUtils.getStackInOpenContainerSlot(20);
/* 187 */             if (aboveDrill != null && aboveDrill.func_77952_i() == 5) {
/* 188 */               int fuelSlot = InventoryUtils.getSlotForItem("Volta", Items.field_151144_bL);
/* 189 */               if (fuelSlot == -1) {
/* 190 */                 fuelSlot = InventoryUtils.getSlotForItem("Oil Barrel", Items.field_151144_bL);
/*     */               }
/* 192 */               if (fuelSlot == -1) {
/* 193 */                 ChatUtils.send("Bozo you don't have any fuel", new String[0]);
/* 194 */                 CF4M.INSTANCE.moduleManager.toggle(this);
/* 195 */                 mc.field_71439_g.func_71053_j();
/*     */                 break;
/*     */               } 
/* 198 */               mc.field_71442_b.func_78753_a(mc.field_71439_g.field_71070_bA.field_75152_c, fuelSlot, 0, 1, (EntityPlayer)mc.field_71439_g);
/* 199 */               this.refuelState = RefuelState.REFUEL_DRILL;
/*     */             } 
/*     */             break;
/*     */           
/*     */           case WARP:
/* 204 */             hopper = InventoryUtils.getStackInOpenContainerSlot(22);
/* 205 */             if (hopper != null && hopper.func_77948_v()) {
/* 206 */               mc.field_71442_b.func_78753_a(mc.field_71439_g.field_71070_bA.field_75152_c, 22, 0, 0, (EntityPlayer)mc.field_71439_g);
/* 207 */               this.refuelState = RefuelState.CLICK_DRILL_OUT;
/*     */             } 
/*     */             break;
/*     */ 
/*     */           
/*     */           case null:
/* 213 */             oldDrill = InventoryUtils.getStackInOpenContainerSlot(29);
/*     */             
/* 215 */             if (oldDrill == null) {
/* 216 */               mc.field_71442_b.func_78753_a(mc.field_71439_g.field_71070_bA.field_75152_c, 13, 0, 1, (EntityPlayer)mc.field_71439_g);
/* 217 */               this.refuelState = RefuelState.DONE_REFUELING;
/*     */             } 
/*     */             break;
/*     */           
/*     */           case null:
/* 222 */             mc.field_71439_g.func_71053_j();
/* 223 */             this.mineState = MineState.WARP_FORGE;
/* 224 */             this.refuelState = RefuelState.CLICK_MERCHANT;
/* 225 */             recoverTimer.reset();
/*     */             break;
/*     */         } 
/*     */ 
/*     */       
/*     */       } 
/*     */       return;
/*     */     } 
/* 233 */     if (this.thread == null || !this.thread.isAlive()) {
/* 234 */       (this.thread = new Thread(this)).setDaemon(false);
/* 235 */       this.thread.setPriority(1);
/* 236 */       this.thread.start();
/*     */     } 
/*     */     
/* 239 */     if (this.mineState == MineState.CHOOSE || this.mineState == MineState.LOOK || this.mineState == MineState.MINE) {
/* 240 */       if (!CF4M.INSTANCE.moduleManager.isEnabled("CommMacro")) {
/* 241 */         boolean warpOut = false;
/* 242 */         int rongo = this.maxPlayerRange.getCurrent().intValue();
/*     */         
/* 244 */         if (currentLocation != null && !currentLocation.name.equals("REFUEL")) {
/* 245 */           if (boostTimer.hasReached(125000L)) {
/* 246 */             mc.field_71442_b.func_78769_a((EntityPlayer)mc.field_71439_g, (World)mc.field_71441_e, mc.field_71439_g.func_70694_bm());
/* 247 */             boostTimer.reset();
/*     */           } 
/*     */           
/* 250 */           if (rongo != 0) {
/* 251 */             String warpName = "";
/* 252 */             for (Entity e : mc.field_71441_e.func_175674_a((Entity)mc.field_71439_g, mc.field_71439_g.func_174813_aQ().func_72314_b(rongo, (rongo >> 1), rongo), a -> (a instanceof net.minecraft.client.entity.EntityOtherPlayerMP || a instanceof EntityArmorStand))) {
/* 253 */               if (e instanceof EntityArmorStand) {
/* 254 */                 ItemStack bushSlot = ((EntityArmorStand)e).func_71124_b(4);
/* 255 */                 if (bushSlot != null && Item.func_150898_a((Block)Blocks.field_150330_I) == bushSlot.func_77973_b()) {
/* 256 */                   warpOut = true;
/* 257 */                   warpName = "Dead Bush"; break;
/*     */                 }  continue;
/*     */               } 
/* 260 */               if (!(e instanceof net.minecraft.client.entity.EntityOtherPlayerMP) || 
/* 261 */                 e.func_70005_c_().equals("Goblin ") || e.func_70005_c_().contains("Treasuer Hunter") || e.func_70005_c_().contains("Crystal Sentry"))
/* 262 */                 continue;  String formatted = e.func_145748_c_().func_150254_d();
/* 263 */               if (StringUtils.func_76338_a(formatted).equals(formatted)) {
/*     */                 continue;
/*     */               }
/* 266 */               if (formatted.startsWith("§r") && !formatted.startsWith("§r§")) {
/*     */                 continue;
/*     */               }
/* 269 */               warpOut = true;
/* 270 */               warpName = e.func_70005_c_();
/*     */             } 
/*     */             
/* 273 */             if (warpOut) {
/* 274 */               if (!this.miningSpot.getCurrent().equals("None")) {
/* 275 */                 ChatUtils.send("Switching lobbies cause a nice person is near you: " + warpName, new String[0]);
/* 276 */                 mc.field_71439_g.func_71165_d("/warp home");
/* 277 */                 this.mineState = MineState.WARP_FORGE;
/* 278 */                 KeyBinding.func_74506_a();
/* 279 */                 recoverTimer.reset();
/*     */               } else {
/* 281 */                 ChatUtils.send("A person was near you, but you didn't configure a Mining Spot, sending to your island: " + warpName, new String[0]);
/* 282 */                 mc.field_71439_g.func_71165_d("/warp home");
/* 283 */                 KeyBinding.func_74506_a();
/* 284 */                 if (CF4M.INSTANCE.moduleManager.isEnabled(this)) {
/* 285 */                   CF4M.INSTANCE.moduleManager.toggle(this);
/*     */                 }
/*     */               } 
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/* 292 */       this.blocksNear.removeIf(v -> {
/*     */             Vec3 randPoint = v.points.get(RandomUtil.randBetween(0, v.points.size() - 1));
/*     */             
/*     */             MovingObjectPosition mop = mc.field_71441_e.func_72933_a(mc.field_71439_g.func_174824_e(1.0F), randPoint);
/* 296 */             return (mop != null && mop.field_72313_a == MovingObjectPosition.MovingObjectType.BLOCK) ? (
/* 297 */               (!mop.func_178782_a().equals(v.blockPos) || randPoint.func_72438_d(mc.field_71439_g.func_174824_e(1.0F)) >= mc.field_71442_b.func_78757_d())) : true;
/*     */           });
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 303 */       if (this.blocksNear.stream().noneMatch(v -> v.blockPos.equals(this.curBlockPos))) {
/* 304 */         this.mineState = MineState.CHOOSE;
/*     */       }
/*     */     } 
/*     */     
/* 308 */     if (recoverTimer.hasReached(5000L)) {
/* 309 */       Optional<Location> loc; BlockPosWithVec closest; IBlockState ibs; SkyblockUtils.Location curLoc = SkyblockUtils.getLocation();
/*     */ 
/*     */       
/* 312 */       switch (curLoc) {
/*     */         case SETUP:
/* 314 */           switch (this.mineState) {
/*     */             case SETUP:
/* 316 */               loc = CommMacro.miningJson.locations.stream().filter(v -> v.name.equals(this.miningSpot.getCurrent())).findFirst();
/* 317 */               loc.ifPresent(location -> currentLocation = location);
/* 318 */               if (currentLocation != null) {
/* 319 */                 ChatUtils.send("Navigating to: " + currentLocation.name, new String[0]);
/* 320 */                 mc.field_71439_g.func_71165_d("/warp forge");
/* 321 */                 path = null;
/* 322 */                 this.mineState = MineState.NAVIGATING; break;
/*     */               } 
/* 324 */               ChatUtils.send("Couldn't determine location, very weird", new String[0]);
/* 325 */               CF4M.INSTANCE.moduleManager.toggle(this);
/*     */               break;
/*     */ 
/*     */             
/*     */             case LOOK:
/* 330 */               if (mc.field_71439_g.func_180425_c().equals(new BlockPos(1, 149, -68)) && path == null) {
/* 331 */                 path = new ArrayList<>(currentLocation.path);
/* 332 */                 oldPos = null;
/* 333 */                 KeyBinding.func_74510_a(mc.field_71474_y.field_74311_E.func_151463_i(), true);
/* 334 */                 warpTimer.reset();
/* 335 */                 this.warpState = WarpState.SETUP;
/*     */               } 
/*     */               break;
/*     */             
/*     */             case WARP:
/* 340 */               if (boostTimer.hasReached(125000L)) {
/* 341 */                 mc.field_71442_b.func_78769_a((EntityPlayer)mc.field_71439_g, (World)mc.field_71441_e, mc.field_71439_g.func_70694_bm());
/* 342 */                 boostTimer.reset();
/*     */               } 
/*     */               
/* 345 */               closest = getClosestBlock(null);
/*     */               
/* 347 */               if (closest != null) {
/* 348 */                 this.curBlockPos = closest.getBlockPos();
/* 349 */                 IBlockState iBlockState = mc.field_71441_e.func_180495_p(this.curBlockPos);
/* 350 */                 if (iBlockState != null) {
/* 351 */                   this.curBlock = iBlockState.func_177230_c();
/*     */                 }
/* 353 */                 this.startRot = closest.getVec3();
/* 354 */                 this.endRot = null;
/* 355 */                 RotationUtils.setup(RotationUtils.getRotation(closest.getVec3()), Long.valueOf(this.lookTime.getCurrent().intValue()));
/* 356 */                 this.mineState = MineState.LOOK; break;
/*     */               } 
/* 358 */               KeyBinding.func_74510_a(mc.field_71474_y.field_74312_F.func_151463_i(), false);
/*     */               break;
/*     */ 
/*     */ 
/*     */             
/*     */             case null:
/* 364 */               if (this.mineTimer.hasReached(this.maxMineTime.getCurrent().intValue())) {
/* 365 */                 this.blocksNear.removeIf(v -> v.blockPos.equals(this.curBlockPos));
/* 366 */                 this.mineState = MineState.CHOOSE;
/*     */                 
/*     */                 break;
/*     */               } 
/*     */               
/* 371 */               ibs = mc.field_71441_e.func_180495_p(this.curBlockPos);
/* 372 */               if (ibs != null) {
/* 373 */                 if ((this.curBlock != null && ibs.func_177230_c() != this.curBlock) || ibs.func_177230_c() == Blocks.field_150357_h || ibs.func_177230_c() == Blocks.field_150350_a) {
/* 374 */                   this.blocksNear.removeIf(v -> v.blockPos.equals(this.curBlockPos));
/* 375 */                   this.mineState = MineState.CHOOSE;
/* 376 */                   this.curBlockPos = null;
/* 377 */                   this.curBlock = null;
/* 378 */                   this.startRot = null;
/* 379 */                   this.endRot = null;
/*     */                   break;
/*     */                 } 
/* 382 */                 if (!mc.field_71474_y.field_74312_F.func_151470_d() && mc.field_71462_r == null) {
/* 383 */                   mc.field_71415_G = true;
/* 384 */                   KeyBinding.func_74507_a(mc.field_71474_y.field_74312_F.func_151463_i());
/* 385 */                   KeyBinding.func_74510_a(mc.field_71474_y.field_74312_F.func_151463_i(), true);
/*     */                 } 
/*     */               } 
/*     */               break;
/*     */           } 
/*     */ 
/*     */           
/*     */           break;
/*     */         
/*     */         case LOOK:
/* 395 */           ChatUtils.send("Detected player in Island, re-warping", new String[0]);
/* 396 */           fsMsg = "/warp forge";
/*     */           break;
/*     */         
/*     */         case WARP:
/* 400 */           ChatUtils.send("Detected player in Hub, re-warping", new String[0]);
/* 401 */           fsMsg = "/warp forge";
/*     */           break;
/*     */         
/*     */         case null:
/* 405 */           ChatUtils.send("Detected player at Lift, re-warping", new String[0]);
/* 406 */           fsMsg = "/warp forge";
/*     */           break;
/*     */         
/*     */         case null:
/* 410 */           ChatUtils.send("Detected player in Lobby, re-warping", new String[0]);
/* 411 */           fsMsg = "/play skyblock";
/*     */           break;
/*     */         
/*     */         case null:
/* 415 */           ChatUtils.send("Detected player in Limbo, re-warping", new String[0]);
/* 416 */           fsMsg = "/l";
/*     */           break;
/*     */       } 
/*     */       
/* 420 */       if (curLoc != SkyblockUtils.Location.SKYBLOCK && 
/* 421 */         !this.miningSpot.getCurrent().equals("None") && !CF4M.INSTANCE.moduleManager.isEnabled("CommMacro")) {
/* 422 */         this.mineState = MineState.WARP_FORGE;
/* 423 */         mc.field_71439_g.func_71165_d(fsMsg);
/* 424 */         KeyBinding.func_74506_a();
/* 425 */         recoverTimer.reset();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @Event
/*     */   public void onRender(Render3DEvent event) {
/*     */     BlockPosWithVec next;
/* 433 */     for (BetterBlockPos bbp : new ArrayList(this.blocksNear)) {
/* 434 */       if (!bbp.blockPos.equals(this.curBlockPos)) {
/* 435 */         Render3DUtils.renderEspBox(bbp.blockPos, event.partialTicks, -16711681);
/*     */       }
/*     */     } 
/*     */     
/* 439 */     if (this.blocksNear.stream().anyMatch(v -> v.blockPos.equals(this.curBlockPos))) {
/* 440 */       Render3DUtils.renderEspBox(this.curBlockPos, event.partialTicks, -65536);
/*     */     }
/* 442 */     if (this.startRot != null && this.endRot != null) {
/* 443 */       Render3DUtils.drawLine(this.startRot, this.endRot, 1.0F, event.partialTicks);
/*     */     }
/* 445 */     if (this.startRot != null) {
/* 446 */       Render3DUtils.renderSmallBox(this.startRot, -16711936);
/*     */     }
/* 448 */     if (this.endRot != null) {
/* 449 */       Render3DUtils.renderSmallBox(this.endRot, -65536);
/*     */     }
/*     */     
/* 452 */     if (mc.field_71462_r != null)
/*     */       return; 
/* 454 */     if (this.mineState == MineState.NAVIGATING && path != null) {
/* 455 */       switch (this.warpState) {
/*     */         case SETUP:
/* 457 */           if (path.size() > 0) {
/* 458 */             if (warpTimer.hasReached(this.warpTime.getCurrent().intValue()) && !mc.field_71439_g.func_180425_c().equals(oldPos)) {
/* 459 */               PathPoint a = path.get(0);
/* 460 */               path.remove(0);
/* 461 */               RotationUtils.setup(RotationUtils.getRotation(new Vec3(a.x, a.y, a.z)), Long.valueOf(this.warpLookTime.getCurrent().intValue()));
/* 462 */               oldPos = mc.field_71439_g.func_180425_c();
/* 463 */               this.warpState = WarpState.LOOK; break;
/* 464 */             }  if (warpTimer.hasReached(2500L)) {
/* 465 */               ChatUtils.send("Got stuck while tp'ing, re-navigating", new String[0]);
/* 466 */               mc.field_71439_g.func_71165_d("/l");
/* 467 */               recoverTimer.reset();
/* 468 */               warpTimer.reset();
/*     */             }  break;
/*     */           } 
/* 471 */           if (!this.sneak.isEnabled()) {
/* 472 */             KeyBinding.func_74510_a(mc.field_71474_y.field_74311_E.func_151463_i(), false);
/*     */           }
/* 474 */           if (this.pickSlot.getCurrent().intValue() > 0 && this.pickSlot.getCurrent().intValue() <= 8) {
/* 475 */             mc.field_71439_g.field_71071_by.field_70461_c = this.pickSlot.getCurrent().intValue() - 1;
/*     */           }
/* 477 */           if (currentLocation.name.equals("REFUEL")) {
/* 478 */             this.mineState = MineState.REFUEL; break;
/*     */           } 
/* 480 */           this.mineState = MineState.CHOOSE;
/*     */           break;
/*     */ 
/*     */ 
/*     */         
/*     */         case LOOK:
/* 486 */           if (System.currentTimeMillis() <= RotationUtils.endTime) {
/* 487 */             RotationUtils.update(); break;
/*     */           } 
/* 489 */           RotationUtils.update();
/* 490 */           warpTimer.reset();
/* 491 */           this.warpState = WarpState.WARP;
/*     */           break;
/*     */ 
/*     */         
/*     */         case WARP:
/* 496 */           if (warpTimer.hasReached(this.warpTime.getCurrent().intValue())) {
/* 497 */             SkyblockUtils.silentUse(0, this.aotvSlot.getCurrent().intValue());
/* 498 */             warpTimer.reset();
/* 499 */             this.warpState = WarpState.SETUP;
/*     */           } 
/*     */           break;
/*     */       } 
/*     */     
/*     */     }
/* 505 */     switch (this.mineState) {
/*     */       case null:
/* 507 */         if (System.currentTimeMillis() <= RotationUtils.endTime) {
/* 508 */           RotationUtils.update(); break;
/*     */         } 
/* 510 */         if (!RotationUtils.done)
/* 511 */           RotationUtils.update(); 
/* 512 */         this.mineTimer.reset();
/*     */         
/* 514 */         next = getClosestBlock(this.curBlockPos);
/*     */         
/* 516 */         if (next != null) {
/* 517 */           Optional<BetterBlockPos> bbp = this.blocksNear.stream().filter(v -> v.blockPos.equals(this.curBlockPos)).findFirst();
/*     */           
/* 519 */           if (bbp.isPresent()) {
/* 520 */             List<Vec3> points = ((BetterBlockPos)bbp.get()).points;
/* 521 */             points.stream()
/* 522 */               .min(Comparator.comparing(v -> Float.valueOf(RotationUtils.getNeededChange(RotationUtils.getRotation(next.getVec3()), RotationUtils.getRotation(v)).getValue())))
/* 523 */               .ifPresent(nextPointOnSameBlock -> {
/*     */                   this.curBlock = mc.field_71441_e.func_180495_p(this.curBlockPos).func_177230_c();
/*     */                   this.endRot = nextPointOnSameBlock;
/*     */                   RotationUtils.setup(RotationUtils.getRotation(nextPointOnSameBlock), Long.valueOf(this.maxMineTime.getCurrent().intValue()));
/*     */                 });
/*     */           } 
/*     */         } 
/* 530 */         this.mineState = MineState.MINE;
/*     */         break;
/*     */ 
/*     */       
/*     */       case null:
/* 535 */         if (System.currentTimeMillis() <= RotationUtils.endTime) {
/* 536 */           RotationUtils.update(); break;
/*     */         } 
/* 538 */         this.startRot = null;
/* 539 */         this.endRot = null;
/* 540 */         if (!RotationUtils.done) {
/* 541 */           RotationUtils.update();
/*     */         }
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   @Event
/*     */   public void onChatReceived(ClientChatReceivedEvent event) {
/* 549 */     if (!CF4M.INSTANCE.moduleManager.isEnabled("CommMacro")) {
/* 550 */       String msg = event.message.func_150260_c();
/* 551 */       if (this.mineState == MineState.CHOOSE || this.mineState == MineState.LOOK || this.mineState == MineState.MINE) {
/* 552 */         if (msg.startsWith("Mining Speed Boost is now available!")) {
/* 553 */           mc.field_71442_b.func_78769_a((EntityPlayer)mc.field_71439_g, (World)mc.field_71441_e, mc.field_71439_g.func_70694_bm());
/* 554 */           boostTimer.reset();
/* 555 */         } else if (msg.startsWith("Your") && msg.contains("is empty! Refuel it by talking to a Drill Mechanic!")) {
/* 556 */           if (!this.miningSpot.getCurrent().equals("None")) {
/* 557 */             currentLocation = CommMacro.miningJson.locations.get(CommMacro.miningJson.locations.size() - 1);
/* 558 */             this.mineState = MineState.WARP_FORGE;
/*     */           } else {
/* 560 */             ChatUtils.send("Can't use Drill Refuel without a Mining Spot", new String[0]);
/* 561 */             CF4M.INSTANCE.moduleManager.toggle(this);
/*     */           } 
/*     */         } 
/*     */       }
/* 565 */       if (msg.contains("You can't fast travel while in combat!")) {
/* 566 */         mc.field_71439_g.func_71165_d("/l");
/* 567 */         recoverTimer.reset();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private List<String> getMiningSpotNames() {
/* 573 */     List<String> ret = new ArrayList<>();
/* 574 */     ret.add("None");
/* 575 */     ret.addAll((Collection<? extends String>)CommMacro.miningJson.locations.subList(0, CommMacro.miningJson.locations.size() - 5).stream()
/* 576 */         .map(v -> v.name)
/* 577 */         .collect(Collectors.toList()));
/* 578 */     return ret;
/*     */   }
/*     */   
/*     */   private void addBlockIfHittable(BlockPos xyz) {
/* 582 */     List<Vec3> pointsOnBlock = RotationUtils.getPointsOnBlock(xyz);
/*     */     
/* 584 */     for (Vec3 point : pointsOnBlock) {
/* 585 */       MovingObjectPosition mop = mc.field_71441_e.func_72933_a(mc.field_71439_g.func_174824_e(1.0F), point);
/*     */       
/* 587 */       if (mop != null && mop.field_72313_a == MovingObjectPosition.MovingObjectType.BLOCK && 
/* 588 */         mop.func_178782_a().equals(xyz) && point.func_72438_d(mc.field_71439_g.func_174824_e(1.0F)) < mc.field_71442_b.func_78757_d()) {
/* 589 */         if (this.blocksNear.stream().noneMatch(v -> v.blockPos.equals(xyz))) {
/* 590 */           this.blocksNear.add(new BetterBlockPos(xyz, new ArrayList<>(Collections.singletonList(point)))); continue;
/*     */         } 
/* 592 */         this.blocksNear.stream()
/* 593 */           .filter(v -> v.blockPos.equals(xyz))
/* 594 */           .findFirst()
/* 595 */           .ifPresent(v -> v.points.add(point));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private BlockPosWithVec getClosestBlock(BlockPos excluding) {
/* 603 */     BlockPos closest = null;
/* 604 */     Rotation closestRot = null;
/* 605 */     Vec3 closestPoint = null;
/*     */     
/* 607 */     List<BetterBlockPos> asd = new ArrayList<>(this.blocksNear);
/*     */     
/* 609 */     asd.removeIf(v -> v.blockPos.equals(excluding));
/*     */     
/* 611 */     List<BetterBlockPos> tits = new ArrayList<>();
/* 612 */     if (CommMacro.hugeTits) {
/* 613 */       asd.forEach(bbp -> {
/*     */             IBlockState bs = mc.field_71441_e.func_180495_p(bbp.blockPos);
/*     */             
/*     */             Block b = bs.func_177230_c();
/*     */             
/*     */             if (b == Blocks.field_150348_b && bs.func_177229_b((IProperty)BlockStone.field_176247_a) == BlockStone.EnumType.DIORITE_SMOOTH) {
/*     */               tits.add(bbp);
/*     */             }
/*     */           });
/* 622 */       if (!tits.isEmpty()) {
/* 623 */         asd = tits;
/*     */       }
/*     */     } 
/*     */     
/* 627 */     List<BetterBlockPos> miths = new ArrayList<>();
/* 628 */     if (CommMacro.mithril) {
/* 629 */       asd.forEach(bbp -> {
/*     */             IBlockState bs = mc.field_71441_e.func_180495_p(bbp.blockPos);
/*     */             
/*     */             Block b = bs.func_177230_c();
/*     */             
/*     */             if (b == Blocks.field_150325_L && bs.func_177229_b((IProperty)BlockColored.field_176581_a) == EnumDyeColor.GRAY) {
/*     */               miths.add(bbp);
/*     */             } else if (b == Blocks.field_150406_ce && bs.func_177229_b((IProperty)BlockColored.field_176581_a) == EnumDyeColor.CYAN) {
/*     */               miths.add(bbp);
/*     */             } 
/*     */           });
/* 640 */       if (!miths.isEmpty()) {
/* 641 */         asd = miths;
/*     */       }
/*     */     } 
/*     */     
/* 645 */     for (BetterBlockPos bbp : asd) {
/* 646 */       for (Vec3 point : bbp.points) {
/* 647 */         Rotation endRot = RotationUtils.getRotation(point);
/* 648 */         Rotation needed = RotationUtils.getNeededChange(endRot);
/*     */         
/* 650 */         if (closestRot != null && needed.getValue() >= closestRot.getValue())
/*     */           continue; 
/* 652 */         closest = bbp.blockPos;
/* 653 */         closestRot = needed;
/* 654 */         closestPoint = point;
/*     */       } 
/*     */     } 
/*     */     
/* 658 */     if (closest != null) {
/* 659 */       return new BlockPosWithVec(closest, closestPoint);
/*     */     }
/* 661 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void run() {
/* 666 */     while (!this.thread.isInterrupted() && mc.field_71439_g != null && mc.field_71441_e != null) {
/* 667 */       if (CF4M.INSTANCE.moduleManager.isEnabled(this)) {
/* 668 */         int radius = 6;
/*     */         
/* 670 */         int px = MathHelper.func_76128_c(mc.field_71439_g.field_70165_t);
/* 671 */         int py = MathHelper.func_76128_c(mc.field_71439_g.field_70163_u + 1.0D);
/* 672 */         int pz = MathHelper.func_76128_c(mc.field_71439_g.field_70161_v);
/* 673 */         Vec3 eyes = mc.field_71439_g.func_174824_e(1.0F);
/*     */         
/* 675 */         for (int x = px - radius; x < px + radius + 1; x++) {
/* 676 */           for (int y = py - radius; y < py + radius + 1; y++) {
/* 677 */             for (int z = pz - radius; z < pz + radius + 1; z++) {
/* 678 */               BlockPos xyz = new BlockPos(x, y, z);
/* 679 */               IBlockState bs = mc.field_71441_e.func_180495_p(xyz);
/*     */               
/* 681 */               if (this.blocksNear.stream().noneMatch(v -> v.blockPos.equals(xyz)) && !this.blacklist.contains(xyz)) {
/* 682 */                 Block block = bs.func_177230_c();
/* 683 */                 if (Math.sqrt(xyz.func_177957_d(eyes.field_72450_a, eyes.field_72448_b, eyes.field_72449_c)) <= 6.0D) {
/* 684 */                   if (block == Blocks.field_150325_L) {
/* 685 */                     if (bs.func_177229_b((IProperty)BlockColored.field_176581_a) == EnumDyeColor.LIGHT_BLUE) {
/* 686 */                       if (this.blueWool.isEnabled()) {
/* 687 */                         addBlockIfHittable(xyz);
/*     */                       }
/* 689 */                     } else if (bs.func_177229_b((IProperty)BlockColored.field_176581_a) == EnumDyeColor.GRAY && 
/* 690 */                       this.grayShit.isEnabled()) {
/* 691 */                       addBlockIfHittable(xyz);
/*     */                     }
/*     */                   
/* 694 */                   } else if (block == Blocks.field_180397_cI) {
/* 695 */                     if (this.prismarine.isEnabled()) {
/* 696 */                       addBlockIfHittable(xyz);
/*     */                     }
/* 698 */                   } else if (block == Blocks.field_150348_b) {
/* 699 */                     if (bs.func_177229_b((IProperty)BlockStone.field_176247_a) == BlockStone.EnumType.DIORITE_SMOOTH && 
/* 700 */                       this.titanium.isEnabled()) {
/* 701 */                       addBlockIfHittable(xyz);
/*     */                     }
/*     */                   }
/* 704 */                   else if (block == Blocks.field_150406_ce && 
/* 705 */                     bs.func_177229_b((IProperty)BlockColored.field_176581_a) == EnumDyeColor.CYAN && 
/* 706 */                     this.grayShit.isEnabled()) {
/* 707 */                     addBlockIfHittable(xyz);
/*     */                   } 
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 717 */         for (BetterBlockPos bbp : new ArrayList(this.blocksNear)) {
/* 718 */           IBlockState state = mc.field_71441_e.func_180495_p(bbp.blockPos);
/* 719 */           Block block = null;
/*     */           
/* 721 */           if (state != null) {
/* 722 */             block = state.func_177230_c();
/*     */           }
/*     */           
/* 725 */           if (Math.sqrt(bbp.blockPos.func_177957_d(eyes.field_72450_a, eyes.field_72448_b, eyes.field_72449_c)) > 5.0D || block == Blocks.field_150357_h || block == Blocks.field_150350_a) {
/* 726 */             this.blocksNear.remove(bbp);
/*     */           }
/*     */         } 
/*     */         
/*     */         try {
/* 731 */           Thread.sleep(this.delayMs);
/* 732 */         } catch (InterruptedException e) {
/* 733 */           e.printStackTrace();
/*     */         }  continue;
/*     */       } 
/* 736 */       this.thread.interrupt();
/*     */     } 
/*     */ 
/*     */     
/* 740 */     this.thread = null;
/*     */   }
/*     */   
/*     */   private static class BetterBlockPos {
/*     */     BlockPos blockPos;
/*     */     List<Vec3> points;
/*     */     
/*     */     public BetterBlockPos(BlockPos blockPos, List<Vec3> points) {
/* 748 */       this.blockPos = blockPos;
/* 749 */       this.points = points;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class BlockPosWithVec {
/*     */     private BlockPos blockPos;
/*     */     private Vec3 vec3;
/*     */     
/*     */     public BlockPosWithVec(BlockPos blockPos, Vec3 vec3) {
/* 758 */       this.blockPos = blockPos;
/* 759 */       this.vec3 = vec3;
/*     */     }
/*     */     
/*     */     public BlockPos getBlockPos() {
/* 763 */       return this.blockPos;
/*     */     }
/*     */     
/*     */     public Vec3 getVec3() {
/* 767 */       return this.vec3;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\modules\world\AutoMithril.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */