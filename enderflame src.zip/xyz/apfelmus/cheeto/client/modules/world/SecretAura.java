/*     */ package xyz.apfelmus.cheeto.client.modules.world;
/*     */ import com.mojang.authlib.GameProfile;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.tileentity.TileEntityChest;
/*     */ import net.minecraft.tileentity.TileEntitySkull;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraftforge.event.entity.player.PlayerInteractEvent;
/*     */ import xyz.apfelmus.cf4m.CF4M;
/*     */ import xyz.apfelmus.cf4m.annotation.Event;
/*     */ import xyz.apfelmus.cf4m.annotation.Setting;
/*     */ import xyz.apfelmus.cheeto.client.events.ClientChatReceivedEvent;
/*     */ import xyz.apfelmus.cheeto.client.events.ClientTickEvent;
/*     */ import xyz.apfelmus.cheeto.client.events.PlayerInteractEvent;
/*     */ import xyz.apfelmus.cheeto.client.events.Render3DEvent;
/*     */ import xyz.apfelmus.cheeto.client.settings.BooleanSetting;
/*     */ import xyz.apfelmus.cheeto.client.settings.FloatSetting;
/*     */ import xyz.apfelmus.cheeto.client.settings.IntegerSetting;
/*     */ import xyz.apfelmus.cheeto.client.utils.client.RotationUtils;
/*     */ import xyz.apfelmus.cheeto.client.utils.render.Render3DUtils;
/*     */ import xyz.apfelmus.cheeto.client.utils.skyblock.SkyblockUtils;
/*     */ 
/*     */ @Module(name = "SecretAura", category = Category.WORLD)
/*     */ public class SecretAura implements Runnable {
/*     */   @Setting(name = "ScanRange")
/*  34 */   private IntegerSetting scanRange = new IntegerSetting(
/*  35 */       Integer.valueOf(7), Integer.valueOf(0), Integer.valueOf(8)); @Setting(name = "ClickRange")
/*  36 */   private FloatSetting clickRange = new FloatSetting(
/*  37 */       Float.valueOf(5.0F), Float.valueOf(0.0F), Float.valueOf(8.0F)); @Setting(name = "ClickSlot")
/*  38 */   private IntegerSetting clickSlot = new IntegerSetting(
/*  39 */       Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(8)); @Setting(name = "Chests")
/*  40 */   private BooleanSetting chests = new BooleanSetting(true);
/*     */   @Setting(name = "ChestClose")
/*  42 */   private BooleanSetting chestClose = new BooleanSetting(true);
/*     */   @Setting(name = "Levers")
/*  44 */   private BooleanSetting levers = new BooleanSetting(true);
/*     */   @Setting(name = "Essences")
/*  46 */   private BooleanSetting essences = new BooleanSetting(true);
/*     */   @Setting(name = "StonklessStonk")
/*  48 */   private BooleanSetting stonklessStonk = new BooleanSetting(true);
/*     */ 
/*     */   
/*  51 */   private static Minecraft mc = Minecraft.func_71410_x();
/*  52 */   private static List<BlockPos> clicked = new ArrayList<>();
/*  53 */   private int delayMs = 500;
/*     */   private Thread thread;
/*  55 */   private List<BlockPos> blocksNear = new ArrayList<>();
/*     */   
/*     */   private boolean inChest = false;
/*     */   private BlockPos selected;
/*     */   private static BlockPos lastPos;
/*     */   
/*     */   @Enable
/*     */   public void onEnable() {
/*  63 */     this.blocksNear.clear();
/*  64 */     clicked.clear();
/*  65 */     this.inChest = false;
/*  66 */     this.selected = null;
/*  67 */     lastPos = null;
/*     */   }
/*     */   
/*     */   @Event
/*     */   public void onTick(ClientTickEvent event) {
/*  72 */     if ((this.thread == null || !this.thread.isAlive()) && mc.field_71441_e != null && mc.field_71439_g != null && SkyblockUtils.isInDungeon()) {
/*  73 */       (this.thread = new Thread(this)).setDaemon(false);
/*  74 */       this.thread.setPriority(1);
/*  75 */       this.thread.start();
/*     */     } 
/*     */     
/*  78 */     if (mc.field_71441_e != null && mc.field_71439_g != null && this.thread != null) {
/*  79 */       if (!this.stonklessStonk.isEnabled()) {
/*  80 */         if (!this.inChest) {
/*  81 */           Vec3 eyes = mc.field_71439_g.func_174824_e(1.0F);
/*  82 */           for (BlockPos bp : new ArrayList(this.blocksNear)) {
/*  83 */             if (Math.sqrt(bp.func_177957_d(eyes.field_72450_a, eyes.field_72448_b, eyes.field_72449_c)) < this.clickRange.getCurrent().floatValue()) {
/*  84 */               IBlockState bs = mc.field_71441_e.func_180495_p(bp);
/*  85 */               if (bs != null) {
/*  86 */                 if (bs.func_177230_c() == Blocks.field_150486_ae) {
/*  87 */                   this.inChest = true;
/*     */                 }
/*  89 */                 handleClick(bp); break;
/*     */               } 
/*  91 */               this.blocksNear.remove(bp);
/*  92 */               clicked.add(bp);
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } else {
/*  99 */         clicked.clear();
/*     */       } 
/*     */       
/* 102 */       if (SkyblockUtils.isInDungeon() && this.inChest && this.chestClose.isEnabled()) {
/* 103 */         if (mc.field_71462_r instanceof net.minecraft.client.gui.inventory.GuiChest) {
/* 104 */           mc.field_71439_g.func_71053_j();
/* 105 */           this.inChest = false;
/*     */         } 
/*     */       } else {
/* 108 */         this.inChest = false;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @Event
/*     */   public void onRender(Render3DEvent event) {
/* 115 */     this.selected = null;
/* 116 */     for (BlockPos bp : new ArrayList(this.blocksNear)) {
/* 117 */       if (this.selected == null && RotationUtils.lookingAt(bp, this.clickRange.getCurrent().floatValue())) {
/* 118 */         this.selected = bp;
/*     */         
/*     */         continue;
/*     */       } 
/* 122 */       Render3DUtils.renderEspBox(bp, event.partialTicks, -1754827);
/*     */     } 
/*     */     
/* 125 */     if (this.selected != null) {
/* 126 */       Render3DUtils.renderEspBox(this.selected, event.partialTicks, -19712);
/*     */     }
/*     */   }
/*     */   
/*     */   @Event
/*     */   public void onInteract(PlayerInteractEvent event) {
/* 132 */     if (this.stonklessStonk.isEnabled() && 
/* 133 */       this.selected != null && !clicked.contains(this.selected)) {
/* 134 */       MovingObjectPosition omo = mc.field_71476_x;
/* 135 */       if (omo != null && 
/* 136 */         omo.field_72313_a == MovingObjectPosition.MovingObjectType.BLOCK && omo.func_178782_a().equals(this.selected)) {
/*     */         return;
/*     */       }
/*     */       
/* 140 */       if (event.action == PlayerInteractEvent.Action.RIGHT_CLICK_AIR || event.action == PlayerInteractEvent.Action.RIGHT_CLICK_BLOCK) {
/* 141 */         clicked.add(this.selected);
/* 142 */         handleClick(this.selected);
/* 143 */         mc.field_71439_g.func_71038_i();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Event
/*     */   public void onWorldLoad(WorldUnloadEvent event) {
/* 151 */     clicked.clear();
/* 152 */     this.inChest = false;
/*     */   }
/*     */   
/*     */   @Event
/*     */   public void onChat(ClientChatReceivedEvent event) {
/* 157 */     if (event.message.func_150260_c().contains("locked")) {
/* 158 */       clicked.clear();
/* 159 */       this.inChest = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void run() {
/* 165 */     while (!this.thread.isInterrupted()) {
/* 166 */       BlockPos curPos = mc.field_71439_g.func_180425_c();
/* 167 */       if (CF4M.INSTANCE.moduleManager.isEnabled(this)) {
/* 168 */         if (SkyblockUtils.isInDungeon() && !curPos.equals(lastPos)) {
/* 169 */           lastPos = curPos;
/*     */           
/* 171 */           int radius = this.scanRange.getCurrent().intValue();
/*     */           
/* 173 */           int px = MathHelper.func_76128_c(mc.field_71439_g.field_70165_t);
/* 174 */           int py = MathHelper.func_76128_c(mc.field_71439_g.field_70163_u + 1.0D);
/* 175 */           int pz = MathHelper.func_76128_c(mc.field_71439_g.field_70161_v);
/* 176 */           Vec3 eyes = mc.field_71439_g.func_174824_e(1.0F);
/*     */           
/* 178 */           for (int x = px - radius; x < px + radius + 1; x++) {
/* 179 */             for (int y = py - radius; y < py + radius + 1; y++) {
/* 180 */               for (int z = pz - radius; z < pz + radius + 1; z++) {
/* 181 */                 BlockPos xyz = new BlockPos(x, y, z);
/* 182 */                 IBlockState bs = mc.field_71441_e.func_180495_p(xyz);
/* 183 */                 Block block = bs.func_177230_c();
/*     */                 
/* 185 */                 if (!clicked.contains(xyz) && !this.blocksNear.contains(xyz) && Math.sqrt(xyz.func_177957_d(eyes.field_72450_a, eyes.field_72448_b, eyes.field_72449_c)) <= this.scanRange.getCurrent().intValue()) {
/* 186 */                   if (this.chests.isEnabled() && block instanceof net.minecraft.block.BlockChest) {
/* 187 */                     TileEntityChest te = (TileEntityChest)mc.field_71441_e.func_175625_s(xyz);
/*     */                     
/* 189 */                     if (te.field_145989_m == 0.0F) {
/* 190 */                       this.blocksNear.add(xyz);
/*     */                     }
/*     */                   } 
/* 193 */                   if (this.levers.isEnabled() && block instanceof net.minecraft.block.BlockLever) {
/* 194 */                     this.blocksNear.add(xyz);
/*     */                   }
/* 196 */                   if (this.essences.isEnabled() && block instanceof net.minecraft.block.BlockSkull) {
/* 197 */                     TileEntitySkull te = (TileEntitySkull)mc.field_71441_e.func_175625_s(xyz);
/* 198 */                     GameProfile gp = te.func_152108_a();
/*     */                     
/* 200 */                     if (gp != null) {
/* 201 */                       BlockPos bp = te.func_174877_v();
/* 202 */                       if (bp != null && 
/* 203 */                         gp.getId().toString().equals("26bb1a8d-7c66-31c6-82d5-a9c04c94fb02")) {
/* 204 */                         this.blocksNear.add(xyz);
/*     */                       }
/*     */                     } 
/*     */                   } 
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 214 */           List<BlockPos> blocksToRemove = new ArrayList<>();
/*     */           
/* 216 */           for (BlockPos bp : this.blocksNear) {
/* 217 */             IBlockState state = mc.field_71441_e.func_180495_p(bp);
/* 218 */             Block block = null;
/*     */             
/* 220 */             if (state != null) {
/* 221 */               block = state.func_177230_c();
/*     */             }
/*     */             
/* 224 */             if (Math.sqrt(bp.func_177957_d(eyes.field_72450_a, eyes.field_72448_b, eyes.field_72449_c)) > this.scanRange.getCurrent().intValue() || block == Blocks.field_150350_a) {
/* 225 */               blocksToRemove.add(bp);
/*     */             }
/*     */           } 
/*     */           
/* 229 */           this.blocksNear.removeAll(blocksToRemove);
/*     */         } 
/*     */         
/*     */         try {
/* 233 */           Thread.sleep(this.delayMs);
/* 234 */         } catch (InterruptedException e) {
/* 235 */           e.printStackTrace();
/*     */         }  continue;
/*     */       } 
/* 238 */       this.thread.interrupt();
/*     */     } 
/*     */ 
/*     */     
/* 242 */     this.thread = null;
/*     */   }
/*     */   
/*     */   private void handleClick(BlockPos xyz) {
/* 246 */     if (this.clickSlot.getCurrent().intValue() != 0) {
/* 247 */       int holding = mc.field_71439_g.field_71071_by.field_70461_c;
/* 248 */       mc.field_71439_g.field_71071_by.field_70461_c = this.clickSlot.getCurrent().intValue();
/* 249 */       mc.field_71442_b.func_178890_a(mc.field_71439_g, mc.field_71441_e, mc.field_71439_g.field_71071_by.func_70448_g(), xyz, EnumFacing.func_176733_a(RotationUtils.getRotation(xyz).getYaw()), mc.field_71476_x.field_72307_f);
/* 250 */       mc.field_71439_g.field_71071_by.field_70461_c = holding;
/*     */     } else {
/* 252 */       mc.field_71442_b.func_178890_a(mc.field_71439_g, mc.field_71441_e, mc.field_71439_g.field_71071_by.func_70448_g(), xyz, EnumFacing.func_176733_a(RotationUtils.getRotation(xyz).getYaw()), mc.field_71476_x.field_72307_f);
/*     */     } 
/* 254 */     if (!this.stonklessStonk.isEnabled()) {
/* 255 */       this.blocksNear.remove(xyz);
/* 256 */       clicked.add(xyz);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\modules\world\SecretAura.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */