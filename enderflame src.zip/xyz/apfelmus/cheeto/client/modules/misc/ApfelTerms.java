/*     */ package xyz.apfelmus.cheeto.client.modules.misc;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.inventory.Container;
/*     */ import net.minecraft.inventory.ContainerChest;
/*     */ import net.minecraft.inventory.Slot;
/*     */ import net.minecraft.item.EnumDyeColor;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.StringUtils;
/*     */ import xyz.apfelmus.cf4m.annotation.Event;
/*     */ import xyz.apfelmus.cf4m.annotation.Setting;
/*     */ import xyz.apfelmus.cf4m.annotation.module.Module;
/*     */ import xyz.apfelmus.cheeto.client.events.BackgroundDrawnEvent;
/*     */ import xyz.apfelmus.cheeto.client.events.ClientTickEvent;
/*     */ import xyz.apfelmus.cheeto.client.settings.BooleanSetting;
/*     */ import xyz.apfelmus.cheeto.client.settings.IntegerSetting;
/*     */ import xyz.apfelmus.cheeto.client.utils.skyblock.SkyblockUtils;
/*     */ 
/*     */ @Module(name = "ApfelTerms", category = Category.MISC)
/*     */ public class ApfelTerms {
/*     */   @Setting(name = "Delay")
/*  27 */   private IntegerSetting delay = new IntegerSetting(
/*  28 */       Integer.valueOf(150), Integer.valueOf(0), Integer.valueOf(1000)); @Setting(name = "RandomRange")
/*  29 */   private IntegerSetting randomRange = new IntegerSetting(
/*  30 */       Integer.valueOf(100), Integer.valueOf(0), Integer.valueOf(1000)); @Setting(name = "MaxLag", description = "Set to something slightly above your ping")
/*  31 */   private IntegerSetting maxLag = new IntegerSetting(
/*  32 */       Integer.valueOf(250), Integer.valueOf(0), Integer.valueOf(1000)); @Setting(name = "Maze")
/*  33 */   BooleanSetting maze = new BooleanSetting(true);
/*     */   @Setting(name = "Order")
/*  35 */   BooleanSetting order = new BooleanSetting(true);
/*     */   @Setting(name = "Panes")
/*  37 */   BooleanSetting panes = new BooleanSetting(true);
/*     */   @Setting(name = "Name")
/*  39 */   BooleanSetting name = new BooleanSetting(true);
/*     */   @Setting(name = "Color")
/*  41 */   BooleanSetting color = new BooleanSetting(true);
/*     */   @Setting(name = "Pingless")
/*  43 */   BooleanSetting pingless = new BooleanSetting(true);
/*     */ 
/*     */   
/*  46 */   private static Terminal currentTerm = Terminal.NONE;
/*  47 */   private static List<TermSlot> clickQueue = new ArrayList<>();
/*     */   
/*     */   private static boolean recalculate = false;
/*  50 */   private static final int[] mazeDirection = new int[] { -9, -1, 1, 9 };
/*  51 */   private static char letterNeeded = Character.MIN_VALUE;
/*  52 */   private static String colorNeeded = null;
/*     */   
/*     */   private static int windowId;
/*     */   private static long lastClickTime;
/*  56 */   private static int windowClicks = 0;
/*  57 */   private static int currentSlot = 0;
/*     */   
/*  59 */   private static Minecraft mc = Minecraft.func_71410_x();
/*     */   
/*     */   private enum Terminal {
/*  62 */     NONE,
/*  63 */     MAZE,
/*  64 */     ORDER,
/*  65 */     PANES,
/*  66 */     NAME,
/*  67 */     COLOR;
/*     */   }
/*     */   
/*     */   @Event
/*     */   public void onGuiDraw(BackgroundDrawnEvent event) {
/*  72 */     if (!SkyblockUtils.isInDungeon())
/*     */       return; 
/*  74 */     if (event.gui instanceof GuiChest) {
/*  75 */       Container container = ((GuiChest)event.gui).field_147002_h;
/*     */       
/*  77 */       if (container instanceof ContainerChest) {
/*  78 */         List<Slot> invSlots = container.field_75151_b;
/*     */         
/*  80 */         if (currentTerm == Terminal.NONE) {
/*  81 */           String chestName = ((ContainerChest)container).func_85151_d().func_145748_c_().func_150260_c();
/*     */           
/*  83 */           if (chestName.equals("Navigate the maze!")) {
/*  84 */             currentTerm = Terminal.MAZE;
/*  85 */           } else if (chestName.equals("Click in order!")) {
/*  86 */             currentTerm = Terminal.ORDER;
/*  87 */           } else if (chestName.equals("Correct all the panes!")) {
/*  88 */             currentTerm = Terminal.PANES;
/*  89 */           } else if (chestName.startsWith("What starts with:")) {
/*  90 */             currentTerm = Terminal.NAME;
/*  91 */           } else if (chestName.startsWith("Select all the")) {
/*  92 */             currentTerm = Terminal.COLOR;
/*     */           } 
/*     */         } else {
/*  95 */           if (clickQueue.isEmpty() || recalculate) {
/*  96 */             recalculate = getClicks((ContainerChest)container);
/*     */           } else {
/*  98 */             switch (currentTerm) {
/*     */               
/*     */               case MAZE:
/*     */               case ORDER:
/*     */               case PANES:
/* 103 */                 for (TermSlot slot : clickQueue) {
/* 104 */                   if (slot.clicked > 0L && System.currentTimeMillis() - slot.clicked >= this.maxLag.getCurrent().intValue()) {
/* 105 */                     Slot s = invSlots.get(slot.slot.field_75222_d);
/* 106 */                     if (s.func_75216_d() && s.func_75211_c().func_77952_i() != 5) {
/* 107 */                       currentSlot = clickQueue.indexOf(slot);
/* 108 */                       windowClicks = currentSlot;
/*     */                       break;
/*     */                     } 
/*     */                   } 
/*     */                 } 
/*     */                 break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               case NAME:
/*     */               case COLOR:
/* 124 */                 for (TermSlot slot : clickQueue) {
/* 125 */                   if (slot.clicked > 0L && System.currentTimeMillis() - slot.clicked >= this.maxLag.getCurrent().intValue()) {
/* 126 */                     Slot s = invSlots.get(slot.slot.field_75222_d);
/* 127 */                     if (s.func_75216_d() && !s.func_75211_c().func_77948_v()) {
/* 128 */                       currentSlot = clickQueue.indexOf(slot);
/* 129 */                       windowClicks = currentSlot;
/*     */                       break;
/*     */                     } 
/*     */                   } 
/*     */                 } 
/*     */                 break;
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           } 
/* 143 */           if (!clickQueue.isEmpty() && currentSlot < clickQueue.size() && (System.currentTimeMillis() - lastClickTime) >= this.randomRange.getCurrent().intValue() / 2.0D - Math.random() * this.randomRange.getCurrent().intValue() + this.delay.getCurrent().intValue()) {
/* 144 */             switch (currentTerm) {
/*     */               case MAZE:
/* 146 */                 if (this.maze.isEnabled()) {
/* 147 */                   clickSlot(clickQueue.get(currentSlot));
/*     */                 }
/*     */                 break;
/*     */               
/*     */               case ORDER:
/* 152 */                 if (this.order.isEnabled()) {
/* 153 */                   clickSlot(clickQueue.get(currentSlot));
/*     */                 }
/*     */                 break;
/*     */               
/*     */               case PANES:
/* 158 */                 if (this.panes.isEnabled()) {
/* 159 */                   clickSlot(clickQueue.get(currentSlot));
/*     */                 }
/*     */                 break;
/*     */               
/*     */               case NAME:
/* 164 */                 if (this.name.isEnabled()) {
/* 165 */                   clickSlot(clickQueue.get(currentSlot));
/*     */                 }
/*     */                 break;
/*     */               
/*     */               case COLOR:
/* 170 */                 if (this.color.isEnabled()) {
/* 171 */                   clickSlot(clickQueue.get(currentSlot));
/*     */                 }
/*     */                 break;
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @Event
/*     */   public void onTick(ClientTickEvent event) {
/* 183 */     if (!SkyblockUtils.isInDungeon())
/*     */       return; 
/* 185 */     if (!(mc.field_71462_r instanceof GuiChest)) {
/* 186 */       currentTerm = Terminal.NONE;
/* 187 */       clickQueue.clear();
/* 188 */       letterNeeded = Character.MIN_VALUE;
/* 189 */       colorNeeded = null;
/* 190 */       windowClicks = 0;
/* 191 */       currentSlot = 0;
/*     */     }  } private static boolean getClicks(ContainerChest cc) {
/*     */     int startSlot, endSlot;
/*     */     boolean[] mazeVisited;
/*     */     int j;
/* 196 */     List<Slot> invSlots = cc.field_75151_b;
/* 197 */     String chestName = cc.func_85151_d().func_145748_c_().func_150260_c();
/* 198 */     clickQueue.clear();
/*     */     
/* 200 */     switch (currentTerm) {
/*     */       case MAZE:
/* 202 */         startSlot = -1;
/* 203 */         endSlot = -1;
/* 204 */         mazeVisited = new boolean[54];
/*     */         
/* 206 */         for (Slot slot : invSlots) {
/* 207 */           if (startSlot >= 0 && endSlot >= 0)
/* 208 */             break;  if (slot.field_75224_c == mc.field_71439_g.field_71071_by)
/* 209 */             continue;  ItemStack stack = slot.func_75211_c();
/* 210 */           if (stack == null || 
/* 211 */             stack.func_77973_b() != Item.func_150898_a((Block)Blocks.field_150397_co))
/* 212 */             continue;  if (stack.func_77952_i() == 5) { startSlot = slot.field_75222_d; continue; }
/*     */           
/* 214 */           if (stack.func_77952_i() != 14)
/* 215 */             continue;  endSlot = slot.field_75222_d;
/*     */         } 
/*     */         
/* 218 */         while (startSlot != endSlot) {
/* 219 */           boolean newSlotChosen = false;
/*     */           
/* 221 */           for (int i = 0; i < 4; i++) {
/* 222 */             int slotNumber = startSlot + mazeDirection[i];
/* 223 */             if (slotNumber == endSlot) return false; 
/* 224 */             if (slotNumber >= 0 && slotNumber <= 53 && (i != 1 || slotNumber % 9 != 8) && (
/* 225 */               i != 2 || slotNumber % 9 != 0) && 
/* 226 */               !mazeVisited[slotNumber]) {
/* 227 */               ItemStack stack = ((Slot)invSlots.get(slotNumber)).func_75211_c();
/* 228 */               if (stack != null && 
/* 229 */                 stack.func_77973_b() == Item.func_150898_a((Block)Blocks.field_150397_co) && stack.func_77952_i() == 0) {
/* 230 */                 clickQueue.add(new TermSlot(invSlots.get(slotNumber)));
/* 231 */                 startSlot = slotNumber;
/* 232 */                 mazeVisited[slotNumber] = true;
/* 233 */                 newSlotChosen = true;
/*     */ 
/*     */                 
/*     */                 break;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 242 */           if (!newSlotChosen) {
/* 243 */             return true;
/*     */           }
/*     */         } 
/*     */         break;
/*     */ 
/*     */       
/*     */       case ORDER:
/* 250 */         while (clickQueue.size() < 14) {
/* 251 */           clickQueue.add((TermSlot)null);
/*     */         }
/* 253 */         for (j = 10; j <= 25; j++) {
/* 254 */           if (j != 17 && 
/* 255 */             j != 18) {
/* 256 */             ItemStack itemStack3 = ((Slot)invSlots.get(j)).func_75211_c();
/* 257 */             if (itemStack3 != null && 
/* 258 */               itemStack3.func_77973_b() == Item.func_150898_a((Block)Blocks.field_150397_co) && itemStack3.func_77952_i() == 14 && itemStack3.field_77994_a < 15) {
/* 259 */               clickQueue.set(itemStack3.field_77994_a - 1, new TermSlot(invSlots.get(j)));
/*     */             }
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 265 */         if (clickQueue.removeIf(Objects::isNull)) {
/* 266 */           return true;
/*     */         }
/*     */         break;
/*     */       
/*     */       case PANES:
/* 271 */         for (Slot slot : invSlots) {
/* 272 */           if (slot.field_75224_c == mc.field_71439_g.field_71071_by) {
/*     */             continue;
/*     */           }
/* 275 */           if (slot.field_75222_d < 9 || slot.field_75222_d > 35 || slot.field_75222_d % 9 <= 1) {
/*     */             continue;
/*     */           }
/* 278 */           if (slot.field_75222_d % 9 >= 7) {
/*     */             continue;
/*     */           }
/* 281 */           ItemStack itemStack = slot.func_75211_c();
/* 282 */           if (itemStack == null) {
/* 283 */             return true;
/*     */           }
/* 285 */           if (itemStack.func_77973_b() != Item.func_150898_a((Block)Blocks.field_150397_co) || itemStack.func_77952_i() != 14) {
/*     */             continue;
/*     */           }
/* 288 */           clickQueue.add(new TermSlot(slot));
/*     */         } 
/*     */         break;
/*     */       
/*     */       case NAME:
/* 293 */         letterNeeded = chestName.charAt(chestName.indexOf("'") + 1);
/* 294 */         if (letterNeeded != '\000') {
/* 295 */           for (Slot slot : invSlots) {
/* 296 */             if (slot.field_75224_c == mc.field_71439_g.field_71071_by) {
/*     */               continue;
/*     */             }
/* 299 */             if (slot.field_75222_d < 9 || slot.field_75222_d > 44 || slot.field_75222_d % 9 == 0) {
/*     */               continue;
/*     */             }
/* 302 */             if (slot.field_75222_d % 9 == 8) {
/*     */               continue;
/*     */             }
/* 305 */             ItemStack itemStack = slot.func_75211_c();
/* 306 */             if (itemStack == null) {
/* 307 */               return true;
/*     */             }
/* 309 */             if (itemStack.func_77948_v()) {
/*     */               continue;
/*     */             }
/* 312 */             if (StringUtils.func_76338_a(itemStack.func_82833_r()).charAt(0) != letterNeeded) {
/*     */               continue;
/*     */             }
/* 315 */             clickQueue.add(new TermSlot(slot));
/*     */           } 
/*     */         }
/*     */         break;
/*     */ 
/*     */       
/*     */       case COLOR:
/* 322 */         for (EnumDyeColor color : EnumDyeColor.values()) {
/* 323 */           String colorName = color.func_176610_l().replaceAll("_", " ").toUpperCase();
/* 324 */           if (chestName.contains(colorName)) {
/* 325 */             colorNeeded = color.func_176762_d();
/*     */             break;
/*     */           } 
/*     */         } 
/* 329 */         if (colorNeeded != null) {
/* 330 */           for (Slot slot : invSlots) {
/* 331 */             if (slot.field_75224_c == mc.field_71439_g.field_71071_by) {
/*     */               continue;
/*     */             }
/* 334 */             if (slot.field_75222_d < 9 || slot.field_75222_d > 44 || slot.field_75222_d % 9 == 0) {
/*     */               continue;
/*     */             }
/* 337 */             if (slot.field_75222_d % 9 == 8) {
/*     */               continue;
/*     */             }
/* 340 */             ItemStack itemStack = slot.func_75211_c();
/* 341 */             if (itemStack == null) {
/* 342 */               return true;
/*     */             }
/* 344 */             if (itemStack.func_77948_v()) {
/*     */               continue;
/*     */             }
/* 347 */             if (!itemStack.func_77977_a().contains(colorNeeded)) {
/*     */               continue;
/*     */             }
/* 350 */             clickQueue.add(new TermSlot(slot));
/*     */           } 
/*     */         }
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 357 */     return false;
/*     */   }
/*     */   
/*     */   private void clickSlot(TermSlot slot) {
/* 361 */     if (windowClicks == 0) {
/* 362 */       windowId = mc.field_71439_g.field_71070_bA.field_75152_c;
/*     */     }
/* 364 */     mc.field_71442_b.func_78753_a(windowId + (this.pingless.isEnabled() ? windowClicks : 0), slot.slot.field_75222_d, 2, 0, (EntityPlayer)mc.field_71439_g);
/*     */     
/* 366 */     slot.clicked = System.currentTimeMillis();
/* 367 */     lastClickTime = System.currentTimeMillis();
/* 368 */     currentSlot++;
/* 369 */     if (this.pingless.isEnabled())
/* 370 */       windowClicks++; 
/*     */   }
/*     */   
/*     */   private static class TermSlot
/*     */   {
/*     */     public Slot slot;
/*     */     public long clicked;
/*     */     
/*     */     public TermSlot(Slot slot) {
/* 379 */       this.slot = slot;
/* 380 */       this.clicked = -1L;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 385 */       return this.slot.field_75222_d + " - " + this.clicked;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\modules\misc\ApfelTerms.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */