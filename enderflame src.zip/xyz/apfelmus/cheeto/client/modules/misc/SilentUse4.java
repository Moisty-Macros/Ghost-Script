/*    */ package xyz.apfelmus.cheeto.client.modules.misc;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import xyz.apfelmus.cf4m.CF4M;
/*    */ import xyz.apfelmus.cf4m.annotation.Event;
/*    */ import xyz.apfelmus.cf4m.annotation.Setting;
/*    */ import xyz.apfelmus.cf4m.annotation.module.Disable;
/*    */ import xyz.apfelmus.cf4m.annotation.module.Enable;
/*    */ import xyz.apfelmus.cf4m.annotation.module.Module;
/*    */ import xyz.apfelmus.cf4m.module.Category;
/*    */ import xyz.apfelmus.cheeto.client.events.ClientTickEvent;
/*    */ import xyz.apfelmus.cheeto.client.settings.BooleanSetting;
/*    */ import xyz.apfelmus.cheeto.client.settings.IntegerSetting;
/*    */ import xyz.apfelmus.cheeto.client.utils.client.Flags;
/*    */ import xyz.apfelmus.cheeto.client.utils.client.KeybindUtils;
/*    */ import xyz.apfelmus.cheeto.client.utils.skyblock.SkyblockUtils;
/*    */ 
/*    */ @Module(name = "SilentUse4", category = Category.MISC)
/*    */ public class SilentUse4 {
/*    */   @Setting(name = "MainSlot")
/* 20 */   private IntegerSetting mainSlot = new IntegerSetting(
/* 21 */       Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(8)); @Setting(name = "UseSlot")
/* 22 */   private IntegerSetting useSlot = new IntegerSetting(
/* 23 */       Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(8)); @Setting(name = "LeftClick")
/* 24 */   private BooleanSetting leftClick = new BooleanSetting(false);
/*    */ 
/*    */   
/* 27 */   private static Minecraft mc = Minecraft.func_71410_x();
/*    */   
/*    */   private static boolean leftFlag = false;
/* 30 */   private static int ticks = 0;
/*    */   
/*    */   @Enable
/*    */   public void onEnable() {
/* 34 */     Flags.silentUsing = true;
/* 35 */     if (this.leftClick.isEnabled()) {
/* 36 */       if (this.useSlot.getCurrent().intValue() > 0 && this.useSlot.getCurrent().intValue() <= 8) {
/* 37 */         mc.field_71439_g.field_71071_by.field_70461_c = this.useSlot.getCurrent().intValue() - 1;
/* 38 */         leftFlag = true;
/*    */       } 
/*    */     } else {
/* 41 */       SkyblockUtils.silentUse(this.mainSlot.getCurrent().intValue(), this.useSlot.getCurrent().intValue());
/* 42 */       CF4M.INSTANCE.moduleManager.toggle(this);
/*    */     } 
/*    */   }
/*    */   
/*    */   @Disable
/*    */   public void onDisable() {
/* 48 */     Flags.silentUsing = false;
/*    */   }
/*    */   
/*    */   @Event
/*    */   public void onTick(ClientTickEvent event) {
/* 53 */     if (leftFlag) {
/* 54 */       ticks++;
/* 55 */       if (ticks == 2) {
/* 56 */         KeybindUtils.leftClick();
/* 57 */       } else if (ticks > 2) {
/* 58 */         if (this.mainSlot.getCurrent().intValue() > 0 && this.mainSlot.getCurrent().intValue() <= 8) {
/* 59 */           mc.field_71439_g.field_71071_by.field_70461_c = this.mainSlot.getCurrent().intValue() - 1;
/*    */         }
/* 61 */         leftFlag = false;
/* 62 */         ticks = 0;
/* 63 */         CF4M.INSTANCE.moduleManager.toggle(this);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\modules\misc\SilentUse4.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */