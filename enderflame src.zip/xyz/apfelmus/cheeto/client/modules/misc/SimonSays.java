/*    */ package xyz.apfelmus.cheeto.client.modules.misc;
/*    */ 
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraftforge.event.entity.player.PlayerInteractEvent;
/*    */ import xyz.apfelmus.cf4m.annotation.Event;
/*    */ import xyz.apfelmus.cf4m.annotation.module.Module;
/*    */ import xyz.apfelmus.cf4m.module.Category;
/*    */ import xyz.apfelmus.cheeto.client.events.PlayerInteractEvent;
/*    */ import xyz.apfelmus.cheeto.client.utils.client.KeybindUtils;
/*    */ import xyz.apfelmus.cheeto.client.utils.skyblock.SkyblockUtils;
/*    */ 
/*    */ @Module(name = "SimonSays", category = Category.MISC)
/*    */ public class SimonSays {
/* 16 */   private static Minecraft mc = Minecraft.func_71410_x(); private static boolean clicking = false;
/*    */   
/*    */   @Event
/*    */   public void onInteract(PlayerInteractEvent event) {
/* 20 */     if (!clicking && SkyblockUtils.isInDungeon() && event.action == PlayerInteractEvent.Action.RIGHT_CLICK_BLOCK) {
/* 21 */       IBlockState bs = mc.field_71441_e.func_180495_p(event.pos);
/*    */       
/* 23 */       if (bs != null && bs.func_177230_c() == Blocks.field_150430_aB) {
/* 24 */         int x = event.pos.func_177958_n();
/* 25 */         int y = event.pos.func_177956_o();
/* 26 */         int z = event.pos.func_177952_p();
/*    */         
/* 28 */         if (x == 309 && y >= 120 && y <= 123 && z >= 291 && z <= 294) {
/* 29 */           clicking = true;
/* 30 */           for (int i = 0; i < 4; i++) {
/* 31 */             KeybindUtils.rightClick();
/*    */           }
/* 33 */           clicking = false;
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\modules\misc\SimonSays.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */