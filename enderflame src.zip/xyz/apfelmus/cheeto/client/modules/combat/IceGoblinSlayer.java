/*     */ package xyz.apfelmus.cheeto.client.modules.combat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.stream.Stream;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.settings.KeyBinding;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.Vec3;
/*     */ import xyz.apfelmus.cf4m.annotation.Event;
/*     */ import xyz.apfelmus.cf4m.annotation.Setting;
/*     */ import xyz.apfelmus.cf4m.annotation.module.Disable;
/*     */ import xyz.apfelmus.cf4m.annotation.module.Enable;
/*     */ import xyz.apfelmus.cf4m.annotation.module.Module;
/*     */ import xyz.apfelmus.cheeto.client.events.ClientTickEvent;
/*     */ import xyz.apfelmus.cheeto.client.events.Render3DEvent;
/*     */ import xyz.apfelmus.cheeto.client.settings.BooleanSetting;
/*     */ import xyz.apfelmus.cheeto.client.settings.IntegerSetting;
/*     */ import xyz.apfelmus.cheeto.client.utils.client.Rotation;
/*     */ import xyz.apfelmus.cheeto.client.utils.client.RotationUtils;
/*     */ import xyz.apfelmus.cheeto.client.utils.skyblock.SkyblockUtils;
/*     */ 
/*     */ @Module(name = "IceGoblinSlayer", category = Category.COMBAT)
/*     */ public class IceGoblinSlayer {
/*     */   @Setting(name = "AimTime")
/*  27 */   private IntegerSetting aimTime = new IntegerSetting(
/*  28 */       Integer.valueOf(250), Integer.valueOf(0), Integer.valueOf(1000)); @Setting(name = "ClickDelay")
/*  29 */   private IntegerSetting clickDelay = new IntegerSetting(
/*  30 */       Integer.valueOf(200), Integer.valueOf(0), Integer.valueOf(1000)); @Setting(name = "AntiAFK")
/*  31 */   private BooleanSetting antiAfk = new BooleanSetting(true);
/*     */   @Setting(name = "Radius")
/*  33 */   private IntegerSetting radius = new IntegerSetting(
/*  34 */       Integer.valueOf(30), Integer.valueOf(0), Integer.valueOf(30)); @Setting(name = "ItemSlot", description = "Juju / Term / Frozen Scythe")
/*  35 */   private IntegerSetting itemSlot = new IntegerSetting(
/*  36 */       Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(8));
/*     */   
/*  38 */   private static Minecraft mc = Minecraft.func_71410_x();
/*  39 */   private static Entity currentMob = null;
/*  40 */   private static List<Entity> blacklist = new ArrayList<>();
/*  41 */   private static long curEnd = 0L;
/*  42 */   private static int ticks = 0;
/*     */   
/*     */   enum KillState {
/*  45 */     SELECT,
/*  46 */     AIM,
/*  47 */     KILL;
/*     */   }
/*     */   
/*     */   enum AfkState {
/*  51 */     LEFT,
/*  52 */     RIGHT;
/*     */   }
/*     */   
/*  55 */   private static KillState killState = KillState.SELECT;
/*  56 */   private static AfkState afkState = AfkState.LEFT;
/*     */   
/*     */   @Enable
/*     */   public void onEnable() {
/*  60 */     curEnd = 0L;
/*  61 */     currentMob = null;
/*  62 */     killState = KillState.SELECT;
/*  63 */     afkState = AfkState.LEFT;
/*  64 */     blacklist.clear();
/*     */   }
/*     */   
/*     */   @Disable
/*     */   public void onDisable() {
/*  69 */     if (this.antiAfk.isEnabled()) {
/*  70 */       KeyBinding.func_74510_a(mc.field_71474_y.field_74370_x.func_151463_i(), false);
/*  71 */       KeyBinding.func_74510_a(mc.field_71474_y.field_74366_z.func_151463_i(), false);
/*  72 */       KeyBinding.func_74510_a(mc.field_71474_y.field_74311_E.func_151463_i(), false);
/*     */     } 
/*     */   }
/*     */   @Event
/*     */   public void onTick(ClientTickEvent event) {
/*     */     List<Entity> allPossible;
/*  78 */     if (this.antiAfk.isEnabled()) {
/*  79 */       KeyBinding.func_74510_a(mc.field_71474_y.field_74311_E.func_151463_i(), true);
/*  80 */       KeyBinding.func_74510_a(mc.field_71474_y.field_74370_x.func_151463_i(), false);
/*  81 */       KeyBinding.func_74510_a(mc.field_71474_y.field_74366_z.func_151463_i(), false);
/*     */     } 
/*     */     
/*  84 */     if (++ticks > 40) {
/*  85 */       ticks = 0;
/*  86 */       blacklist.clear();
/*     */       
/*  88 */       if (this.antiAfk.isEnabled()) {
/*  89 */         switch (afkState) {
/*     */           case SELECT:
/*  91 */             KeyBinding.func_74510_a(mc.field_71474_y.field_74370_x.func_151463_i(), true);
/*  92 */             afkState = AfkState.RIGHT;
/*     */             break;
/*     */           
/*     */           case KILL:
/*  96 */             KeyBinding.func_74510_a(mc.field_71474_y.field_74366_z.func_151463_i(), true);
/*  97 */             afkState = AfkState.LEFT;
/*     */             break;
/*     */         } 
/*     */       
/*     */       }
/*     */     } 
/* 103 */     switch (killState) {
/*     */       case SELECT:
/* 105 */         allPossible = new ArrayList<>();
/* 106 */         for (Entity e : mc.field_71441_e.field_72996_f) {
/* 107 */           if (!(e instanceof net.minecraft.entity.player.EntityPlayer) || 
/* 108 */             Stream.<String>of(new String[] { "knifethrower", "goblin", "walker" }).noneMatch(v -> e.func_70005_c_().toLowerCase().contains(v)) || 
/* 109 */             !mc.field_71439_g.func_70685_l(e) || 
/* 110 */             e.field_70128_L || 
/* 111 */             e.func_70032_d((Entity)mc.field_71439_g) >= this.radius.getCurrent().intValue())
/*     */             continue; 
/* 113 */           if (!blacklist.contains(e)) allPossible.add(e);
/*     */         
/*     */         } 
/* 116 */         if (!allPossible.isEmpty()) {
/* 117 */           currentMob = Collections.<Entity>min(allPossible, Comparator.comparing(e2 -> Float.valueOf(e2.func_70032_d((Entity)mc.field_71439_g))));
/* 118 */           Vec3 vec = currentMob.func_174791_d();
/* 119 */           vec = vec.func_72441_c(0.0D, 1.0D, 0.0D);
/* 120 */           Rotation rot = RotationUtils.getRotation(vec);
/* 121 */           RotationUtils.setup(rot, Long.valueOf(this.aimTime.getCurrent().intValue()));
/* 122 */           curEnd = RotationUtils.endTime;
/* 123 */           killState = KillState.AIM;
/*     */         } 
/*     */         break;
/*     */       
/*     */       case KILL:
/* 128 */         SkyblockUtils.silentUse(this.itemSlot.getCurrent().intValue(), this.itemSlot.getCurrent().intValue());
/* 129 */         blacklist.add(currentMob);
/* 130 */         currentMob = null;
/* 131 */         killState = KillState.SELECT;
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   @Event
/*     */   public void onRender(Render3DEvent event) {
/* 138 */     if (killState == KillState.AIM) {
/* 139 */       if (currentMob.field_70128_L) {
/* 140 */         blacklist.add(currentMob);
/* 141 */         currentMob = null;
/* 142 */         killState = KillState.SELECT;
/*     */         return;
/*     */       } 
/* 145 */       if (System.currentTimeMillis() <= curEnd + this.clickDelay.getCurrent().intValue()) {
/* 146 */         RotationUtils.update();
/*     */       } else {
/* 148 */         killState = KillState.KILL;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\modules\combat\IceGoblinSlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */