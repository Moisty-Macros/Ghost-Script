/*    */ package xyz.apfelmus.cheeto.client.modules.combat;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.Comparator;
/*    */ import java.util.List;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.settings.KeyBinding;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.util.MovingObjectPosition;
/*    */ import net.minecraft.util.Vec3;
/*    */ import xyz.apfelmus.cf4m.annotation.Event;
/*    */ import xyz.apfelmus.cf4m.annotation.Setting;
/*    */ import xyz.apfelmus.cf4m.annotation.module.Enable;
/*    */ import xyz.apfelmus.cheeto.client.events.Render3DEvent;
/*    */ import xyz.apfelmus.cheeto.client.events.WorldUnloadEvent;
/*    */ import xyz.apfelmus.cheeto.client.settings.BooleanSetting;
/*    */ import xyz.apfelmus.cheeto.client.settings.IntegerSetting;
/*    */ import xyz.apfelmus.cheeto.client.utils.client.Rotation;
/*    */ import xyz.apfelmus.cheeto.client.utils.client.RotationUtils;
/*    */ 
/*    */ public class ZealotBot {
/*    */   @Setting(name = "AimTime")
/* 23 */   private IntegerSetting aimTime = new IntegerSetting(
/* 24 */       Integer.valueOf(100), Integer.valueOf(0), Integer.valueOf(1000)); @Setting(name = "ClickDelay")
/* 25 */   private IntegerSetting clickDelay = new IntegerSetting(
/* 26 */       Integer.valueOf(100), Integer.valueOf(0), Integer.valueOf(1000)); @Setting(name = "Radius")
/* 27 */   private IntegerSetting radius = new IntegerSetting(
/* 28 */       Integer.valueOf(30), Integer.valueOf(0), Integer.valueOf(30));
/*    */   @Setting(name = "GodGamerMode")
/* 30 */   public static BooleanSetting godGamerMode = new BooleanSetting(false);
/*    */   
/* 32 */   private static Minecraft mc = Minecraft.func_71410_x();
/*    */   private Entity zealot;
/* 34 */   private KillState ks = KillState.SELECT;
/*    */   
/*    */   enum KillState {
/* 37 */     SELECT,
/* 38 */     AIM,
/* 39 */     KILL;
/*    */   }
/*    */   
/*    */   @Enable
/*    */   public void onEnable() {
/* 44 */     this.zealot = null;
/* 45 */     this.ks = KillState.SELECT;
/*    */   }
/*    */   @Event
/*    */   public void onRender(Render3DEvent event) {
/*    */     List<Entity> allPossible;
/* 50 */     switch (this.ks) {
/*    */       case SELECT:
/* 52 */         allPossible = new ArrayList<>();
/* 53 */         for (Entity e : mc.field_71441_e.field_72996_f) {
/* 54 */           if (e instanceof net.minecraft.entity.monster.EntityEnderman)
/*    */           {
/* 56 */             if (e != null) {
/* 57 */               allPossible.add(e);
/*    */             }
/*    */           }
/*    */         } 
/*    */         
/* 62 */         allPossible.forEach(e -> {
/*    */               MovingObjectPosition mop = mc.field_71441_e.func_72933_a(mc.field_71439_g.func_174824_e(1.0F), e.func_174791_d());
/*    */               
/*    */               if (mop != null) {
/*    */                 System.out.println(mop.field_72313_a);
/*    */               }
/*    */             });
/* 69 */         if (!allPossible.isEmpty()) {
/* 70 */           this.zealot = Collections.<Entity>min(allPossible, Comparator.comparing(e2 -> Float.valueOf(e2.func_70032_d((Entity)mc.field_71439_g))));
/* 71 */           Vec3 vec = this.zealot.func_174791_d();
/* 72 */           vec = vec.func_72441_c(0.0D, 1.0D, 0.0D);
/* 73 */           Rotation rot = RotationUtils.getRotation(vec);
/* 74 */           RotationUtils.setup(rot, Long.valueOf(this.aimTime.getCurrent().intValue()));
/* 75 */           this.ks = KillState.AIM;
/*    */         } 
/*    */         break;
/*    */       
/*    */       case AIM:
/* 80 */         if (System.currentTimeMillis() <= RotationUtils.endTime + this.clickDelay.getCurrent().intValue()) {
/* 81 */           RotationUtils.update(); break;
/*    */         } 
/* 83 */         this.ks = KillState.KILL;
/*    */         break;
/*    */ 
/*    */       
/*    */       case KILL:
/* 88 */         KeyBinding.func_74507_a(mc.field_71474_y.field_74311_E.func_151463_i());
/* 89 */         this.ks = KillState.SELECT;
/*    */         break;
/*    */     } 
/*    */   }
/*    */   
/*    */   @Event
/*    */   public void onWorldLoad(WorldUnloadEvent event) {
/* 96 */     this.zealot = null;
/* 97 */     this.ks = KillState.SELECT;
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\modules\combat\ZealotBot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */