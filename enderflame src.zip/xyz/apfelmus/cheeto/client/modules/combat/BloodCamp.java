/*    */ package xyz.apfelmus.cheeto.client.modules.combat;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.settings.KeyBinding;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.util.Vec3;
/*    */ import xyz.apfelmus.cf4m.annotation.Event;
/*    */ import xyz.apfelmus.cf4m.annotation.Setting;
/*    */ import xyz.apfelmus.cf4m.annotation.module.Enable;
/*    */ import xyz.apfelmus.cf4m.annotation.module.Module;
/*    */ import xyz.apfelmus.cf4m.module.Category;
/*    */ import xyz.apfelmus.cheeto.client.events.Render3DEvent;
/*    */ import xyz.apfelmus.cheeto.client.events.WorldUnloadEvent;
/*    */ import xyz.apfelmus.cheeto.client.settings.BooleanSetting;
/*    */ import xyz.apfelmus.cheeto.client.settings.FloatSetting;
/*    */ import xyz.apfelmus.cheeto.client.settings.IntegerSetting;
/*    */ import xyz.apfelmus.cheeto.client.utils.client.Rotation;
/*    */ import xyz.apfelmus.cheeto.client.utils.client.RotationUtils;
/*    */ 
/*    */ @Module(name = "BloodCamp", category = Category.COMBAT)
/*    */ public class BloodCamp
/*    */ {
/*    */   @Setting(name = "AimTime")
/* 27 */   private IntegerSetting aimTime = new IntegerSetting(
/* 28 */       Integer.valueOf(100), Integer.valueOf(0), Integer.valueOf(1000)); @Setting(name = "ClickDelay")
/* 29 */   private IntegerSetting clickDelay = new IntegerSetting(
/* 30 */       Integer.valueOf(100), Integer.valueOf(0), Integer.valueOf(1000)); @Setting(name = "AimLow")
/* 31 */   private FloatSetting aimLow = new FloatSetting(
/* 32 */       Float.valueOf(1.0F), Float.valueOf(0.0F), Float.valueOf(5.0F));
/*    */   @Setting(name = "GodGamerMode")
/* 34 */   public static BooleanSetting godGamerMode = new BooleanSetting(false);
/*    */   
/* 36 */   private static Minecraft mc = Minecraft.func_71410_x();
/* 37 */   private List<String> names = new ArrayList<>(Arrays.asList(new String[] { "Revoker", "Psycho", "Reaper", "Parasite", "Cannibal", "Mute", "Ooze", "Putrid", "Freak", "Leech", "Flamer", "Tear", "Skull", "Mr. Dead", "Vader", "Frost", "Walker" }));
/* 38 */   private List<String> clickedNames = new ArrayList<>();
/* 39 */   private KillState ks = KillState.SELECT;
/* 40 */   private long curEnd = 0L;
/*    */   
/*    */   enum KillState {
/* 43 */     SELECT,
/* 44 */     AIM,
/* 45 */     KILL;
/*    */   }
/*    */   
/*    */   @Enable
/*    */   public void onEnable() {
/* 50 */     this.curEnd = 0L;
/* 51 */     this.clickedNames.clear();
/* 52 */     this.ks = KillState.SELECT;
/*    */   }
/*    */   
/*    */   @Event
/*    */   public void onRender(Render3DEvent event) {
/* 57 */     switch (this.ks) {
/*    */       case SELECT:
/* 59 */         for (Entity e : mc.field_71441_e.field_72996_f) {
/* 60 */           if (e instanceof net.minecraft.client.entity.EntityOtherPlayerMP && 
/* 61 */             !this.clickedNames.contains(e.func_70005_c_().trim()) && this.names.contains(e.func_70005_c_().trim())) {
/* 62 */             Vec3 vec = e.func_174791_d();
/* 63 */             vec = vec.func_72441_c(0.0D, (-1.0F * this.aimLow.getCurrent().floatValue()), 0.0D);
/* 64 */             Rotation rot = RotationUtils.getRotation(vec);
/* 65 */             RotationUtils.setup(rot, Long.valueOf(this.aimTime.getCurrent().intValue()));
/* 66 */             this.curEnd = RotationUtils.endTime;
/* 67 */             this.clickedNames.add(e.func_70005_c_().trim());
/* 68 */             this.ks = KillState.AIM;
/*    */           } 
/*    */         } 
/*    */         break;
/*    */ 
/*    */       
/*    */       case AIM:
/* 75 */         if (System.currentTimeMillis() <= this.curEnd + this.clickDelay.getCurrent().intValue()) {
/* 76 */           RotationUtils.update(); break;
/*    */         } 
/* 78 */         this.ks = KillState.KILL;
/*    */         break;
/*    */ 
/*    */       
/*    */       case KILL:
/* 83 */         KeyBinding.func_74507_a(mc.field_71474_y.field_74312_F.func_151463_i());
/* 84 */         this.ks = KillState.SELECT;
/*    */         break;
/*    */     } 
/*    */   }
/*    */   
/*    */   @Event
/*    */   public void onWorldLoad(WorldUnloadEvent event) {
/* 91 */     this.clickedNames.clear();
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\modules\combat\BloodCamp.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */