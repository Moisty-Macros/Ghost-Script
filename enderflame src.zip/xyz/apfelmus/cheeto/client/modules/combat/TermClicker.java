/*    */ package xyz.apfelmus.cheeto.client.modules.combat;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import org.lwjgl.input.Keyboard;
/*    */ import xyz.apfelmus.cf4m.CF4M;
/*    */ import xyz.apfelmus.cf4m.annotation.Event;
/*    */ import xyz.apfelmus.cf4m.annotation.Setting;
/*    */ import xyz.apfelmus.cf4m.annotation.module.Module;
/*    */ import xyz.apfelmus.cf4m.module.Category;
/*    */ import xyz.apfelmus.cheeto.client.events.Render3DEvent;
/*    */ import xyz.apfelmus.cheeto.client.settings.BooleanSetting;
/*    */ import xyz.apfelmus.cheeto.client.settings.IntegerSetting;
/*    */ import xyz.apfelmus.cheeto.client.settings.ModeSetting;
/*    */ import xyz.apfelmus.cheeto.client.utils.skyblock.InventoryUtils;
/*    */ import xyz.apfelmus.cheeto.client.utils.skyblock.SkyblockUtils;
/*    */ 
/*    */ @Module(name = "TermClicker", category = Category.COMBAT)
/*    */ public class TermClicker {
/*    */   @Setting(name = "CPS")
/* 21 */   private IntegerSetting cps = new IntegerSetting(
/* 22 */       Integer.valueOf(20), Integer.valueOf(0), Integer.valueOf(50)); @Setting(name = "Silent")
/* 23 */   private BooleanSetting silent = new BooleanSetting(true);
/*    */   @Setting(name = "Mode")
/* 25 */   private ModeSetting mode = new ModeSetting("Hold", 
/* 26 */       Arrays.asList(new String[] { "Hold", "Toggle" })); @Setting(name = "Weapon")
/* 27 */   private ModeSetting weapon = new ModeSetting("Terminator", 
/* 28 */       Arrays.asList(new String[] { "Terminator", "Juju Shortbow" }));
/*    */   
/* 30 */   private static long lastClickTime = 0L;
/*    */   
/* 32 */   private static Minecraft mc = Minecraft.func_71410_x();
/*    */   
/*    */   @Event
/*    */   public void onRenderTick(Render3DEvent event) {
/* 36 */     if (this.mode.getCurrent().equals("Hold")) {
/* 37 */       if (Keyboard.isKeyDown(CF4M.INSTANCE.moduleManager.getKey(this))) {
/* 38 */         clickTermIfNeeded();
/*    */       } else {
/* 40 */         CF4M.INSTANCE.moduleManager.toggle(this);
/*    */       } 
/* 42 */     } else if (this.mode.getCurrent().equals("Toggle")) {
/* 43 */       clickTermIfNeeded();
/*    */     } 
/*    */   }
/*    */   
/*    */   private void clickTermIfNeeded() {
/* 48 */     float acTime = 1000.0F / this.cps.getCurrent().intValue();
/* 49 */     if ((float)(System.currentTimeMillis() - lastClickTime) >= acTime) {
/* 50 */       int termSlot = InventoryUtils.getItemInHotbar(this.weapon.getCurrent());
/*    */       
/* 52 */       if (termSlot != -1) {
/* 53 */         SkyblockUtils.silentUse(this.silent.isEnabled() ? (mc.field_71439_g.field_71071_by.field_70461_c + 1) : (termSlot + 1), termSlot + 1);
/*    */       }
/* 55 */       lastClickTime = System.currentTimeMillis();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\modules\combat\TermClicker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */