/*    */ package xyz.apfelmus.cheeto.client.modules.combat;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import xyz.apfelmus.cf4m.CF4M;
/*    */ import xyz.apfelmus.cf4m.annotation.Event;
/*    */ import xyz.apfelmus.cf4m.annotation.Setting;
/*    */ import xyz.apfelmus.cf4m.annotation.module.Enable;
/*    */ import xyz.apfelmus.cf4m.annotation.module.Module;
/*    */ import xyz.apfelmus.cf4m.module.Category;
/*    */ import xyz.apfelmus.cheeto.client.events.Render3DEvent;
/*    */ import xyz.apfelmus.cheeto.client.settings.BooleanSetting;
/*    */ import xyz.apfelmus.cheeto.client.settings.IntegerSetting;
/*    */ import xyz.apfelmus.cheeto.client.utils.math.TimeHelper;
/*    */ import xyz.apfelmus.cheeto.client.utils.skyblock.InventoryUtils;
/*    */ 
/*    */ @Module(name = "BonerThrower", category = Category.COMBAT)
/*    */ public class BonerThrower {
/*    */   @Setting(name = "SilentUse", description = "Always stay on the configured slot")
/* 22 */   private BooleanSetting silentUse = new BooleanSetting(false);
/*    */   @Setting(name = "ThrowDelay", description = "Throw delay in milliseconds")
/* 24 */   private IntegerSetting throwDelay = new IntegerSetting(
/* 25 */       Integer.valueOf(100), Integer.valueOf(0), Integer.valueOf(1000)); @Setting(name = "MainSlot", description = "Slot of the weapon you want held")
/* 26 */   private IntegerSetting mainSlot = new IntegerSetting(
/* 27 */       Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(8)); @Setting(name = "InvMode", description = "A bit bannable")
/* 28 */   private BooleanSetting invMode = new BooleanSetting(false);
/*    */ 
/*    */   
/* 31 */   private static Minecraft mc = Minecraft.func_71410_x();
/* 32 */   private static List<Integer> boners = new ArrayList<>();
/* 33 */   private static TimeHelper throwTimer = new TimeHelper();
/* 34 */   private static int throwSlot = -1;
/*    */   private static boolean first = true;
/*    */   
/*    */   @Enable
/*    */   public void onEnable() {
/* 39 */     boners.clear();
/* 40 */     throwSlot = -1;
/* 41 */     first = true;
/* 42 */     throwTimer.reset();
/* 43 */     if (!this.invMode.isEnabled()) {
/* 44 */       for (int i = 0; i < 8; i++) {
/* 45 */         ItemStack a = mc.field_71439_g.field_71071_by.func_70301_a(i);
/* 46 */         if (a != null && a.func_82833_r().contains("Bonemerang")) {
/* 47 */           boners.add(Integer.valueOf(i));
/*    */         }
/*    */       } 
/*    */     } else {
/* 51 */       throwSlot = InventoryUtils.getAvailableHotbarSlot("Bonemerang");
/*    */       
/* 53 */       boners = InventoryUtils.getAllSlots(throwSlot, "Bonemerang");
/* 54 */       if (throwSlot == -1 || boners.isEmpty()) {
/* 55 */         CF4M.INSTANCE.moduleManager.toggle(this);
/*    */       }
/*    */     } 
/*    */   }
/*    */   
/*    */   @Event
/*    */   public void onRenderTick(Render3DEvent event) {
/* 62 */     if (throwTimer.hasReached(this.throwDelay.getCurrent().intValue())) {
/* 63 */       int oldSlot = mc.field_71439_g.field_71071_by.field_70461_c;
/*    */       
/* 65 */       if (!this.invMode.isEnabled()) {
/* 66 */         if (!boners.isEmpty()) {
/* 67 */           InventoryUtils.throwSlot(((Integer)boners.get(0)).intValue());
/* 68 */           boners.remove(0);
/*    */         }
/*    */       
/* 71 */       } else if (first) {
/* 72 */         InventoryUtils.throwSlot(throwSlot);
/* 73 */         first = false;
/*    */       } else {
/* 75 */         if (!boners.isEmpty()) {
/* 76 */           mc.field_71442_b.func_78753_a(mc.field_71439_g.field_71069_bz.field_75152_c, ((Integer)boners.get(0)).intValue(), throwSlot, 2, (EntityPlayer)mc.field_71439_g);
/* 77 */           boners.remove(0);
/*    */         } 
/* 79 */         InventoryUtils.throwSlot(throwSlot);
/*    */       } 
/*    */ 
/*    */       
/* 83 */       if (this.silentUse.isEnabled()) {
/* 84 */         if (this.mainSlot.getCurrent().intValue() > 0 && this.mainSlot.getCurrent().intValue() <= 8) {
/* 85 */           mc.field_71439_g.field_71071_by.field_70461_c = this.mainSlot.getCurrent().intValue() - 1;
/*    */         } else {
/* 87 */           mc.field_71439_g.field_71071_by.field_70461_c = oldSlot;
/*    */         } 
/* 89 */       } else if (boners.isEmpty() && 
/* 90 */         this.mainSlot.getCurrent().intValue() > 0 && this.mainSlot.getCurrent().intValue() <= 8) {
/* 91 */         mc.field_71439_g.field_71071_by.field_70461_c = this.mainSlot.getCurrent().intValue() - 1;
/*    */       } 
/*    */ 
/*    */       
/* 95 */       if (boners.isEmpty())
/* 96 */         CF4M.INSTANCE.moduleManager.toggle(this); 
/* 97 */       throwTimer.reset();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\modules\combat\BonerThrower.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */