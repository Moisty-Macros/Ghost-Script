/*    */ package xyz.apfelmus.cheeto.client.modules.combat;
/*    */ import org.lwjgl.input.Keyboard;
/*    */ import xyz.apfelmus.cf4m.CF4M;
/*    */ import xyz.apfelmus.cf4m.annotation.Event;
/*    */ import xyz.apfelmus.cf4m.annotation.Setting;
/*    */ import xyz.apfelmus.cf4m.annotation.module.Enable;
/*    */ import xyz.apfelmus.cf4m.annotation.module.Module;
/*    */ import xyz.apfelmus.cf4m.module.Category;
/*    */ import xyz.apfelmus.cheeto.client.events.Render3DEvent;
/*    */ import xyz.apfelmus.cheeto.client.settings.BooleanSetting;
/*    */ import xyz.apfelmus.cheeto.client.settings.IntegerSetting;
/*    */ import xyz.apfelmus.cheeto.client.utils.client.KeybindUtils;
/*    */ 
/*    */ @Module(name = "AutoClicker", category = Category.COMBAT)
/*    */ public class AutoClicker {
/*    */   @Setting(name = "BurstMode")
/* 17 */   private BooleanSetting burstMode = new BooleanSetting(false);
/*    */   @Setting(name = "BurstAmount")
/* 19 */   private IntegerSetting burstAmount = new IntegerSetting(
/* 20 */       Integer.valueOf(10), Integer.valueOf(0), Integer.valueOf(25)); @Setting(name = "CPS")
/* 21 */   private IntegerSetting cps = new IntegerSetting(
/* 22 */       Integer.valueOf(10), Integer.valueOf(0), Integer.valueOf(50));
/*    */   
/*    */   private static boolean toggled = false;
/* 25 */   private static long lastClickTime = 0L;
/* 26 */   private static int clickedAmount = 0;
/*    */   
/*    */   @Enable
/*    */   public void onEnable() {
/* 30 */     if (toggled) toggled = false; 
/* 31 */     clickedAmount = 0;
/*    */   }
/*    */   
/*    */   @Event
/*    */   public void onTick(Render3DEvent event) {
/* 36 */     if (this.burstMode.isEnabled()) {
/* 37 */       if (toggled) {
/* 38 */         float acTime = 1000.0F / this.cps.getCurrent().intValue();
/* 39 */         if (clickedAmount < this.burstAmount.getCurrent().intValue()) {
/* 40 */           if ((float)(System.currentTimeMillis() - lastClickTime) >= acTime) {
/* 41 */             KeybindUtils.rightClick();
/* 42 */             lastClickTime = System.currentTimeMillis();
/* 43 */             clickedAmount++;
/*    */           } 
/*    */         } else {
/* 46 */           toggled = false;
/* 47 */           CF4M.INSTANCE.moduleManager.toggle(this);
/*    */         } 
/*    */       } else {
/* 50 */         toggled = true;
/*    */       }
/*    */     
/* 53 */     } else if (Keyboard.isKeyDown(CF4M.INSTANCE.moduleManager.getKey(this))) {
/* 54 */       float acTime = 1000.0F / this.cps.getCurrent().intValue();
/* 55 */       if ((float)(System.currentTimeMillis() - lastClickTime) >= acTime) {
/* 56 */         KeybindUtils.rightClick();
/* 57 */         lastClickTime = System.currentTimeMillis();
/*    */       } 
/*    */     } else {
/* 60 */       CF4M.INSTANCE.moduleManager.toggle(this);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\modules\combat\AutoClicker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */