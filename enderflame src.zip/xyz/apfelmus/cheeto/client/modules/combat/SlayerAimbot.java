/*     */ package xyz.apfelmus.cheeto.client.modules.combat;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ThreadLocalRandom;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.item.EntityArmorStand;
/*     */ import net.minecraft.entity.monster.EntityEnderman;
/*     */ import net.minecraft.entity.monster.EntitySpider;
/*     */ import net.minecraft.entity.monster.EntityZombie;
/*     */ import net.minecraft.entity.passive.EntityWolf;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import xyz.apfelmus.cf4m.annotation.Event;
/*     */ import xyz.apfelmus.cf4m.annotation.Setting;
/*     */ import xyz.apfelmus.cf4m.annotation.module.Enable;
/*     */ import xyz.apfelmus.cf4m.annotation.module.Module;
/*     */ import xyz.apfelmus.cheeto.client.events.ClientTickEvent;
/*     */ import xyz.apfelmus.cheeto.client.events.Render3DEvent;
/*     */ import xyz.apfelmus.cheeto.client.settings.BooleanSetting;
/*     */ import xyz.apfelmus.cheeto.client.settings.IntegerSetting;
/*     */ import xyz.apfelmus.cheeto.client.utils.client.Rotation;
/*     */ import xyz.apfelmus.cheeto.client.utils.client.RotationUtils;
/*     */ import xyz.apfelmus.cheeto.client.utils.skyblock.SkyblockUtils;
/*     */ 
/*     */ @Module(name = "SlayerAimbot", category = Category.COMBAT)
/*     */ public class SlayerAimbot {
/*     */   @Setting(name = "AimSpeed")
/*  33 */   private IntegerSetting aimSpeed = new IntegerSetting(
/*  34 */       Integer.valueOf(45), Integer.valueOf(5), Integer.valueOf(100)); @Setting(name = "Range")
/*  35 */   private IntegerSetting range = new IntegerSetting(
/*  36 */       Integer.valueOf(4), Integer.valueOf(3), Integer.valueOf(7)); @Setting(name = "Blatant")
/*  37 */   private BooleanSetting blatant = new BooleanSetting(false);
/*     */   @Setting(name = "Minibosses")
/*  39 */   private BooleanSetting miniBosses = new BooleanSetting(true);
/*     */   @Setting(name = "DisableForTP")
/*  41 */   private BooleanSetting disable = new BooleanSetting(false);
/*     */ 
/*     */   
/*  44 */   private static Minecraft mc = Minecraft.func_71410_x();
/*     */   
/*     */   private static EntityArmorStand slayerStand;
/*     */   private static Entity slayerMob;
/*     */   private static boolean isMini;
/*  49 */   private static final Map<String, Class<?>> slayerMap = new HashMap<String, Class<?>>()
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   private static final Map<String, Class<?>> miniMap = new HashMap<String, Class<?>>()
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enable
/*     */   public void onEnable() {
/*  73 */     slayerMob = null;
/*  74 */     slayerStand = null;
/*  75 */     isMini = false;
/*     */   }
/*     */   
/*     */   @Event
/*     */   public void onTick(ClientTickEvent event) {
/*  80 */     if (slayerMob == null) {
/*  81 */       Map<Entity, EntityArmorStand> allPossibleSlayers = new HashMap<>();
/*  82 */       Map<Entity, EntityArmorStand> allPossibleMinis = new HashMap<>();
/*     */       
/*  84 */       int rongo = this.range.getCurrent().intValue();
/*  85 */       for (Iterator<Entity> iterator = mc.field_71441_e.func_175674_a((Entity)mc.field_71439_g, mc.field_71439_g.func_174813_aQ().func_72314_b(rongo, rongo, rongo), null).iterator(); iterator.hasNext(); ) { Entity e = iterator.next();
/*  86 */         if (e instanceof EntityArmorStand) {
/*  87 */           slayerMap.forEach((k, v) -> {
/*     */                 if (e.func_95999_t().contains(k) && e.func_70032_d((Entity)mc.field_71439_g) <= this.range.getCurrent().intValue()) {
/*     */                   Entity slay = SkyblockUtils.getEntityCuttingOtherEntity(e, v);
/*     */                   
/*     */                   if (slay != null) {
/*     */                     allPossibleSlayers.put(slay, (EntityArmorStand)e);
/*     */                   }
/*     */                 } 
/*     */               });
/*  96 */           if (this.miniBosses.isEnabled()) {
/*  97 */             miniMap.forEach((k, v) -> {
/*     */                   if (e.func_95999_t().contains(k) && e.func_70032_d((Entity)mc.field_71439_g) <= this.range.getCurrent().intValue()) {
/*     */                     Entity mini = SkyblockUtils.getEntityCuttingOtherEntity(e, v);
/*     */                     
/*     */                     if (mini != null) {
/*     */                       allPossibleMinis.put(mini, (EntityArmorStand)e);
/*     */                     }
/*     */                   } 
/*     */                 });
/*     */           }
/*     */         }  }
/*     */       
/* 109 */       if (!allPossibleSlayers.isEmpty()) {
/* 110 */         slayerMob = Collections.<Entity>min(allPossibleSlayers.keySet(), Comparator.comparing(e2 -> Float.valueOf(e2.func_70032_d((Entity)mc.field_71439_g))));
/* 111 */         slayerStand = allPossibleSlayers.get(slayerMob);
/* 112 */       } else if (!allPossibleMinis.isEmpty()) {
/* 113 */         slayerMob = Collections.<Entity>min(allPossibleMinis.keySet(), Comparator.comparing(e2 -> Float.valueOf(e2.func_70032_d((Entity)mc.field_71439_g))));
/* 114 */         slayerStand = allPossibleMinis.get(slayerMob);
/* 115 */         isMini = true;
/*     */       }
/*     */     
/* 118 */     } else if (this.miniBosses.isEnabled() && isMini) {
/* 119 */       Map<Entity, EntityArmorStand> allPossibleSlayers = new HashMap<>();
/*     */       
/* 121 */       int rongo = this.range.getCurrent().intValue();
/* 122 */       for (Iterator<Entity> iterator = mc.field_71441_e.func_175674_a((Entity)mc.field_71439_g, mc.field_71439_g.func_174813_aQ().func_72314_b(rongo, rongo, rongo), null).iterator(); iterator.hasNext(); ) { Entity e = iterator.next();
/* 123 */         if (e instanceof EntityArmorStand) {
/* 124 */           slayerMap.forEach((k, v) -> {
/*     */                 if (e.func_95999_t().contains(k) && e.func_70032_d((Entity)mc.field_71439_g) <= this.range.getCurrent().intValue()) {
/*     */                   Entity slay = SkyblockUtils.getEntityCuttingOtherEntity(e, v);
/*     */                   
/*     */                   if (slay != null) {
/*     */                     allPossibleSlayers.put(slay, (EntityArmorStand)e);
/*     */                   }
/*     */                 } 
/*     */               });
/*     */         } }
/*     */       
/* 135 */       if (!allPossibleSlayers.isEmpty()) {
/* 136 */         slayerMob = Collections.<Entity>min(allPossibleSlayers.keySet(), Comparator.comparing(e2 -> Float.valueOf(e2.func_70032_d((Entity)mc.field_71439_g))));
/* 137 */         slayerStand = allPossibleSlayers.get(slayerMob);
/* 138 */         isMini = false;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Event
/*     */   public void onRender(Render3DEvent event) {
/* 146 */     if (this.disable.isEnabled()) {
/* 147 */       ItemStack currentHeld = mc.field_71439_g.func_70694_bm();
/* 148 */       if (currentHeld == null || currentHeld.func_82833_r().contains("Aspect of the "))
/*     */         return; 
/* 150 */     }  if (slayerMob != null) {
/* 151 */       int mobHp = getSlayerHp();
/*     */       
/* 153 */       if (slayerMob.func_70032_d((Entity)mc.field_71439_g) > 5.0F || slayerMob.field_70128_L || mobHp == 0) {
/* 154 */         slayerMob = null;
/* 155 */         slayerStand = null;
/*     */         
/*     */         return;
/*     */       } 
/* 159 */       if (!this.blatant.isEnabled() && (mc.field_71476_x == null || mc.field_71476_x.field_72313_a != MovingObjectPosition.MovingObjectType.ENTITY || !mc.field_71476_x.field_72308_g.equals(slayerMob))) {
/* 160 */         double n = RotationUtils.fovFromEntity(slayerMob);
/* 161 */         double complimentSpeed = n * ThreadLocalRandom.current().nextDouble(-1.47328D, 2.48293D) / 100.0D;
/* 162 */         float val = (float)-(complimentSpeed + n / (101.0D - (float)ThreadLocalRandom.current().nextDouble(this.aimSpeed.getCurrent().intValue() - 4.723847D, this.aimSpeed.getCurrent().intValue())));
/* 163 */         mc.field_71439_g.field_70177_z += val;
/* 164 */       } else if (this.blatant.isEnabled()) {
/* 165 */         Rotation needed = RotationUtils.getNeededChange(RotationUtils.getRotation(slayerMob.func_174791_d()));
/* 166 */         mc.field_71439_g.field_70177_z += needed.getYaw();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @Event
/*     */   public void onWorldUnload(WorldUnloadEvent event) {
/* 173 */     slayerMob = null;
/*     */   }
/*     */   
/*     */   private int getSlayerHp() {
/* 177 */     int mobHp = -1;
/* 178 */     Pattern pattern = Pattern.compile(".+? (\\d+)[Mk]?");
/* 179 */     String stripped = SkyblockUtils.stripString(slayerStand.func_70005_c_());
/* 180 */     Matcher mat = pattern.matcher(stripped);
/*     */     
/* 182 */     if (mat.matches()) {
/*     */       try {
/* 184 */         mobHp = Integer.parseInt(mat.group(1));
/* 185 */       } catch (NumberFormatException numberFormatException) {}
/*     */     }
/*     */     
/* 188 */     return mobHp;
/*     */   }
/*     */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\modules\combat\SlayerAimbot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */