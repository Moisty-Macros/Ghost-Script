/*    */ package xyz.apfelmus.cheeto.client.modules.combat;
/*    */ import xyz.apfelmus.cf4m.annotation.Setting;
/*    */ import xyz.apfelmus.cf4m.annotation.module.Module;
/*    */ import xyz.apfelmus.cf4m.module.Category;
/*    */ import xyz.apfelmus.cheeto.client.settings.BooleanSetting;
/*    */ 
/*    */ @Module(name = "GhostArm", category = Category.COMBAT)
/*    */ public class GhostArm {
/*    */   @Setting(name = "Zombies")
/* 10 */   public BooleanSetting Zombies = new BooleanSetting(true);
/*    */   @Setting(name = "Players")
/* 12 */   public BooleanSetting Players = new BooleanSetting(true);
/*    */   @Setting(name = "HideMobs")
/* 14 */   public BooleanSetting HideMobs = new BooleanSetting(true);
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\modules\combat\GhostArm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */