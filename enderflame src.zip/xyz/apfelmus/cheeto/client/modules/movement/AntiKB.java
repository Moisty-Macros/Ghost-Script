package xyz.apfelmus.cheeto.client.modules.movement;

import xyz.apfelmus.cf4m.annotation.module.Module;
import xyz.apfelmus.cf4m.module.Category;

@Module(name = "AntiKB", category = Category.MOVEMENT)
public class AntiKB {}


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\modules\movement\AntiKB.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */