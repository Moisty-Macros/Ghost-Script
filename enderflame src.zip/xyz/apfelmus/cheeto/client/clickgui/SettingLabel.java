/*    */ package xyz.apfelmus.cheeto.client.clickgui;
/*    */ import gg.essential.elementa.UIComponent;
/*    */ import gg.essential.elementa.UIConstraints;
/*    */ import gg.essential.elementa.constraints.SuperConstraint;
/*    */ import gg.essential.elementa.constraints.YConstraint;
/*    */ import gg.essential.elementa.dsl.ComponentsKt;
/*    */ import gg.essential.elementa.dsl.UtilitiesKt;
/*    */ import java.awt.Color;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import xyz.apfelmus.cheeto.client.clickgui.settings.SettingComponent;
/*    */ 
/*    */ @Metadata(mv = {1, 6, 0}, k = 1, xi = 48, d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\020\000\n\002\b\b\030\0002\0020\001B\025\022\006\020\002\032\0020\003\022\006\020\004\032\0020\003¢\006\002\020\005R\016\020\002\032\0020\003X\004¢\006\002\n\000R\016\020\004\032\0020\003X\004¢\006\002\n\000R\033\020\006\032\0020\0018BX\002¢\006\f\n\004\b\t\020\n\032\004\b\007\020\b¨\006\013"}, d2 = {"Lxyz/apfelmus/cheeto/client/clickgui/SettingLabel;", "Lgg/essential/elementa/components/UIContainer;", "module", "", "setting", "(Ljava/lang/Object;Ljava/lang/Object;)V", "textContainer", "getTextContainer", "()Lgg/essential/elementa/components/UIContainer;", "textContainer$delegate", "Lkotlin/properties/ReadWriteProperty;", "Cheeto"})
/*    */ public final class SettingLabel extends UIContainer {
/*    */   public SettingLabel(@NotNull Object module, @NotNull Object setting) {
/* 15 */     this.module = module; this.setting = setting;
/* 16 */     UIComponent uIComponent2 = (UIComponent)new UIContainer(); int $i$f$constrain = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 70 */     UIComponent uIComponent4 = uIComponent2, $this$constrain_u24lambda_u2d0$iv = uIComponent4; int $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 71 */     UIConstraints uIConstraints1 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); SettingLabel settingLabel = this; int $i$a$-constrain-SettingLabel$textContainer$2 = 0; uIConstraints1.setY((YConstraint)new CenterConstraint()); uIConstraints1.setWidth((WidthConstraint)UtilitiesKt.percent(Integer.valueOf(75))); uIConstraints1.setHeight((HeightConstraint)new ChildBasedSizeConstraint(0.0F, 1, null)); settingLabel.textContainer$delegate = ComponentsKt.provideDelegate(ComponentsKt.childOf(uIComponent4, (UIComponent)this), this, $$delegatedProperties[0]); String str2 = CF4M.INSTANCE.settingManager.getName(this.module, this.setting); Intrinsics.checkNotNullExpressionValue(str2, "INSTANCE.settingManager.getName(module, setting)"); UIComponent uIComponent1 = (UIComponent)new UIText(str2, false, null, 6, null);
/*    */     $i$f$constrain = 0;
/* 73 */     $this$constrain_u24lambda_u2d0$iv = uIComponent4 = uIComponent1; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 74 */     UIConstraints $this$_init__u24lambda_u2d1 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); int $i$a$-constrain-SettingLabel$1 = 0; $this$_init__u24lambda_u2d1.setX((XConstraint)UtilitiesKt.pixels$default(Integer.valueOf(10), false, false, 3, null)); String str4 = CF4M.INSTANCE.settingManager.getDescription(this.module, this.setting); Intrinsics.checkNotNullExpressionValue(str4, "INSTANCE.settingManager.…cription(module, setting)"); $this$_init__u24lambda_u2d1.setY(((str4.length() == 0)) ? (YConstraint)new CenterConstraint() : (YConstraint)UtilitiesKt.pixels$default(Integer.valueOf(0), false, false, 3, null)); $this$_init__u24lambda_u2d1.setTextScale((HeightConstraint)UtilitiesKt.pixels$default(Float.valueOf(1.5F), false, false, 3, null)); Color color2 = ColorUtils.LABEL; Intrinsics.checkNotNullExpressionValue(color2, "LABEL"); $this$_init__u24lambda_u2d1.setColor((ColorConstraint)UtilitiesKt.toConstraint(color2)); $this$_init__u24lambda_u2d1.setFontProvider(DefaultFonts.getVANILLA_FONT_RENDERER()); ComponentsKt.childOf(uIComponent4, (UIComponent)getTextContainer()); String str1 = CF4M.INSTANCE.settingManager.getDescription(this.module, this.setting); Intrinsics.checkNotNullExpressionValue(str1, "INSTANCE.settingManager.…cription(module, setting)"); UIComponent $this$constrain$iv = (UIComponent)new UIWrappedText(str1, false, null, false, false, 0.0F, null, 126, null);
/*    */     $i$f$constrain = 0;
/* 76 */     $this$constrain_u24lambda_u2d0$iv = uIComponent4 = $this$constrain$iv; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 77 */     UIConstraints $this$_init__u24lambda_u2d2 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); int $i$a$-constrain-SettingLabel$2 = 0; $this$_init__u24lambda_u2d2.setX((XConstraint)UtilitiesKt.pixels$default(Integer.valueOf(10), false, false, 3, null)); $this$_init__u24lambda_u2d2.setY((YConstraint)ConstraintsKt.plus((SuperConstraint)new SiblingConstraint(0.0F, false, 3, null), (SuperConstraint)UtilitiesKt.pixels$default(Integer.valueOf(2), false, false, 3, null))); color2 = ColorUtils.SUB_LABEL; Intrinsics.checkNotNullExpressionValue(color2, "SUB_LABEL"); $this$_init__u24lambda_u2d2.setColor((ColorConstraint)UtilitiesKt.toConstraint(color2)); $this$_init__u24lambda_u2d2.setFontProvider(DefaultFonts.getVANILLA_FONT_RENDERER()); ComponentsKt.childOf(uIComponent4, (UIComponent)getTextContainer()); $this$constrain$iv = (UIComponent)this;
/*    */     $i$f$constrain = 0;
/* 79 */     $this$constrain_u24lambda_u2d0$iv = uIComponent4 = $this$constrain$iv; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 80 */     UIConstraints $this$_init__u24lambda_u2d3 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); int $i$a$-constrain-SettingLabel$3 = 0; $this$_init__u24lambda_u2d3.setX((XConstraint)UtilitiesKt.pixels$default(Integer.valueOf(10), false, false, 3, null)); $this$_init__u24lambda_u2d3.setY((YConstraint)ConstraintsKt.plus((SuperConstraint)new SiblingConstraint(0.0F, false, 3, null), (SuperConstraint)UtilitiesKt.pixels$default(Integer.valueOf(10), false, false, 3, null))); $this$_init__u24lambda_u2d3.setWidth((WidthConstraint)ConstraintsKt.minus((SuperConstraint)new FillConstraint(false), (SuperConstraint)UtilitiesKt.pixels$default(Integer.valueOf(10), false, false, 3, null))); $this$_init__u24lambda_u2d3.setHeight((HeightConstraint)UtilitiesKt.pixels$default(Integer.valueOf(45), false, false, 3, null)); Color color1 = ColorUtils.M_BORDER; Intrinsics.checkNotNullExpressionValue(color1, "M_BORDER"); ComponentsKt.effect(uIComponent4, (Effect)new OutlineEffect(color1, 1.0F, false, false, null, 28, null)); Object object = this.setting; Integer integer = ((IntegerSetting)this.setting).getCurrent(); Intrinsics.checkNotNullExpressionValue(integer, "setting.current"); integer = ((IntegerSetting)this.setting).getMin(); Intrinsics.checkNotNullExpressionValue(integer, "setting.min"); integer = ((IntegerSetting)this.setting).getMax(); Intrinsics.checkNotNullExpressionValue(integer, "setting.max"); Float float_ = ((FloatSetting)this.setting).getCurrent(); Intrinsics.checkNotNullExpressionValue(float_, "setting.current"); float_ = ((FloatSetting)this.setting).getMin(); Intrinsics.checkNotNullExpressionValue(float_, "setting.min"); float_ = ((FloatSetting)this.setting).getMax(); Intrinsics.checkNotNullExpressionValue(float_, "setting.max"); List list = ((ModeSetting)this.setting).getModes(); Intrinsics.checkNotNullExpressionValue(list, "setting.modes"); String str3 = ((StringSetting)this.setting).getCurrent(); Intrinsics.checkNotNullExpressionValue(str3, "setting.current"); SettingComponent comp = (object instanceof BooleanSetting) ? (SettingComponent)new SwitchComponent(((BooleanSetting)this.setting).isEnabled()) : ((object instanceof IntegerSetting) ? (SettingComponent)new SliderComponent(integer.intValue(), integer.intValue(), integer.intValue()) : ((object instanceof FloatSetting) ? (SettingComponent)new DecimalSliderComponent(float_.floatValue(), float_.floatValue(), float_.floatValue(), 1) : ((object instanceof ModeSetting) ? (SettingComponent)new SelectorComponent(((ModeSetting)this.setting).getModes().indexOf(((ModeSetting)this.setting).getCurrent()), list) : ((object instanceof StringSetting) ? (SettingComponent)new TextComponent(str3, "<empty>", false, false) : (SettingComponent)new SwitchComponent(true))))); UIComponent uIComponent3 = (UIComponent)comp;
/*    */     int i = 0;
/* 82 */     UIComponent uIComponent5 = uIComponent3, uIComponent6 = uIComponent5; int j = 0;
/* 83 */     UIConstraints $this$_init__u24lambda_u2d4 = uIComponent6.getConstraints(); int $i$a$-constrain-SettingLabel$4 = 0;
/*    */     $this$_init__u24lambda_u2d4.setX((XConstraint)UtilitiesKt.pixels$default(Integer.valueOf(12), true, false, 2, null));
/*    */     $this$_init__u24lambda_u2d4.setY((comp instanceof SwitchComponent) ? (YConstraint)UtilitiesKt.pixels$default(Integer.valueOf(18), false, false, 3, null) : (YConstraint)UtilitiesKt.pixels$default(Integer.valueOf(12), false, false, 3, null));
/*    */     ComponentsKt.childOf(uIComponent5, (UIComponent)this);
/*    */     comp.onValueChange(new Function1<Object, Unit>() {
/*    */           public final void invoke(@Nullable Object it) {
/*    */             Object object = SettingLabel.this.setting;
/*    */             if (object instanceof BooleanSetting) {
/*    */               if (it == null)
/*    */                 throw new NullPointerException("null cannot be cast to non-null type kotlin.Boolean"); 
/*    */               it.setState(((Boolean)it).booleanValue());
/*    */             } else if (object instanceof IntegerSetting) {
/*    */               if (it == null)
/*    */                 throw new NullPointerException("null cannot be cast to non-null type kotlin.Int"); 
/*    */               it.setCurrent(Integer.valueOf(((Integer)it).intValue()));
/*    */             } else if (object instanceof FloatSetting) {
/*    */               if (it == null)
/*    */                 throw new NullPointerException("null cannot be cast to non-null type kotlin.Float"); 
/*    */               it.setCurrent(Float.valueOf(((Float)it).floatValue()));
/*    */             } else if (object instanceof ModeSetting) {
/*    */               if (it == null)
/*    */                 throw new NullPointerException("null cannot be cast to non-null type kotlin.Int"); 
/*    */               ((ModeSetting)SettingLabel.this.setting).getModes().setCurrent(it.get(((Integer)it).intValue()));
/*    */             } else if (object instanceof StringSetting) {
/*    */               if (it == null)
/*    */                 throw new NullPointerException("null cannot be cast to non-null type kotlin.String"); 
/*    */               it.setCurrent((String)it);
/*    */             } 
/*    */           }
/*    */         });
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   private final Object module;
/*    */   @NotNull
/*    */   private final Object setting;
/*    */   @NotNull
/*    */   private final ReadWriteProperty textContainer$delegate;
/*    */   
/*    */   private final UIContainer getTextContainer() {
/*    */     return (UIContainer)this.textContainer$delegate.getValue(this, $$delegatedProperties[0]);
/*    */   }
/*    */   
/*    */   static {
/*    */     KProperty[] arrayOfKProperty = new KProperty[1];
/*    */     arrayOfKProperty[0] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(SettingLabel.class, "textContainer", "getTextContainer()Lgg/essential/elementa/components/UIContainer;", 0));
/*    */     $$delegatedProperties = (KProperty<Object>[])arrayOfKProperty;
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\clickgui\SettingLabel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */