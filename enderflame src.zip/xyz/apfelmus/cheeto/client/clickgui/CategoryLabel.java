/*     */ package xyz.apfelmus.cheeto.client.clickgui;
/*     */ @Metadata(mv = {1, 6, 0}, k = 1, xi = 48, d1 = {"\0000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\007\n\002\020\013\n\002\b\004\n\002\030\002\n\002\b\t\n\002\020\002\n\002\b\002\030\0002\0020\001B\025\022\006\020\002\032\0020\003\022\006\020\004\032\0020\005¢\006\002\020\006J\006\020\033\032\0020\034J\006\020\035\032\0020\034R\016\020\004\032\0020\005X\004¢\006\002\n\000R\032\020\007\032\0020\005X\016¢\006\016\n\000\032\004\b\b\020\t\"\004\b\n\020\013R\016\020\002\032\0020\003X\004¢\006\002\n\000R\032\020\f\032\0020\rX\016¢\006\016\n\000\032\004\b\f\020\016\"\004\b\017\020\020R\033\020\021\032\0020\0228BX\002¢\006\f\n\004\b\025\020\026\032\004\b\023\020\024R\033\020\027\032\0020\0018BX\002¢\006\f\n\004\b\032\020\026\032\004\b\030\020\031¨\006\036"}, d2 = {"Lxyz/apfelmus/cheeto/client/clickgui/CategoryLabel;", "Lgg/essential/elementa/components/UIContainer;", "gui", "Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;", "category", "Lxyz/apfelmus/cf4m/module/Category;", "(Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;Lxyz/apfelmus/cf4m/module/Category;)V", "categoryName", "getCategoryName", "()Lxyz/apfelmus/cf4m/module/Category;", "setCategoryName", "(Lxyz/apfelmus/cf4m/module/Category;)V", "isSelected", "", "()Z", "setSelected", "(Z)V", "text", "Lgg/essential/elementa/components/UIText;", "getText", "()Lgg/essential/elementa/components/UIText;", "text$delegate", "Lkotlin/properties/ReadWriteProperty;", "textContainer", "getTextContainer", "()Lgg/essential/elementa/components/UIContainer;", "textContainer$delegate", "deselect", "", "select", "Cheeto"})
/*     */ public final class CategoryLabel extends UIContainer {
/*     */   @NotNull
/*     */   private final ConfigGUI gui;
/*     */   @NotNull
/*     */   private final Category category;
/*     */   @NotNull
/*     */   private Category categoryName;
/*     */   @NotNull
/*     */   private final ReadWriteProperty textContainer$delegate;
/*     */   @NotNull
/*     */   private final ReadWriteProperty text$delegate;
/*     */   private boolean isSelected;
/*     */   
/*  16 */   public CategoryLabel(@NotNull ConfigGUI gui, @NotNull Category category) { this.gui = gui; this.category = category;
/*  17 */     this.categoryName = this.category;
/*     */ 
/*     */     
/*  20 */     Color color2 = ColorUtils.M_BORDER; Intrinsics.checkNotNullExpressionValue(color2, "M_BORDER"); UIComponent uIComponent2 = (UIComponent)new UIBlock(color2); int i = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  99 */     UIComponent uIComponent4 = uIComponent2, $this$constrain_u24lambda_u2d0$iv = uIComponent4; int $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 100 */     UIConstraints $this$_init__u24lambda_u2d0 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); int $i$a$-constrain-CategoryLabel$1 = 0; $this$_init__u24lambda_u2d0.setX((XConstraint)new SiblingConstraint(0.0F, false, 3, null)); $this$_init__u24lambda_u2d0.setWidth((WidthConstraint)UtilitiesKt.pixel$default(Integer.valueOf(1), false, false, 3, null)); $this$_init__u24lambda_u2d0.setHeight((HeightConstraint)UtilitiesKt.percent(Integer.valueOf(100))); ComponentsKt.childOf(uIComponent4, (UIComponent)this); uIComponent2 = (UIComponent)new UIContainer();
/*     */     i = 0;
/* 102 */     $this$constrain_u24lambda_u2d0$iv = uIComponent4 = uIComponent2; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 103 */     $this$_init__u24lambda_u2d0 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); CategoryLabel categoryLabel = this; int $i$a$-constrain-CategoryLabel$textContainer$2 = 0; $this$_init__u24lambda_u2d0.setX((XConstraint)new SiblingConstraint(0.0F, false, 3, null)); $this$_init__u24lambda_u2d0.setY((YConstraint)new CenterConstraint()); $this$_init__u24lambda_u2d0.setWidth((WidthConstraint)ConstraintsKt.plus((SuperConstraint)new ChildBasedMaxSizeConstraint(), (SuperConstraint)UtilitiesKt.pixels$default(Integer.valueOf(20), false, false, 3, null))); categoryLabel.textContainer$delegate = ComponentsKt.provideDelegate(ComponentsKt.childOf(uIComponent4, (UIComponent)this), this, $$delegatedProperties[0]); String str3 = this.category.name().toLowerCase(Locale.ROOT); Intrinsics.checkNotNullExpressionValue(str3, "this as java.lang.String).toLowerCase(Locale.ROOT)"); String str1 = str3;
/*     */     char c = str1.charAt(0);
/* 105 */     StringBuilder stringBuilder = new StringBuilder(); categoryLabel = this; int $i$a$-replaceFirstCharWithCharSequence-CategoryLabel$text$2 = 0; String str5 = CharsKt.titlecase(c), str2 = str1; $i$a$-replaceFirstCharWithCharSequence-CategoryLabel$text$2 = 1; String str4 = str2.substring($i$a$-replaceFirstCharWithCharSequence-CategoryLabel$text$2); Intrinsics.checkNotNullExpressionValue(str4, "this as java.lang.String).substring(startIndex)"); DefaultConstructorMarker defaultConstructorMarker = null; byte b = 6; Color color4 = null; boolean bool = false; String str6 = ((str1.length() > 0)) ? stringBuilder.append(str5).append(str4).toString() : str1; UIComponent uIComponent1 = (UIComponent)new UIText(str6, bool, color4, b, defaultConstructorMarker); int $i$f$constrain = 0;
/* 106 */     UIComponent uIComponent3 = uIComponent1; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 107 */     UIConstraints $this$textContainer_delegate_u24lambda_u2d1 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); categoryLabel = categoryLabel; int $i$a$-constrain-CategoryLabel$text$3 = 0; $this$textContainer_delegate_u24lambda_u2d1.setX((XConstraint)new CenterConstraint()); $this$textContainer_delegate_u24lambda_u2d1.setY((YConstraint)new CenterConstraint()); Color color3 = ColorUtils.LABEL; Intrinsics.checkNotNullExpressionValue(color3, "LABEL"); $this$textContainer_delegate_u24lambda_u2d1.setColor((ColorConstraint)UtilitiesKt.toConstraint(color3)); $this$textContainer_delegate_u24lambda_u2d1.setTextScale((HeightConstraint)UtilitiesKt.pixels$default(Float.valueOf(1.5F), false, false, 3, null)); $this$textContainer_delegate_u24lambda_u2d1.setFontProvider(DefaultFonts.getVANILLA_FONT_RENDERER()); categoryLabel.text$delegate = ComponentsKt.provideDelegate(ComponentsKt.childOf(uIComponent3, (UIComponent)getTextContainer()), this, $$delegatedProperties[1]); Color color1 = ColorUtils.M_BORDER; Intrinsics.checkNotNullExpressionValue(color1, "M_BORDER"); UIComponent $this$constrain$iv = (UIComponent)new UIBlock(color1);
/*     */     $i$f$constrain = 0;
/* 109 */     $this$constrain_u24lambda_u2d0$iv = uIComponent3 = $this$constrain$iv; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 110 */     UIConstraints $this$_init__u24lambda_u2d3 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); int $i$a$-constrain-CategoryLabel$2 = 0; $this$_init__u24lambda_u2d3.setX((XConstraint)ConstraintsKt.minus((SuperConstraint)new SiblingConstraint(0.0F, false, 3, null), (SuperConstraint)UtilitiesKt.pixel$default(Integer.valueOf(1), false, false, 3, null))); $this$_init__u24lambda_u2d3.setWidth((WidthConstraint)UtilitiesKt.pixel$default(Integer.valueOf(1), false, false, 3, null)); $this$_init__u24lambda_u2d3.setHeight((HeightConstraint)UtilitiesKt.percent(Integer.valueOf(100))); ComponentsKt.childOf(uIComponent3, (UIComponent)this); $this$constrain$iv = (UIComponent)this;
/*     */     $i$f$constrain = 0;
/* 112 */     $this$constrain_u24lambda_u2d0$iv = uIComponent3 = $this$constrain$iv; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 113 */     UIConstraints $this$_init__u24lambda_u2d4 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); int $i$a$-constrain-CategoryLabel$3 = 0; $this$_init__u24lambda_u2d4.setX((XConstraint)new SiblingConstraint(0.0F, false, 3, null)); $this$_init__u24lambda_u2d4.setY((YConstraint)new CenterConstraint()); $this$_init__u24lambda_u2d4.setWidth((WidthConstraint)new ChildBasedMaxSizeConstraint()); $this$_init__u24lambda_u2d4.setHeight((HeightConstraint)UtilitiesKt.pixels$default(Integer.valueOf(14), false, false, 3, null)); UIComponent $this$onLeftClick$iv = (UIComponent)this;
/*     */     int $i$f$onLeftClick = 0;
/* 115 */     $this$onLeftClick$iv.onMouseClick(new CategoryLabel$special$$inlined$onLeftClick$1(this)); onMouseEnter(new Function1<UIComponent, Unit>() {
/*     */           public final void invoke(@NotNull UIComponent $this$onMouseEnter) { Intrinsics.checkNotNullParameter($this$onMouseEnter, "$this$onMouseEnter"); if (!CategoryLabel.this.isSelected()) { UIComponent $this$animate$iv = (UIComponent)CategoryLabel.this.getText(); int $i$f$animate = 0; UIComponent uIComponent1 = $this$animate$iv, $this$animate_u24lambda_u2d0$iv = uIComponent1; int $i$a$-apply-AnimationsKt$animate$1$iv = 0; AnimatingConstraints anim$iv = $this$animate_u24lambda_u2d0$iv.makeAnimation(); AnimatingConstraints $this$invoke_u24lambda_u2d0 = anim$iv; int $i$a$-animate-CategoryLabel$5$1 = 0; Color color = ColorUtils.TEXT_HOVERED; Intrinsics.checkNotNullExpressionValue(color, "TEXT_HOVERED"); AnimatingConstraints.setColorAnimation$default($this$invoke_u24lambda_u2d0, (AnimationStrategy)Animations.OUT_EXP, 0.5F, (ColorConstraint)UtilitiesKt.toConstraint(color), 0.0F, 8, null); $this$animate_u24lambda_u2d0$iv.animateTo(anim$iv); }  }
/*     */         }); onMouseLeave(new Function1<UIComponent, Unit>() {
/*     */           public final void invoke(@NotNull UIComponent $this$onMouseLeave) { Intrinsics.checkNotNullParameter($this$onMouseLeave, "$this$onMouseLeave"); if (!CategoryLabel.this.isSelected()) { UIComponent $this$animate$iv = (UIComponent)CategoryLabel.this.getText(); int $i$f$animate = 0; UIComponent uIComponent1 = $this$animate$iv, $this$animate_u24lambda_u2d0$iv = uIComponent1; int $i$a$-apply-AnimationsKt$animate$1$iv = 0; AnimatingConstraints anim$iv = $this$animate_u24lambda_u2d0$iv.makeAnimation(); AnimatingConstraints $this$invoke_u24lambda_u2d0 = anim$iv; int $i$a$-animate-CategoryLabel$6$1 = 0; Color color = ColorUtils.LABEL; Intrinsics.checkNotNullExpressionValue(color, "LABEL"); AnimatingConstraints.setColorAnimation$default($this$invoke_u24lambda_u2d0, (AnimationStrategy)Animations.OUT_EXP, 0.5F, (ColorConstraint)UtilitiesKt.toConstraint(color), 0.0F, 8, null); $this$animate_u24lambda_u2d0$iv.animateTo(anim$iv); }  }
/*     */         }); }
/* 120 */   @NotNull public final Category getCategoryName() { return this.categoryName; } public final void setCategoryName(@NotNull Category <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); this.categoryName = <set-?>; } private final UIContainer getTextContainer() { return (UIContainer)this.textContainer$delegate.getValue(this, $$delegatedProperties[0]); } public final void select() { this.gui.selectCategory(this.category); this.isSelected = true; UIComponent $this$animate$iv = (UIComponent)getText(); int $i$f$animate = 0; UIComponent uIComponent1 = $this$animate$iv, $this$animate_u24lambda_u2d0$iv = uIComponent1; int $i$a$-apply-AnimationsKt$animate$1$iv = 0;
/* 121 */     AnimatingConstraints anim$iv = $this$animate_u24lambda_u2d0$iv.makeAnimation();
/* 122 */     AnimatingConstraints $this$select_u24lambda_u2d6 = anim$iv; int $i$a$-animate-CategoryLabel$select$1 = 0; Color color = Color.WHITE; Intrinsics.checkNotNullExpressionValue(color, "WHITE"); AnimatingConstraints.setColorAnimation$default($this$select_u24lambda_u2d6, (AnimationStrategy)Animations.OUT_EXP, 0.5F, (ColorConstraint)UtilitiesKt.toConstraint(color), 0.0F, 8, null);
/* 123 */     $this$animate_u24lambda_u2d0$iv.animateTo(anim$iv); }
/*     */   static { KProperty[] arrayOfKProperty = new KProperty[2]; arrayOfKProperty[0] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(CategoryLabel.class, "textContainer", "getTextContainer()Lgg/essential/elementa/components/UIContainer;", 0)); arrayOfKProperty[1] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(CategoryLabel.class, "text", "getText()Lgg/essential/elementa/components/UIText;", 0)); $$delegatedProperties = (KProperty<Object>[])arrayOfKProperty; }
/* 125 */   private final UIText getText() { return (UIText)this.text$delegate.getValue(this, $$delegatedProperties[1]); } public final boolean isSelected() { return this.isSelected; } public final void setSelected(boolean <set-?>) { this.isSelected = <set-?>; } public final void deselect() { this.isSelected = false; UIComponent $this$animate$iv = (UIComponent)getText(); int $i$f$animate = 0; UIComponent uIComponent1 = $this$animate$iv, $this$animate_u24lambda_u2d0$iv = uIComponent1; int $i$a$-apply-AnimationsKt$animate$1$iv = 0;
/* 126 */     AnimatingConstraints anim$iv = $this$animate_u24lambda_u2d0$iv.makeAnimation();
/* 127 */     AnimatingConstraints $this$deselect_u24lambda_u2d7 = anim$iv; int $i$a$-animate-CategoryLabel$deselect$1 = 0; Color color = ColorUtils.LABEL; Intrinsics.checkNotNullExpressionValue(color, "LABEL"); AnimatingConstraints.setColorAnimation$default($this$deselect_u24lambda_u2d7, (AnimationStrategy)Animations.OUT_EXP, 0.5F, (ColorConstraint)UtilitiesKt.toConstraint(color), 0.0F, 8, null);
/* 128 */     $this$animate_u24lambda_u2d0$iv.animateTo(anim$iv); }
/*     */ 
/*     */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\clickgui\CategoryLabel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */