/*    */ package xyz.apfelmus.cheeto.client.clickgui.settings;
/*    */ import gg.essential.elementa.UIComponent;
/*    */ import gg.essential.elementa.UIConstraints;
/*    */ import gg.essential.elementa.components.UIText;
/*    */ import gg.essential.elementa.dsl.ComponentsKt;
/*    */ import gg.essential.elementa.dsl.UtilitiesKt;
/*    */ import java.awt.Color;
/*    */ import kotlin.Unit;
/*    */ import kotlin.reflect.KProperty;
/*    */ 
/*    */ @Metadata(mv = {1, 6, 0}, k = 1, xi = 48, d1 = {"\000\"\n\002\030\002\n\002\030\002\n\000\n\002\020\b\n\002\b\004\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\004\030\0002\0020\001B\035\022\006\020\002\032\0020\003\022\006\020\004\032\0020\003\022\006\020\005\032\0020\003¢\006\002\020\006R\033\020\007\032\0020\b8BX\002¢\006\f\n\004\b\013\020\f\032\004\b\t\020\nR\033\020\r\032\0020\0168TX\002¢\006\f\n\004\b\021\020\f\032\004\b\017\020\020¨\006\022"}, d2 = {"Lxyz/apfelmus/cheeto/client/clickgui/settings/SliderComponent;", "Lxyz/apfelmus/cheeto/client/clickgui/settings/AbstractSliderComponent;", "initialValue", "", "min", "max", "(III)V", "currentValueText", "Lgg/essential/elementa/components/UIText;", "getCurrentValueText", "()Lgg/essential/elementa/components/UIText;", "currentValueText$delegate", "Lkotlin/properties/ReadWriteProperty;", "slider", "Lxyz/apfelmus/cheeto/client/clickgui/settings/Slider;", "getSlider", "()Lxyz/apfelmus/cheeto/client/clickgui/settings/Slider;", "slider$delegate", "Cheeto"})
/*    */ public final class SliderComponent extends AbstractSliderComponent {
/*    */   public SliderComponent(int initialValue, int min, int max) {
/* 14 */     UIComponent $this$constrain$iv = (UIComponent)new UIText(String.valueOf(min), false, null, 6, null); int $i$f$constrain = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 53 */     UIComponent uIComponent1 = $this$constrain$iv, $this$constrain_u24lambda_u2d0$iv = uIComponent1; int $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 54 */     UIConstraints $this$_init__u24lambda_u2d0 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); int $i$a$-constrain-SliderComponent$1 = 0; $this$_init__u24lambda_u2d0.setY((YConstraint)new CenterConstraint()); Color color = ColorUtils.LABEL; Intrinsics.checkNotNullExpressionValue(color, "LABEL"); $this$_init__u24lambda_u2d0.setColor((ColorConstraint)UtilitiesKt.toConstraint(color)); $this$_init__u24lambda_u2d0.setFontProvider(DefaultFonts.getVANILLA_FONT_RENDERER()); ComponentsKt.childOf(uIComponent1, (UIComponent)this); $this$constrain$iv = (UIComponent)new Slider((initialValue - min) / (max - min));
/*    */     $i$f$constrain = 0;
/* 56 */     $this$constrain_u24lambda_u2d0$iv = uIComponent1 = $this$constrain$iv; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 57 */     $this$_init__u24lambda_u2d0 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); SliderComponent sliderComponent = this; int $i$a$-constrain-SliderComponent$slider$2 = 0; $this$_init__u24lambda_u2d0.setX((XConstraint)new SiblingConstraint(0.0F, false, 3, null)); $this$_init__u24lambda_u2d0.setWidth((WidthConstraint)UtilitiesKt.pixels$default(Integer.valueOf(60), false, false, 3, null)); $this$_init__u24lambda_u2d0.setHeight((HeightConstraint)UtilitiesKt.pixels$default(Integer.valueOf(12), false, false, 3, null)); sliderComponent.slider$delegate = ComponentsKt.provideDelegate(ComponentsKt.childOf(uIComponent1, (UIComponent)this), this, $$delegatedProperties[0]); $this$constrain$iv = (UIComponent)new UIText(String.valueOf(max), false, null, 6, null);
/*    */     $i$f$constrain = 0;
/* 59 */     $this$constrain_u24lambda_u2d0$iv = uIComponent1 = $this$constrain$iv; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 60 */     UIConstraints $this$_init__u24lambda_u2d2 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); int $i$a$-constrain-SliderComponent$2 = 0; $this$_init__u24lambda_u2d2.setX((XConstraint)new SiblingConstraint(0.0F, false, 3, null)); $this$_init__u24lambda_u2d2.setY((YConstraint)new CenterConstraint()); color = ColorUtils.LABEL; Intrinsics.checkNotNullExpressionValue(color, "LABEL"); $this$_init__u24lambda_u2d2.setColor((ColorConstraint)UtilitiesKt.toConstraint(color)); $this$_init__u24lambda_u2d2.setFontProvider(DefaultFonts.getVANILLA_FONT_RENDERER()); ComponentsKt.childOf(uIComponent1, (UIComponent)this); $this$constrain$iv = (UIComponent)new UIText(String.valueOf(initialValue), false, null, 6, null);
/*    */     $i$f$constrain = 0;
/* 62 */     $this$constrain_u24lambda_u2d0$iv = uIComponent1 = $this$constrain$iv; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 63 */     UIConstraints $this$slider_delegate_u24lambda_u2d1 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); sliderComponent = this; int $i$a$-constrain-SliderComponent$currentValueText$2 = 0;
/*    */     $this$slider_delegate_u24lambda_u2d1.setX((XConstraint)ConstraintsKt.boundTo((SuperConstraint)new CenterConstraint(), (UIComponent)getSlider().getGrabBox()));
/*    */     $this$slider_delegate_u24lambda_u2d1.setY((YConstraint)new RelativeConstraint(1.5F));
/*    */     color = ColorUtils.LABEL;
/*    */     Intrinsics.checkNotNullExpressionValue(color, "LABEL");
/*    */     $this$slider_delegate_u24lambda_u2d1.setColor((ColorConstraint)UtilitiesKt.toConstraint(color));
/*    */     $this$slider_delegate_u24lambda_u2d1.setFontProvider(DefaultFonts.getVANILLA_FONT_RENDERER());
/*    */     sliderComponent.currentValueText$delegate = ComponentsKt.provideDelegate(ComponentsKt.childOf(uIComponent1, (UIComponent)getSlider()), this, $$delegatedProperties[1]);
/*    */     getSlider().onValueChange(new Function1<Float, Unit>(max, this) {
/*    */           public final void invoke(float newPercentage) {
/*    */             int newValue = MathKt.roundToInt(this.$min + newPercentage * (this.$max - this.$min));
/*    */             SettingComponent.changeValue$default(SliderComponent.this, Integer.valueOf(newValue), false, 2, null);
/*    */             SliderComponent.this.getCurrentValueText().setText(String.valueOf(newValue));
/*    */           }
/*    */         });
/*    */     sliderInit();
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   private final ReadWriteProperty slider$delegate;
/*    */   @NotNull
/*    */   private final ReadWriteProperty currentValueText$delegate;
/*    */   
/*    */   @NotNull
/*    */   protected Slider getSlider() {
/*    */     return (Slider)this.slider$delegate.getValue(this, $$delegatedProperties[0]);
/*    */   }
/*    */   
/*    */   static {
/*    */     KProperty[] arrayOfKProperty = new KProperty[2];
/*    */     arrayOfKProperty[0] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(SliderComponent.class, "slider", "getSlider()Lxyz/apfelmus/cheeto/client/clickgui/settings/Slider;", 0));
/*    */     arrayOfKProperty[1] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(SliderComponent.class, "currentValueText", "getCurrentValueText()Lgg/essential/elementa/components/UIText;", 0));
/*    */     $$delegatedProperties = (KProperty<Object>[])arrayOfKProperty;
/*    */   }
/*    */   
/*    */   private final UIText getCurrentValueText() {
/*    */     return (UIText)this.currentValueText$delegate.getValue(this, $$delegatedProperties[1]);
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\clickgui\settings\SliderComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */