/*    */ package xyz.apfelmus.cheeto.client.clickgui.settings;
/*    */ import gg.essential.elementa.UIComponent;
/*    */ import java.util.List;
/*    */ 
/*    */ @Metadata(mv = {1, 6, 0}, k = 1, xi = 48, d1 = {"\0000\n\002\030\002\n\002\030\002\n\000\n\002\020\b\n\000\n\002\020 \n\002\020\016\n\002\b\002\n\002\030\002\n\002\b\005\n\002\020\002\n\000\n\002\020\013\n\000\030\0002\0020\001B\033\022\006\020\002\032\0020\003\022\f\020\004\032\b\022\004\022\0020\0060\005¢\006\002\020\007J\020\020\016\032\0020\0172\006\020\020\032\0020\021H\026R\033\020\b\032\0020\t8@X\002¢\006\f\n\004\b\f\020\r\032\004\b\n\020\013¨\006\022"}, d2 = {"Lxyz/apfelmus/cheeto/client/clickgui/settings/SelectorComponent;", "Lxyz/apfelmus/cheeto/client/clickgui/settings/SettingComponent;", "initialSelection", "", "options", "", "", "(ILjava/util/List;)V", "dropDown", "Lxyz/apfelmus/cheeto/client/clickgui/settings/DropDown;", "getDropDown$Cheeto", "()Lxyz/apfelmus/cheeto/client/clickgui/settings/DropDown;", "dropDown$delegate", "Lkotlin/properties/ReadWriteProperty;", "closePopups", "", "instantly", "", "Cheeto"})
/*    */ public final class SelectorComponent extends SettingComponent {
/*    */   public SelectorComponent(int initialSelection, @NotNull List options) {
/*  8 */     List list1 = options; int i = initialSelection; SelectorComponent selectorComponent = this; int $i$f$map = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 26 */     List list2 = list1; Collection<String> destination$iv$iv = new ArrayList(CollectionsKt.collectionSizeOrDefault(list1, 10)); int $i$f$mapTo = 0;
/* 27 */     for (Object item$iv$iv : list2) {
/* 28 */       String str = (String)item$iv$iv; Collection<String> collection = destination$iv$iv; int $i$a$-map-SelectorComponent$dropDown$2 = 0; collection.add(I18n.func_135052_a(str, new Object[0]));
/* 29 */     }  List list3 = (List)destination$iv$iv; DefaultConstructorMarker defaultConstructorMarker = null; byte b = 12; float f = 0.0F; OutlineEffect outlineEffect = null; List list4 = list3; int j = i; selectorComponent.dropDown$delegate = ComponentsKt.provideDelegate(ComponentsKt.childOf((UIComponent)new DropDown(j, list4, outlineEffect, f, b, defaultConstructorMarker), (UIComponent)this), this, $$delegatedProperties[0]); UIComponent $this$constrain$iv = (UIComponent)this; int $i$f$constrain = 0;
/* 30 */     UIComponent uIComponent1 = $this$constrain$iv, $this$constrain_u24lambda_u2d0$iv = uIComponent1; int $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 31 */     UIConstraints $this$_init__u24lambda_u2d1 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); int $i$a$-constrain-SelectorComponent$1 = 0;
/*    */     $this$_init__u24lambda_u2d1.setY((YConstraint)UtilitiesKt.pixels$default(Integer.valueOf(18), false, false, 3, null));
/*    */     $this$_init__u24lambda_u2d1.setWidth((WidthConstraint)new ChildBasedSizeConstraint(0.0F, 1, null));
/*    */     $this$_init__u24lambda_u2d1.setHeight((HeightConstraint)new ChildBasedSizeConstraint(0.0F, 1, null));
/*    */     getDropDown$Cheeto().onValueChange(new Function1<Integer, Unit>() {
/*    */           public final void invoke(int newValue) {
/*    */             SettingComponent.changeValue$default(SelectorComponent.this, Integer.valueOf(newValue), false, 2, null);
/*    */           }
/*    */         });
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   private final ReadWriteProperty dropDown$delegate;
/*    */   
/*    */   @NotNull
/*    */   public final DropDown getDropDown$Cheeto() {
/*    */     return (DropDown)this.dropDown$delegate.getValue(this, $$delegatedProperties[0]);
/*    */   }
/*    */   
/*    */   static {
/*    */     KProperty[] arrayOfKProperty = new KProperty[1];
/*    */     arrayOfKProperty[0] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(SelectorComponent.class, "dropDown", "getDropDown$Cheeto()Lxyz/apfelmus/cheeto/client/clickgui/settings/DropDown;", 0));
/*    */     $$delegatedProperties = (KProperty<Object>[])arrayOfKProperty;
/*    */   }
/*    */   
/*    */   public void closePopups(boolean instantly) {
/*    */     getDropDown$Cheeto().collapse(true, instantly);
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\clickgui\settings\SelectorComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */