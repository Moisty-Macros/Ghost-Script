/*     */ package xyz.apfelmus.cheeto.client.clickgui.settings;
/*     */ import gg.essential.elementa.UIComponent;
/*     */ import gg.essential.elementa.UIConstraints;
/*     */ import gg.essential.elementa.constraints.SuperConstraint;
/*     */ import gg.essential.elementa.constraints.animation.AnimatingConstraints;
/*     */ import gg.essential.elementa.dsl.UtilitiesKt;
/*     */ import gg.essential.vigilance.data.PropertyData;
/*     */ import java.awt.Color;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function0;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.reflect.KProperty;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ @Metadata(mv = {1, 6, 0}, k = 1, xi = 48, d1 = {"\000<\n\002\030\002\n\002\030\002\n\000\n\002\020\016\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\t\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\005\030\000 \0372\0020\001:\001\037B\033\b\026\022\n\b\002\020\002\032\004\030\0010\003\022\006\020\004\032\0020\005¢\006\002\020\006B\037\022\n\b\002\020\002\032\004\030\0010\003\022\f\020\007\032\b\022\004\022\0020\t0\b¢\006\002\020\nJ\024\020\034\032\0020\0002\f\020\035\032\b\022\004\022\0020\0030\033J\006\020\027\032\0020\003J\016\020\036\032\0020\0002\006\020\025\032\0020\003R\024\020\007\032\b\022\004\022\0020\t0\bX\004¢\006\002\n\000R\033\020\013\032\0020\f8BX\002¢\006\f\n\004\b\017\020\020\032\004\b\r\020\016R\033\020\021\032\0020\f8BX\002¢\006\f\n\004\b\023\020\020\032\004\b\022\020\016R\024\020\024\032\b\022\004\022\0020\t0\bX\016¢\006\002\n\000R\033\020\025\032\0020\0268BX\002¢\006\f\n\004\b\031\020\020\032\004\b\027\020\030R\024\020\032\032\b\022\004\022\0020\0030\033X\016¢\006\002\n\000¨\006 "}, d2 = {"Lxyz/apfelmus/cheeto/client/clickgui/settings/ButtonComponent;", "Lxyz/apfelmus/cheeto/client/clickgui/settings/SettingComponent;", "placeholder", "", "data", "Lgg/essential/vigilance/data/PropertyData;", "(Ljava/lang/String;Lgg/essential/vigilance/data/PropertyData;)V", "callback", "Lkotlin/Function0;", "", "(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V", "container", "Lgg/essential/elementa/components/UIRoundedRectangle;", "getContainer", "()Lgg/essential/elementa/components/UIRoundedRectangle;", "container$delegate", "Lkotlin/properties/ReadWriteProperty;", "contentContainer", "getContentContainer", "contentContainer$delegate", "listener", "text", "Lgg/essential/elementa/components/UIWrappedText;", "getText", "()Lgg/essential/elementa/components/UIWrappedText;", "text$delegate", "textState", "Lgg/essential/elementa/state/State;", "bindText", "newTextState", "setText", "Companion", "Cheeto"})
/*     */ public final class ButtonComponent extends SettingComponent {
/*     */   @NotNull
/*     */   public static final Companion Companion;
/*     */   
/*     */   public ButtonComponent(@Nullable String placeholder, @NotNull Function0<Unit> callback) {
/*  21 */     this.callback = callback;
/*  22 */     if (placeholder == null); CharSequence charSequence1 = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  97 */     String str = placeholder; int $i$a$-ifEmpty-ButtonComponent$textState$1 = 0; CharSequence charSequence2 = ((charSequence1.length() == 0)) ? "Activate" : charSequence1; ((ButtonComponent)str).textState = (State<String>)(new BasicState(charSequence2)).map(ButtonComponent$textState$2.INSTANCE); this.listener = this.textState.onSetValue(new ButtonComponent$listener$1()); UIComponent $this$constrain$iv = (UIComponent)new UIRoundedRectangle(2.5F); int $i$f$constrain = 0;
/*  98 */     UIComponent uIComponent2 = $this$constrain$iv, $this$constrain_u24lambda_u2d0$iv = uIComponent2; int $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/*  99 */     UIConstraints uIConstraints1 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); ButtonComponent buttonComponent = this; int $i$a$-constrain-ButtonComponent$container$2 = 0; uIConstraints1.setWidth((WidthConstraint)ConstraintsKt.plus((SuperConstraint)new ChildBasedSizeConstraint(0.0F, 1, null), (SuperConstraint)UtilitiesKt.pixels$default(Integer.valueOf(2), false, false, 3, null))); uIConstraints1.setHeight((HeightConstraint)ConstraintsKt.plus((SuperConstraint)new ChildBasedSizeConstraint(0.0F, 1, null), (SuperConstraint)UtilitiesKt.pixels$default(Integer.valueOf(2), false, false, 3, null))); Color color2 = ColorUtils.M_BORDER; Intrinsics.checkNotNullExpressionValue(color2, "M_BORDER"); uIConstraints1.setColor((ColorConstraint)UtilitiesKt.toConstraint(color2)); buttonComponent.container$delegate = ComponentsKt.provideDelegate(ComponentsKt.childOf(uIComponent2, (UIComponent)this), this, $$delegatedProperties[0]); $this$constrain$iv = (UIComponent)new UIRoundedRectangle(2.5F);
/*     */     $i$f$constrain = 0;
/* 101 */     $this$constrain_u24lambda_u2d0$iv = uIComponent2 = $this$constrain$iv; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 102 */     UIConstraints $this$container_delegate_u24lambda_u2d1 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); buttonComponent = this; int $i$a$-constrain-ButtonComponent$contentContainer$2 = 0; $this$container_delegate_u24lambda_u2d1.setX((XConstraint)UtilitiesKt.pixel$default(Integer.valueOf(1), false, false, 3, null)); $this$container_delegate_u24lambda_u2d1.setY((YConstraint)UtilitiesKt.pixel$default(Integer.valueOf(1), false, false, 3, null)); $this$container_delegate_u24lambda_u2d1.setWidth((WidthConstraint)ConstraintsKt.plus((SuperConstraint)new ChildBasedSizeConstraint(0.0F, 1, null), (SuperConstraint)UtilitiesKt.pixels$default(Integer.valueOf(20), false, false, 3, null))); $this$container_delegate_u24lambda_u2d1.setHeight((HeightConstraint)ConstraintsKt.plus((SuperConstraint)new ChildBasedSizeConstraint(0.0F, 1, null), (SuperConstraint)UtilitiesKt.pixels$default(Integer.valueOf(10), false, false, 3, null))); color2 = ColorUtils.MENU_BG; Intrinsics.checkNotNullExpressionValue(color2, "MENU_BG"); $this$container_delegate_u24lambda_u2d1.setColor((ColorConstraint)UtilitiesKt.toConstraint(color2)); buttonComponent.contentContainer$delegate = ComponentsKt.provideDelegate(ComponentsKt.childOf(uIComponent2, (UIComponent)getContainer()), this, $$delegatedProperties[1]); $this$constrain$iv = (UIComponent)new UIWrappedText((String)this.textState.get(), false, null, false, true, 0.0F, null, 110, null);
/*     */     $i$f$constrain = 0;
/* 104 */     $this$constrain_u24lambda_u2d0$iv = uIComponent2 = $this$constrain$iv; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 105 */     UIConstraints $this$contentContainer_delegate_u24lambda_u2d2 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); buttonComponent = this; int $i$a$-constrain-ButtonComponent$text$2 = 0; $this$contentContainer_delegate_u24lambda_u2d2.setX((XConstraint)new CenterConstraint()); $this$contentContainer_delegate_u24lambda_u2d2.setY((YConstraint)new CenterConstraint()); $this$contentContainer_delegate_u24lambda_u2d2.setWidth((WidthConstraint)ConstraintsKt.coerceAtMost((SuperConstraint)$this$contentContainer_delegate_u24lambda_u2d2.getWidth(), (SuperConstraint)UtilitiesKt.pixels$default(Integer.valueOf(300), false, false, 3, null))); $this$contentContainer_delegate_u24lambda_u2d2.setHeight((HeightConstraint)UtilitiesKt.pixels$default(Integer.valueOf(10), false, false, 3, null)); color2 = ColorUtils.LABEL; Intrinsics.checkNotNullExpressionValue(color2, "LABEL"); $this$contentContainer_delegate_u24lambda_u2d2.setColor((ColorConstraint)UtilitiesKt.toConstraint(color2)); $this$contentContainer_delegate_u24lambda_u2d2.setFontProvider(DefaultFonts.getVANILLA_FONT_RENDERER()); buttonComponent.text$delegate = ComponentsKt.provideDelegate(ComponentsKt.childOf(uIComponent2, (UIComponent)getContentContainer()), this, $$delegatedProperties[2]); $this$constrain$iv = (UIComponent)this;
/*     */     $i$f$constrain = 0;
/* 107 */     $this$constrain_u24lambda_u2d0$iv = uIComponent2 = $this$constrain$iv; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 108 */     UIConstraints $this$_init__u24lambda_u2d4 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); int $i$a$-constrain-ButtonComponent$1 = 0; $this$_init__u24lambda_u2d4.setWidth((WidthConstraint)new ChildBasedSizeConstraint(0.0F, 1, null)); $this$_init__u24lambda_u2d4.setHeight((HeightConstraint)new ChildBasedSizeConstraint(0.0F, 1, null)); Color color1 = ColorUtils.SELECTED; Intrinsics.checkNotNullExpressionValue(color1, "SELECTED"); enableEffect((Effect)new ExpandingClickEffect(ExtensionsKt.withAlpha(color1, 0.5F), 0.0F, (UIComponent)getContentContainer(), 2, null)); UIComponent uIComponent1 = getContainer().onMouseEnter(new Function1<UIComponent, Unit>() { public final void invoke(@NotNull UIComponent $this$onMouseEnter) { Intrinsics.checkNotNullParameter($this$onMouseEnter, "$this$onMouseEnter"); UIComponent $this$animate$iv = (UIComponent)ButtonComponent.this.getContainer(); int $i$f$animate = 0; UIComponent uIComponent1 = $this$animate$iv, $this$animate_u24lambda_u2d0$iv = uIComponent1; int $i$a$-apply-AnimationsKt$animate$1$iv = 0; AnimatingConstraints anim$iv = $this$animate_u24lambda_u2d0$iv.makeAnimation(); AnimatingConstraints $this$invoke_u24lambda_u2d0 = anim$iv; int $i$a$-animate-ButtonComponent$2$1 = 0; Color color = ColorUtils.SELECTED; Intrinsics.checkNotNullExpressionValue(color, "SELECTED"); AnimatingConstraints.setColorAnimation$default($this$invoke_u24lambda_u2d0, (AnimationStrategy)Animations.OUT_EXP, 0.5F, (ColorConstraint)UtilitiesKt.toConstraint(color), 0.0F, 8, null); $this$animate_u24lambda_u2d0$iv.animateTo(anim$iv); } }
/*     */       ).onMouseLeave(new Function1<UIComponent, Unit>() { public final void invoke(@NotNull UIComponent $this$onMouseLeave) { Intrinsics.checkNotNullParameter($this$onMouseLeave, "$this$onMouseLeave"); UIComponent $this$animate$iv = (UIComponent)ButtonComponent.this.getContainer(); int $i$f$animate = 0; UIComponent uIComponent1 = $this$animate$iv, $this$animate_u24lambda_u2d0$iv = uIComponent1; int $i$a$-apply-AnimationsKt$animate$1$iv = 0; AnimatingConstraints anim$iv = $this$animate_u24lambda_u2d0$iv.makeAnimation(); AnimatingConstraints $this$invoke_u24lambda_u2d0 = anim$iv; int $i$a$-animate-ButtonComponent$3$1 = 0; Color color = ColorUtils.M_BORDER; Intrinsics.checkNotNullExpressionValue(color, "M_BORDER"); AnimatingConstraints.setColorAnimation$default($this$invoke_u24lambda_u2d0, (AnimationStrategy)Animations.OUT_EXP, 0.5F, (ColorConstraint)UtilitiesKt.toConstraint(color), 0.0F, 8, null); $this$animate_u24lambda_u2d0$iv.animateTo(anim$iv); } }
/* 110 */       ); int $i$f$onLeftClick = 0; uIComponent1.onMouseClick(new ButtonComponent$special$$inlined$onLeftClick$1(this));
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   private final Function0<Unit> callback;
/*     */   @NotNull
/*     */   private State<String> textState;
/*     */   @NotNull
/*     */   private Function0<Unit> listener;
/*     */   @NotNull
/*     */   private final ReadWriteProperty container$delegate;
/*     */   @NotNull
/*     */   private final ReadWriteProperty contentContainer$delegate;
/*     */   @NotNull
/*     */   private final ReadWriteProperty text$delegate;
/*     */   
/*     */   @Metadata(mv = {1, 6, 0}, k = 3, xi = 48, d1 = {"\000\n\n\000\n\002\020\016\n\002\b\002\020\000\032\0020\0012\006\020\002\032\0020\001H\n¢\006\002\b\003"}, d2 = {"<anonymous>", "", "it", "invoke"})
/*     */   static final class ButtonComponent$textState$2 extends Lambda implements Function1<String, String> {
/*     */     public static final ButtonComponent$textState$2 INSTANCE = new ButtonComponent$textState$2();
/*     */     
/*     */     ButtonComponent$textState$2() {
/*     */       super(1);
/*     */     }
/*     */     
/*     */     @NotNull
/*     */     public final String invoke(@NotNull String it) {
/*     */       Intrinsics.checkNotNullParameter(it, "it");
/*     */       String str = I18n.func_135052_a(it, new Object[0]);
/*     */       Intrinsics.checkNotNullExpressionValue(str, "format(it)");
/*     */       return str;
/*     */     }
/*     */   }
/*     */   
/*     */   @Metadata(mv = {1, 6, 0}, k = 3, xi = 48, d1 = {"\000\016\n\000\n\002\020\002\n\000\n\002\020\016\n\000\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "it", "", "invoke"})
/*     */   static final class ButtonComponent$listener$1 extends Lambda implements Function1<String, Unit> {
/*     */     public final void invoke(@NotNull String it) {
/*     */       Intrinsics.checkNotNullParameter(it, "it");
/*     */       ButtonComponent.this.getText().setText((String)ButtonComponent.this.textState.get());
/*     */     }
/*     */     
/*     */     ButtonComponent$listener$1() {
/*     */       super(1);
/*     */     }
/*     */   }
/*     */   
/*     */   private final UIRoundedRectangle getContainer() {
/*     */     return (UIRoundedRectangle)this.container$delegate.getValue(this, $$delegatedProperties[0]);
/*     */   }
/*     */   
/*     */   static {
/*     */     KProperty[] arrayOfKProperty = new KProperty[3];
/*     */     arrayOfKProperty[0] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(ButtonComponent.class, "container", "getContainer()Lgg/essential/elementa/components/UIRoundedRectangle;", 0));
/*     */     arrayOfKProperty[1] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(ButtonComponent.class, "contentContainer", "getContentContainer()Lgg/essential/elementa/components/UIRoundedRectangle;", 0));
/*     */     arrayOfKProperty[2] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(ButtonComponent.class, "text", "getText()Lgg/essential/elementa/components/UIWrappedText;", 0));
/*     */     $$delegatedProperties = (KProperty<Object>[])arrayOfKProperty;
/*     */     Companion = new Companion(null);
/*     */   }
/*     */   
/*     */   private final UIRoundedRectangle getContentContainer() {
/*     */     return (UIRoundedRectangle)this.contentContainer$delegate.getValue(this, $$delegatedProperties[1]);
/*     */   }
/*     */   
/*     */   private final UIWrappedText getText() {
/*     */     return (UIWrappedText)this.text$delegate.getValue(this, $$delegatedProperties[2]);
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final ButtonComponent bindText(@NotNull State<String> newTextState) {
/*     */     Intrinsics.checkNotNullParameter(newTextState, "newTextState");
/*     */     ButtonComponent buttonComponent1 = this, $this$bindText_u24lambda_u2d6 = buttonComponent1;
/*     */     int $i$a$-apply-ButtonComponent$bindText$1 = 0;
/*     */     $this$bindText_u24lambda_u2d6.listener.invoke();
/*     */     $this$bindText_u24lambda_u2d6.textState = newTextState;
/*     */     $this$bindText_u24lambda_u2d6.getText().bindText((State)$this$bindText_u24lambda_u2d6.textState.map(ButtonComponent$bindText$1$1.INSTANCE));
/*     */     $this$bindText_u24lambda_u2d6.listener = $this$bindText_u24lambda_u2d6.textState.onSetValue(new ButtonComponent$bindText$1$2($this$bindText_u24lambda_u2d6));
/*     */     return buttonComponent1;
/*     */   }
/*     */   
/*     */   @Metadata(mv = {1, 6, 0}, k = 3, xi = 48, d1 = {"\000\n\n\000\n\002\020\016\n\002\b\002\020\000\032\0020\0012\006\020\002\032\0020\001H\n¢\006\002\b\003"}, d2 = {"<anonymous>", "", "it", "invoke"})
/*     */   static final class ButtonComponent$bindText$1$1 extends Lambda implements Function1<String, String> {
/*     */     public static final ButtonComponent$bindText$1$1 INSTANCE = new ButtonComponent$bindText$1$1();
/*     */     
/*     */     ButtonComponent$bindText$1$1() {
/*     */       super(1);
/*     */     }
/*     */     
/*     */     @NotNull
/*     */     public final String invoke(@NotNull String it) {
/*     */       Intrinsics.checkNotNullParameter(it, "it");
/*     */       String str = I18n.func_135052_a(it, new Object[0]);
/*     */       Intrinsics.checkNotNullExpressionValue(str, "format(it)");
/*     */       return str;
/*     */     }
/*     */   }
/*     */   
/*     */   @Metadata(mv = {1, 6, 0}, k = 3, xi = 48, d1 = {"\000\016\n\000\n\002\020\002\n\000\n\002\020\016\n\000\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "it", "", "invoke"})
/*     */   static final class ButtonComponent$bindText$1$2 extends Lambda implements Function1<String, Unit> {
/*     */     public final void invoke(@NotNull String it) {
/*     */       Intrinsics.checkNotNullParameter(it, "it");
/*     */       this.$this_apply.getText().setText((String)this.$this_apply.textState.get());
/*     */     }
/*     */     
/*     */     ButtonComponent$bindText$1$2(ButtonComponent $receiver) {
/*     */       super(1);
/*     */     }
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final String getText() {
/*     */     return (String)this.textState.get();
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final ButtonComponent setText(@NotNull String text) {
/*     */     Intrinsics.checkNotNullParameter(text, "text");
/*     */     ButtonComponent buttonComponent1 = this, $this$setText_u24lambda_u2d7 = buttonComponent1;
/*     */     int $i$a$-apply-ButtonComponent$setText$1 = 0;
/*     */     $this$setText_u24lambda_u2d7.textState.set(text);
/*     */     return buttonComponent1;
/*     */   }
/*     */   
/*     */   public ButtonComponent(@Nullable String placeholder, @NotNull PropertyData data) {
/*     */     this(placeholder, Companion.callbackFromPropertyData(data));
/*     */   }
/*     */   
/*     */   @Metadata(mv = {1, 6, 0}, k = 1, xi = 48, d1 = {"\000\034\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\020\002\n\000\n\002\030\002\n\000\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002J\026\020\003\032\b\022\004\022\0020\0050\0042\006\020\006\032\0020\007H\002¨\006\b"}, d2 = {"Lxyz/apfelmus/cheeto/client/clickgui/settings/ButtonComponent$Companion;", "", "()V", "callbackFromPropertyData", "Lkotlin/Function0;", "", "data", "Lgg/essential/vigilance/data/PropertyData;", "Cheeto"})
/*     */   public static final class Companion {
/*     */     private Companion() {}
/*     */     
/*     */     private final Function0<Unit> callbackFromPropertyData(PropertyData data) {
/*     */       PropertyValue value = data.getValue();
/*     */       if (!(value instanceof CallablePropertyValue))
/*     */         throw new IllegalStateException(); 
/*     */       return new ButtonComponent$Companion$callbackFromPropertyData$1(value, data);
/*     */     }
/*     */     
/*     */     @Metadata(mv = {1, 6, 0}, k = 3, xi = 48, d1 = {"\000\b\n\000\n\002\020\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "", "invoke"})
/*     */     static final class ButtonComponent$Companion$callbackFromPropertyData$1 extends Lambda implements Function0<Unit> {
/*     */       ButtonComponent$Companion$callbackFromPropertyData$1(PropertyValue $value, PropertyData $data) {
/*     */         super(0);
/*     */       }
/*     */       
/*     */       public final void invoke() {
/*     */         ((CallablePropertyValue)this.$value).invoke(this.$data.getInstance());
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\clickgui\settings\ButtonComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */