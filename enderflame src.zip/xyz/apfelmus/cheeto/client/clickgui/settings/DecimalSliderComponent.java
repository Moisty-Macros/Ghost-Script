/*    */ package xyz.apfelmus.cheeto.client.clickgui.settings;
/*    */ import gg.essential.elementa.UIComponent;
/*    */ import gg.essential.elementa.UIConstraints;
/*    */ import gg.essential.elementa.components.UIText;
/*    */ import gg.essential.elementa.dsl.ComponentsKt;
/*    */ import gg.essential.elementa.dsl.UtilitiesKt;
/*    */ import java.awt.Color;
/*    */ import java.util.Locale;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.reflect.KProperty;
/*    */ 
/*    */ @Metadata(mv = {1, 6, 0}, k = 1, xi = 48, d1 = {"\000*\n\002\030\002\n\002\030\002\n\000\n\002\020\007\n\002\b\003\n\002\020\b\n\002\b\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\004\030\0002\0020\001B'\022\006\020\002\032\0020\003\022\006\020\004\032\0020\003\022\006\020\005\032\0020\003\022\b\b\002\020\006\032\0020\007¢\006\002\020\bR\033\020\t\032\0020\n8BX\002¢\006\f\n\004\b\r\020\016\032\004\b\013\020\fR\033\020\017\032\0020\0208TX\002¢\006\f\n\004\b\023\020\016\032\004\b\021\020\022¨\006\024"}, d2 = {"Lxyz/apfelmus/cheeto/client/clickgui/settings/DecimalSliderComponent;", "Lxyz/apfelmus/cheeto/client/clickgui/settings/AbstractSliderComponent;", "initialValue", "", "min", "max", "decimalPlaces", "", "(FFFI)V", "currentValueText", "Lgg/essential/elementa/components/UIText;", "getCurrentValueText", "()Lgg/essential/elementa/components/UIText;", "currentValueText$delegate", "Lkotlin/properties/ReadWriteProperty;", "slider", "Lxyz/apfelmus/cheeto/client/clickgui/settings/Slider;", "getSlider", "()Lxyz/apfelmus/cheeto/client/clickgui/settings/Slider;", "slider$delegate", "Cheeto"})
/*    */ public final class DecimalSliderComponent extends AbstractSliderComponent {
/*    */   public DecimalSliderComponent(float initialValue, float min, float max, int decimalPlaces) {
/* 16 */     UIComponent $this$constrain$iv = (UIComponent)new UIText(String.valueOf(min), false, null, 6, null); int $i$f$constrain = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 53 */     UIComponent uIComponent1 = $this$constrain$iv, $this$constrain_u24lambda_u2d0$iv = uIComponent1; int $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 54 */     UIConstraints $this$_init__u24lambda_u2d0 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); int $i$a$-constrain-DecimalSliderComponent$1 = 0; $this$_init__u24lambda_u2d0.setY((YConstraint)new CenterConstraint()); Color color = ColorUtils.LABEL; Intrinsics.checkNotNullExpressionValue(color, "LABEL"); $this$_init__u24lambda_u2d0.setColor((ColorConstraint)UtilitiesKt.toConstraint(color)); ComponentsKt.childOf(uIComponent1, (UIComponent)this); $this$constrain$iv = (UIComponent)new Slider((initialValue - min) / (max - min));
/*    */     $i$f$constrain = 0;
/* 56 */     $this$constrain_u24lambda_u2d0$iv = uIComponent1 = $this$constrain$iv; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 57 */     $this$_init__u24lambda_u2d0 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); DecimalSliderComponent decimalSliderComponent = this; int $i$a$-constrain-DecimalSliderComponent$slider$2 = 0; $this$_init__u24lambda_u2d0.setX((XConstraint)new SiblingConstraint(0.0F, false, 3, null)); $this$_init__u24lambda_u2d0.setWidth((WidthConstraint)UtilitiesKt.pixels$default(Integer.valueOf(60), false, false, 3, null)); $this$_init__u24lambda_u2d0.setHeight((HeightConstraint)UtilitiesKt.pixels$default(Integer.valueOf(12), false, false, 3, null)); decimalSliderComponent.slider$delegate = ComponentsKt.provideDelegate(ComponentsKt.childOf(uIComponent1, (UIComponent)this), this, $$delegatedProperties[0]); $this$constrain$iv = (UIComponent)new UIText(String.valueOf(max), false, null, 6, null);
/*    */     $i$f$constrain = 0;
/* 59 */     $this$constrain_u24lambda_u2d0$iv = uIComponent1 = $this$constrain$iv; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 60 */     UIConstraints $this$_init__u24lambda_u2d2 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); int $i$a$-constrain-DecimalSliderComponent$2 = 0; $this$_init__u24lambda_u2d2.setX((XConstraint)new SiblingConstraint(0.0F, false, 3, null)); $this$_init__u24lambda_u2d2.setY((YConstraint)new CenterConstraint()); color = ColorUtils.LABEL; Intrinsics.checkNotNullExpressionValue(color, "LABEL"); $this$_init__u24lambda_u2d2.setColor((ColorConstraint)UtilitiesKt.toConstraint(color)); ComponentsKt.childOf(uIComponent1, (UIComponent)this); $this$constrain$iv = (UIComponent)new UIText(String.valueOf(initialValue), false, null, 6, null);
/*    */     $i$f$constrain = 0;
/* 62 */     $this$constrain_u24lambda_u2d0$iv = uIComponent1 = $this$constrain$iv; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 63 */     UIConstraints $this$slider_delegate_u24lambda_u2d1 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); decimalSliderComponent = this; int $i$a$-constrain-DecimalSliderComponent$currentValueText$2 = 0;
/*    */     $this$slider_delegate_u24lambda_u2d1.setX((XConstraint)ConstraintsKt.boundTo((SuperConstraint)new CenterConstraint(), (UIComponent)getSlider().getGrabBox()));
/*    */     $this$slider_delegate_u24lambda_u2d1.setY((YConstraint)new RelativeConstraint(1.5F));
/*    */     color = ColorUtils.LABEL;
/*    */     Intrinsics.checkNotNullExpressionValue(color, "LABEL");
/*    */     $this$slider_delegate_u24lambda_u2d1.setColor((ColorConstraint)UtilitiesKt.toConstraint(color));
/*    */     $this$slider_delegate_u24lambda_u2d1.setFontProvider(DefaultFonts.getVANILLA_FONT_RENDERER());
/*    */     decimalSliderComponent.currentValueText$delegate = ComponentsKt.provideDelegate(ComponentsKt.childOf(uIComponent1, (UIComponent)getSlider()), this, $$delegatedProperties[1]);
/*    */     getSlider().onValueChange(new Function1<Float, Unit>(min, max, this) {
/*    */           public final void invoke(float newPercentage) {
/*    */             String str1 = "%." + this.$decimalPlaces + 'f';
/*    */             Locale locale = Locale.US;
/*    */             Object[] arrayOfObject = new Object[1];
/*    */             arrayOfObject[0] = Float.valueOf(this.$min + newPercentage * (this.$max - this.$min));
/*    */             arrayOfObject = arrayOfObject;
/*    */             String str2 = String.format(locale, str1, Arrays.copyOf(arrayOfObject, arrayOfObject.length));
/*    */             Intrinsics.checkNotNullExpressionValue(str2, "format(locale, this, *args)");
/*    */             String newValue = str2;
/*    */             SettingComponent.changeValue$default(DecimalSliderComponent.this, Float.valueOf(Float.parseFloat(newValue)), false, 2, null);
/*    */             DecimalSliderComponent.this.getCurrentValueText().setText(newValue);
/*    */           }
/*    */         });
/*    */     sliderInit();
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   private final ReadWriteProperty slider$delegate;
/*    */   @NotNull
/*    */   private final ReadWriteProperty currentValueText$delegate;
/*    */   
/*    */   @NotNull
/*    */   protected Slider getSlider() {
/*    */     return (Slider)this.slider$delegate.getValue(this, $$delegatedProperties[0]);
/*    */   }
/*    */   
/*    */   static {
/*    */     KProperty[] arrayOfKProperty = new KProperty[2];
/*    */     arrayOfKProperty[0] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(DecimalSliderComponent.class, "slider", "getSlider()Lxyz/apfelmus/cheeto/client/clickgui/settings/Slider;", 0));
/*    */     arrayOfKProperty[1] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(DecimalSliderComponent.class, "currentValueText", "getCurrentValueText()Lgg/essential/elementa/components/UIText;", 0));
/*    */     $$delegatedProperties = (KProperty<Object>[])arrayOfKProperty;
/*    */   }
/*    */   
/*    */   private final UIText getCurrentValueText() {
/*    */     return (UIText)this.currentValueText$delegate.getValue(this, $$delegatedProperties[1]);
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\clickgui\settings\DecimalSliderComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */