/*     */ package xyz.apfelmus.cheeto.client.clickgui.settings;@Metadata(mv = {1, 6, 0}, k = 1, xi = 48, d1 = {"\000d\n\002\030\002\n\002\030\002\n\000\n\002\020\b\n\000\n\002\020 \n\002\020\016\n\000\n\002\030\002\n\000\n\002\020\007\n\002\b\002\n\002\020\013\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\000\n\002\030\002\n\002\020\002\n\000\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\024\030\0002\0020\001B1\022\006\020\002\032\0020\003\022\f\020\004\032\b\022\004\022\0020\0060\005\022\n\b\002\020\007\032\004\030\0010\b\022\b\b\002\020\t\032\0020\n¢\006\002\020\013J\032\020/\032\0020 2\b\b\002\0200\032\0020\r2\b\b\002\0201\032\0020\rJ\b\0202\032\0020 H\002J\006\0203\032\0020\003J\020\0204\032\0020 2\006\0205\032\0020\035H\002J\032\020\036\032\0020 2\022\0206\032\016\022\004\022\0020\003\022\004\022\0020 0\037J\b\0207\032\0020 H\002J\016\0208\032\0020 2\006\0209\032\0020\003J\020\020:\032\0020 2\006\0205\032\0020\035H\002R\016\020\f\032\0020\rX\016¢\006\002\n\000R\016\020\016\032\0020\017X\004¢\006\002\n\000R\033\020\020\032\0020\0218BX\002¢\006\f\n\004\b\024\020\025\032\004\b\022\020\023R\033\020\026\032\0020\0278BX\002¢\006\f\n\004\b\032\020\025\032\004\b\030\020\031R\016\020\033\032\0020\017X\004¢\006\002\n\000R\024\020\034\032\b\022\004\022\0020\0350\005X\004¢\006\002\n\000R\032\020\036\032\016\022\004\022\0020\003\022\004\022\0020 0\037X\016¢\006\002\n\000R\024\020\004\032\b\022\004\022\0020\0060\005X\004¢\006\002\n\000R\033\020!\032\0020\"8BX\002¢\006\f\n\004\b%\020\025\032\004\b#\020$R\033\020&\032\0020'8BX\002¢\006\f\n\004\b*\020\025\032\004\b(\020)R\016\020+\032\0020\003X\016¢\006\002\n\000R\033\020,\032\0020\0278BX\002¢\006\f\n\004\b.\020\025\032\004\b-\020\031¨\006;"}, d2 = {"Lxyz/apfelmus/cheeto/client/clickgui/settings/DropDown;", "Lgg/essential/elementa/components/UIBlock;", "initialSelection", "", "options", "", "", "outlineEffect", "Lgg/essential/elementa/effects/OutlineEffect;", "optionPadding", "", "(ILjava/util/List;Lgg/essential/elementa/effects/OutlineEffect;F)V", "active", "", "collapsedWidth", "Lgg/essential/elementa/constraints/AdditiveConstraint;", "currentSelectionText", "Lgg/essential/elementa/components/UIText;", "getCurrentSelectionText", "()Lgg/essential/elementa/components/UIText;", "currentSelectionText$delegate", "Lkotlin/properties/ReadWriteProperty;", "downArrow", "Lgg/essential/elementa/components/UIImage;", "getDownArrow", "()Lgg/essential/elementa/components/UIImage;", "downArrow$delegate", "expandedWidth", "mappedOptions", "Lgg/essential/elementa/UIComponent;", "onValueChange", "Lkotlin/Function1;", "", "optionsHolder", "Lgg/essential/elementa/components/ScrollComponent;", "getOptionsHolder", "()Lgg/essential/elementa/components/ScrollComponent;", "optionsHolder$delegate", "scrollContainer", "Lgg/essential/elementa/components/UIContainer;", "getScrollContainer", "()Lgg/essential/elementa/components/UIContainer;", "scrollContainer$delegate", "selected", "upArrow", "getUpArrow", "upArrow$delegate", "collapse", "unHover", "instantly", "expand", "getValue", "hoverText", "text", "listener", "readOptionComponents", "select", "index", "unHoverText", "Cheeto"})
/*     */ public final class DropDown extends UIBlock { @NotNull
/*     */   private final List<String> options; private int selected; @NotNull
/*     */   private Function1<? super Integer, Unit> onValueChange; private boolean active; @NotNull
/*     */   private final ReadWriteProperty currentSelectionText$delegate; @NotNull
/*     */   private final ReadWriteProperty downArrow$delegate;
/*     */   @NotNull
/*     */   private final ReadWriteProperty upArrow$delegate;
/*     */   @NotNull
/*     */   private final ReadWriteProperty scrollContainer$delegate;
/*     */   @NotNull
/*     */   private final ReadWriteProperty optionsHolder$delegate;
/*     */   @NotNull
/*     */   private final List<UIComponent> mappedOptions;
/*     */   @NotNull
/*     */   private final AdditiveConstraint collapsedWidth;
/*     */   @NotNull
/*     */   private final AdditiveConstraint expandedWidth;
/*     */   
/*  20 */   public DropDown(int initialSelection, @NotNull List<String> options, @Nullable OutlineEffect outlineEffect, float optionPadding) { super(null, 1, null); this.options = options;
/*  21 */     this.selected = initialSelection;
/*  22 */     this.onValueChange = DropDown$onValueChange$1.INSTANCE;
/*     */ 
/*     */     
/*  25 */     UIComponent uIComponent1 = (UIComponent)new UIText(this.options.get(this.selected), false, null, 6, null); int i = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 211 */     UIComponent uIComponent4 = uIComponent1, uIComponent6 = uIComponent4; int $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 212 */     UIConstraints uIConstraints1 = uIComponent6.getConstraints(); DropDown dropDown = this; int $i$a$-constrain-DropDown$currentSelectionText$2 = 0; uIConstraints1.setX((XConstraint)UtilitiesKt.pixels$default(Integer.valueOf(5), false, false, 3, null)); uIConstraints1.setY((YConstraint)UtilitiesKt.pixels$default(Integer.valueOf(6), false, false, 3, null)); Color color2 = ColorUtils.LABEL; Intrinsics.checkNotNullExpressionValue(color2, "LABEL"); uIConstraints1.setColor((ColorConstraint)UtilitiesKt.toConstraint(color2)); uIConstraints1.setFontProvider(getFontProvider()); dropDown.currentSelectionText$delegate = ComponentsKt.provideDelegate(ComponentsKt.childOf(uIComponent4, (UIComponent)this), this, $$delegatedProperties[0]); uIComponent1 = (UIComponent)UIImage.Companion.ofResourceCached("/vigilance/arrow-down.png");
/*     */     i = 0;
/* 214 */     uIComponent6 = uIComponent4 = uIComponent1; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 215 */     UIConstraints $this$currentSelectionText_delegate_u24lambda_u2d0 = uIComponent6.getConstraints(); dropDown = this; int $i$a$-constrain-DropDown$downArrow$2 = 0; $this$currentSelectionText_delegate_u24lambda_u2d0.setX((XConstraint)UtilitiesKt.pixels$default(Integer.valueOf(5), true, false, 2, null)); $this$currentSelectionText_delegate_u24lambda_u2d0.setY((YConstraint)UtilitiesKt.pixels$default(Double.valueOf(7.5D), false, false, 3, null)); $this$currentSelectionText_delegate_u24lambda_u2d0.setWidth((WidthConstraint)UtilitiesKt.pixels$default(Integer.valueOf(9), false, false, 3, null)); $this$currentSelectionText_delegate_u24lambda_u2d0.setHeight((HeightConstraint)UtilitiesKt.pixels$default(Integer.valueOf(5), false, false, 3, null)); dropDown.downArrow$delegate = ComponentsKt.provideDelegate(ComponentsKt.childOf(uIComponent4, (UIComponent)this), this, $$delegatedProperties[1]); uIComponent1 = (UIComponent)UIImage.Companion.ofResourceCached("/vigilance/arrow-up.png");
/*     */     i = 0;
/* 217 */     uIComponent6 = uIComponent4 = uIComponent1; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 218 */     UIConstraints $this$downArrow_delegate_u24lambda_u2d1 = uIComponent6.getConstraints(); dropDown = this; int $i$a$-constrain-DropDown$upArrow$2 = 0; $this$downArrow_delegate_u24lambda_u2d1.setX((XConstraint)UtilitiesKt.pixels$default(Integer.valueOf(5), true, false, 2, null)); $this$downArrow_delegate_u24lambda_u2d1.setY((YConstraint)UtilitiesKt.pixels$default(Double.valueOf(7.5D), false, false, 3, null)); $this$downArrow_delegate_u24lambda_u2d1.setWidth((WidthConstraint)UtilitiesKt.pixels$default(Integer.valueOf(9), false, false, 3, null)); $this$downArrow_delegate_u24lambda_u2d1.setHeight((HeightConstraint)UtilitiesKt.pixels$default(Integer.valueOf(5), false, false, 3, null)); dropDown.upArrow$delegate = ComponentsKt.provideDelegate(uIComponent4, this, $$delegatedProperties[2]); uIComponent1 = (UIComponent)new UIContainer();
/*     */     i = 0;
/* 220 */     uIComponent6 = uIComponent4 = uIComponent1; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 221 */     UIConstraints $this$upArrow_delegate_u24lambda_u2d2 = uIComponent6.getConstraints(); dropDown = this; int $i$a$-constrain-DropDown$scrollContainer$2 = 0; $this$upArrow_delegate_u24lambda_u2d2.setX((XConstraint)UtilitiesKt.pixels$default(Integer.valueOf(5), false, false, 3, null)); $this$upArrow_delegate_u24lambda_u2d2.setY((YConstraint)ConstraintsKt.boundTo((SuperConstraint)new SiblingConstraint(optionPadding, false, 2, null), (UIComponent)getCurrentSelectionText())); $this$upArrow_delegate_u24lambda_u2d2.setWidth((WidthConstraint)new ChildBasedMaxSizeConstraint()); $this$upArrow_delegate_u24lambda_u2d2.setHeight((HeightConstraint)ConstraintsKt.plus((SuperConstraint)new ChildBasedSizeConstraint(0.0F, 1, null), (SuperConstraint)UtilitiesKt.pixels$default(Float.valueOf(optionPadding), false, false, 3, null))); dropDown.scrollContainer$delegate = ComponentsKt.provideDelegate(ComponentsKt.childOf(uIComponent4, (UIComponent)this), this, $$delegatedProperties[3]); uIComponent1 = (UIComponent)new ScrollComponent(null, 0.0F, null, false, false, false, false, 0.0F, 0.0F, (UIComponent)getScrollContainer(), 511, null);
/*     */     i = 0;
/* 223 */     uIComponent6 = uIComponent4 = uIComponent1; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 224 */     UIConstraints $this$scrollContainer_delegate_u24lambda_u2d3 = uIComponent6.getConstraints(); dropDown = this; int $i$a$-constrain-DropDown$optionsHolder$2 = 0; $this$scrollContainer_delegate_u24lambda_u2d3.setX((XConstraint)UtilitiesKt.pixels$default(Integer.valueOf(0), false, false, 3, null)); $this$scrollContainer_delegate_u24lambda_u2d3.setY((YConstraint)UtilitiesKt.pixels$default(Integer.valueOf(0), false, false, 3, null)); $this$scrollContainer_delegate_u24lambda_u2d3.setHeight((HeightConstraint)UtilitiesKt.pixels$default(Float.valueOf((this.options.size() - 1) * (getFontProvider().getStringHeight("Text", $this$scrollContainer_delegate_u24lambda_u2d3.getTextScale()) + optionPadding) - optionPadding), false, false, 3, null)); dropDown.optionsHolder$delegate = ComponentsKt.provideDelegate(ComponentsKt.childOf(uIComponent4, (UIComponent)getScrollContainer()), this, $$delegatedProperties[4]); List<String> list1 = this.options; dropDown = this;
/*     */     int $i$f$mapIndexed = 0;
/* 226 */     List<String> list2 = list1; Collection destination$iv$iv = new ArrayList(CollectionsKt.collectionSizeOrDefault(list1, 10)); int $i$f$mapIndexedTo = 0;
/* 227 */     int index$iv$iv = 0;
/* 228 */     for (String item$iv$iv : list2) {
/* 229 */       $i$a$-constrain-DropDown$optionsHolder$2 = index$iv$iv; index$iv$iv = $i$a$-constrain-DropDown$optionsHolder$2 + 1; $i$a$-constrain-DropDown$optionsHolder$2 = $i$a$-constrain-DropDown$optionsHolder$2; if ($i$a$-constrain-DropDown$optionsHolder$2 < 0) CollectionsKt.throwIndexOverflow();  String str1 = item$iv$iv; int m = $i$a$-constrain-DropDown$optionsHolder$2; Collection collection = destination$iv$iv; int $i$a$-mapIndexed-DropDown$mappedOptions$1 = 0; UIComponent uIComponent8 = (UIComponent)new UIText(str1, false, null, 6, null); int n = 0;
/* 230 */       UIComponent uIComponent9 = uIComponent8, uIComponent10 = uIComponent9; int i1 = 0;
/* 231 */       UIConstraints $this$mappedOptions_u24lambda_u2d6_u24lambda_u2d5 = uIComponent10.getConstraints(); int $i$a$-constrain-DropDown$mappedOptions$1$1 = 0;
/*     */     } 
/* 233 */     dropDown.mappedOptions = (List<UIComponent>)destination$iv$iv; this.collapsedWidth = ConstraintsKt.plus((SuperConstraint)UtilitiesKt.pixels$default(Integer.valueOf(22), false, false, 3, null), (new CopyConstraintFloat(false, 1, null)).to((UIComponent)getCurrentSelectionText())); this.expandedWidth = ConstraintsKt.plus((SuperConstraint)UtilitiesKt.pixels$default(Integer.valueOf(22), false, false, 3, null), (SuperConstraint)ConstraintsKt.coerceAtLeast((new ChildBasedMaxSizeConstraint()).to((UIComponent)getOptionsHolder()), (new CopyConstraintFloat(false, 1, null)).to((UIComponent)getCurrentSelectionText()))); UIComponent $this$constrain$iv = (UIComponent)this; int $i$f$constrain = 0;
/* 234 */     UIComponent uIComponent3 = $this$constrain$iv, $this$constrain_u24lambda_u2d0$iv = uIComponent3; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 235 */     UIConstraints $this$_init__u24lambda_u2d7 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); int $i$a$-constrain-DropDown$1 = 0; $this$_init__u24lambda_u2d7.setWidth((WidthConstraint)this.collapsedWidth); $this$_init__u24lambda_u2d7.setHeight((HeightConstraint)UtilitiesKt.pixels$default(Integer.valueOf(20), false, false, 3, null)); Color color1 = ColorUtils.MENU_BG; Intrinsics.checkNotNullExpressionValue(color1, "MENU_BG"); $this$_init__u24lambda_u2d7.setColor((ColorConstraint)UtilitiesKt.toConstraint(color1)); readOptionComponents(); getOptionsHolder().hide(true);
/*     */     Effect p0 = (Effect)outlineEffect;
/* 237 */     int $i$a$-let-DropDown$2 = 0; (outlineEffect == null) ? null : enableEffect(p0); UIComponent uIComponent2 = (UIComponent)new UIContainer(); int j = 0;
/* 238 */     UIComponent uIComponent5 = uIComponent2, uIComponent7 = uIComponent5; int k = 0;
/* 239 */     UIConstraints $this$_init__u24lambda_u2d8 = uIComponent7.getConstraints(); int $i$a$-constrain-DropDown$outlineContainer$1 = 0; $this$_init__u24lambda_u2d8.setX((XConstraint)UtilitiesKt.pixels$default(Integer.valueOf(-1), false, false, 3, null)); $this$_init__u24lambda_u2d8.setY((YConstraint)UtilitiesKt.pixels$default(Integer.valueOf(-1), false, false, 3, null)); $this$_init__u24lambda_u2d8.setWidth((WidthConstraint)ConstraintsKt.plus((SuperConstraint)new RelativeConstraint(1.0F), (SuperConstraint)UtilitiesKt.pixels$default(Integer.valueOf(2), false, false, 3, null))); $this$_init__u24lambda_u2d8.setHeight((HeightConstraint)ConstraintsKt.plus((SuperConstraint)new RelativeConstraint(1.0F), (SuperConstraint)UtilitiesKt.pixels$default(Float.valueOf(3.0F), false, false, 3, null))); UIContainer outlineContainer = (UIContainer)uIComponent5; outlineContainer.setParent((UIComponent)this); getChildren().add(0, outlineContainer); enableEffect((Effect)new ScissorEffect((UIComponent)outlineContainer, false, 2, null)); onMouseEnter(new Function1<UIComponent, Unit>() { public final void invoke(@NotNull UIComponent $this$onMouseEnter) { Intrinsics.checkNotNullParameter($this$onMouseEnter, "$this$onMouseEnter"); DropDown.this.hoverText((UIComponent)DropDown.this.getCurrentSelectionText()); } }
/*     */       ); onMouseLeave(new Function1<UIComponent, Unit>() { public final void invoke(@NotNull UIComponent $this$onMouseLeave) { Intrinsics.checkNotNullParameter($this$onMouseLeave, "$this$onMouseLeave"); if (DropDown.this.active) return;  DropDown.this.unHoverText((UIComponent)DropDown.this.getCurrentSelectionText()); } }
/* 241 */       ); UIComponent $this$onLeftClick$iv = (UIComponent)this; int $i$f$onLeftClick = 0; $this$onLeftClick$iv.onMouseClick(new DropDown$special$$inlined$onLeftClick$1(this)); }
/*     */   @Metadata(mv = {1, 6, 0}, k = 3, xi = 48, d1 = {"\000\016\n\000\n\002\020\002\n\000\n\002\020\b\n\000\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "it", "", "invoke"}) static final class DropDown$onValueChange$1 extends Lambda implements Function1<Integer, Unit> {
/*     */     public static final DropDown$onValueChange$1 INSTANCE = new DropDown$onValueChange$1();
/*     */     DropDown$onValueChange$1() { super(1); }
/*     */     public final void invoke(int it) {} }
/* 246 */   private final UIText getCurrentSelectionText() { return (UIText)this.currentSelectionText$delegate.getValue(this, $$delegatedProperties[0]); } static { KProperty[] arrayOfKProperty = new KProperty[5]; arrayOfKProperty[0] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(DropDown.class, "currentSelectionText", "getCurrentSelectionText()Lgg/essential/elementa/components/UIText;", 0)); arrayOfKProperty[1] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(DropDown.class, "downArrow", "getDownArrow()Lgg/essential/elementa/components/UIImage;", 0)); arrayOfKProperty[2] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(DropDown.class, "upArrow", "getUpArrow()Lgg/essential/elementa/components/UIImage;", 0)); arrayOfKProperty[3] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(DropDown.class, "scrollContainer", "getScrollContainer()Lgg/essential/elementa/components/UIContainer;", 0)); arrayOfKProperty[4] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(DropDown.class, "optionsHolder", "getOptionsHolder()Lgg/essential/elementa/components/ScrollComponent;", 0)); $$delegatedProperties = (KProperty<Object>[])arrayOfKProperty; } private final UIImage getDownArrow() { return (UIImage)this.downArrow$delegate.getValue(this, $$delegatedProperties[1]); } private final UIImage getUpArrow() { return (UIImage)this.upArrow$delegate.getValue(this, $$delegatedProperties[2]); } private final UIContainer getScrollContainer() { return (UIContainer)this.scrollContainer$delegate.getValue(this, $$delegatedProperties[3]); } private final void expand() { this.active = true; Iterable<UIComponent> $this$forEach$iv = this.mappedOptions; int $i$f$forEach = 0; Iterator<UIComponent> iterator = $this$forEach$iv.iterator(); if (iterator.hasNext()) { Object element$iv = iterator.next(); UIComponent it = (UIComponent)element$iv; int $i$a$-forEach-DropDown$expand$1 = 0; Color color = ColorUtils.LABEL; Intrinsics.checkNotNullExpressionValue(color, "LABEL"); it.setColor((ColorConstraint)UtilitiesKt.toConstraint(color)); }
/*     */      UIComponent $this$animate$iv = (UIComponent)this; int $i$f$animate = 0;
/* 248 */     UIComponent uIComponent1 = $this$animate$iv, $this$animate_u24lambda_u2d0$iv = uIComponent1; int $i$a$-apply-AnimationsKt$animate$1$iv = 0;
/* 249 */     AnimatingConstraints anim$iv = $this$animate_u24lambda_u2d0$iv.makeAnimation();
/* 250 */     AnimatingConstraints $this$expand_u24lambda_u2d11 = anim$iv; int $i$a$-animate-DropDown$expand$2 = 0; AnimatingConstraints.setHeightAnimation$default($this$expand_u24lambda_u2d11, (AnimationStrategy)Animations.IN_SIN, 0.25F, (HeightConstraint)ConstraintsKt.plus((SuperConstraint)UtilitiesKt.pixels$default(Integer.valueOf(20), false, false, 3, null), ConstraintsKt.boundTo((SuperConstraint)new RelativeConstraint(1.0F), (UIComponent)getScrollContainer())), 0.0F, 8, null);
/* 251 */     $this$animate_u24lambda_u2d0$iv.animateTo(anim$iv); getOptionsHolder().scrollToTop(false); replaceChild((UIComponent)getUpArrow(), (UIComponent)getDownArrow()); setFloating(true); getOptionsHolder().unhide(true); setWidth((WidthConstraint)this.expandedWidth); } private final ScrollComponent getOptionsHolder() { return (ScrollComponent)this.optionsHolder$delegate.getValue(this, $$delegatedProperties[4]); } @Metadata(mv = {1, 6, 0}, k = 3, xi = 48, d1 = {"\000\f\n\000\n\002\020\002\n\002\030\002\n\000\020\000\032\0020\001*\0020\002H\n¢\006\002\b\003"}, d2 = {"<anonymous>", "", "Lgg/essential/elementa/UIComponent;", "invoke"}) static final class DropDown$mappedOptions$1$2 extends Lambda implements Function1<UIComponent, Unit> {
/*     */     public final void invoke(@NotNull UIComponent $this$onMouseEnter) { Intrinsics.checkNotNullParameter($this$onMouseEnter, "$this$onMouseEnter"); DropDown.this.hoverText($this$onMouseEnter); } DropDown$mappedOptions$1$2() { super(1); } } @Metadata(mv = {1, 6, 0}, k = 3, xi = 48, d1 = {"\000\f\n\000\n\002\020\002\n\002\030\002\n\000\020\000\032\0020\001*\0020\002H\n¢\006\002\b\003"}, d2 = {"<anonymous>", "", "Lgg/essential/elementa/UIComponent;", "invoke"}) static final class DropDown$mappedOptions$1$3 extends Lambda implements Function1<UIComponent, Unit> {
/* 253 */     public final void invoke(@NotNull UIComponent $this$onMouseLeave) { Intrinsics.checkNotNullParameter($this$onMouseLeave, "$this$onMouseLeave"); DropDown.this.unHoverText($this$onMouseLeave); } DropDown$mappedOptions$1$3() { super(1); } } @Metadata(mv = {1, 6, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\002\030\002\n\000\n\002\030\002\n\000\020\000\032\0020\001*\0020\0022\006\020\003\032\0020\004H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "Lgg/essential/elementa/UIComponent;", "event", "Lgg/essential/elementa/events/UIClickEvent;", "invoke"}) static final class DropDown$mappedOptions$1$4 extends Lambda implements Function2<UIComponent, UIClickEvent, Unit> { public final void invoke(@NotNull UIComponent $this$onMouseClick, @NotNull UIClickEvent event) { Intrinsics.checkNotNullParameter($this$onMouseClick, "$this$onMouseClick"); Intrinsics.checkNotNullParameter(event, "event"); event.stopPropagation(); DropDown.this.select(this.$index); } DropDown$mappedOptions$1$4(int $index) { super(2); } } public final void select(int index) { if ((0 <= index) ? ((index < this.options.size())) : false) { this.selected = index; this.onValueChange.invoke(Integer.valueOf(index)); getCurrentSelectionText().setText(this.options.get(index)); collapse$default(this, false, false, 3, (Object)null); readOptionComponents(); }  } public final void onValueChange(@NotNull Function1<? super Integer, Unit> listener) { Intrinsics.checkNotNullParameter(listener, "listener"); this.onValueChange = listener; } public final int getValue() { return this.selected; } public final void collapse(boolean unHover, boolean instantly) { if (this.active) replaceChild((UIComponent)getDownArrow(), (UIComponent)getUpArrow());  this.active = false; if (instantly) { setHeight((HeightConstraint)UtilitiesKt.pixels$default(Integer.valueOf(20), false, false, 3, null)); collapse$animationComplete(this); } else { UIComponent $this$animate$iv = (UIComponent)this; int $i$f$animate = 0; UIComponent uIComponent1 = $this$animate$iv, $this$animate_u24lambda_u2d0$iv = uIComponent1; int $i$a$-apply-AnimationsKt$animate$1$iv = 0;
/* 254 */       AnimatingConstraints anim$iv = $this$animate_u24lambda_u2d0$iv.makeAnimation();
/* 255 */       AnimatingConstraints $this$collapse_u24lambda_u2d13 = anim$iv; int $i$a$-animate-DropDown$collapse$1 = 0; AnimatingConstraints.setHeightAnimation$default($this$collapse_u24lambda_u2d13, (AnimationStrategy)Animations.OUT_SIN, 0.35F, (HeightConstraint)UtilitiesKt.pixels$default(Integer.valueOf(20), false, false, 3, null), 0.0F, 8, null); $this$collapse_u24lambda_u2d13.onComplete(new DropDown$collapse$1$1());
/* 256 */       $this$animate_u24lambda_u2d0$iv.animateTo(anim$iv); }
/*     */     
/*     */     if (unHover) {
/*     */       unHoverText((UIComponent)getCurrentSelectionText());
/*     */     }
/*     */     setWidth((WidthConstraint)this.collapsedWidth); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final void collapse$animationComplete(DropDown this$0) {
/*     */     Iterable<UIComponent> $this$forEach$iv = this$0.mappedOptions;
/*     */     int $i$f$forEach = 0;
/* 271 */     Iterator<UIComponent> iterator = $this$forEach$iv.iterator(); if (iterator.hasNext()) { Object element$iv = iterator.next(); UIComponent it = (UIComponent)element$iv; int $i$a$-forEach-DropDown$collapse$animationComplete$1 = 0;
/*     */       it.setColor((ColorConstraint)UtilitiesKt.toConstraint(new Color(0, 0, 0, 0))); }
/*     */     
/*     */     this$0.setFloating(false);
/*     */     this$0.getOptionsHolder().hide(true);
/*     */   }
/*     */   
/*     */   private final void hoverText(UIComponent text) {
/*     */     UIComponent $this$animate$iv = text;
/*     */     int $i$f$animate = 0;
/*     */     UIComponent uIComponent1 = $this$animate$iv, $this$animate_u24lambda_u2d0$iv = uIComponent1;
/*     */     int $i$a$-apply-AnimationsKt$animate$1$iv = 0;
/*     */     AnimatingConstraints anim$iv = $this$animate_u24lambda_u2d0$iv.makeAnimation();
/*     */     AnimatingConstraints $this$hoverText_u24lambda_u2d14 = anim$iv;
/*     */     int $i$a$-animate-DropDown$hoverText$1 = 0;
/*     */     Color color = Color.WHITE;
/*     */     Intrinsics.checkNotNullExpressionValue(color, "WHITE");
/*     */     AnimatingConstraints.setColorAnimation$default($this$hoverText_u24lambda_u2d14, (AnimationStrategy)Animations.OUT_EXP, 0.25F, (ColorConstraint)UtilitiesKt.toConstraint(color), 0.0F, 8, null);
/*     */     $this$animate_u24lambda_u2d0$iv.animateTo(anim$iv);
/*     */   }
/*     */   
/*     */   private final void unHoverText(UIComponent text) {
/*     */     UIComponent $this$animate$iv = text;
/*     */     int $i$f$animate = 0;
/*     */     UIComponent uIComponent1 = $this$animate$iv, $this$animate_u24lambda_u2d0$iv = uIComponent1;
/*     */     int $i$a$-apply-AnimationsKt$animate$1$iv = 0;
/*     */     AnimatingConstraints anim$iv = $this$animate_u24lambda_u2d0$iv.makeAnimation();
/*     */     AnimatingConstraints $this$unHoverText_u24lambda_u2d15 = anim$iv;
/*     */     int $i$a$-animate-DropDown$unHoverText$1 = 0;
/*     */     Color color = ColorUtils.LABEL;
/*     */     Intrinsics.checkNotNullExpressionValue(color, "LABEL");
/*     */     AnimatingConstraints.setColorAnimation$default($this$unHoverText_u24lambda_u2d15, (AnimationStrategy)Animations.OUT_EXP, 0.25F, (ColorConstraint)UtilitiesKt.toConstraint(color), 0.0F, 8, null);
/*     */     $this$animate_u24lambda_u2d0$iv.animateTo(anim$iv);
/*     */   }
/*     */   
/*     */   private final void readOptionComponents() {
/*     */     getOptionsHolder().clearChildren();
/*     */     Iterable<UIComponent> $this$forEachIndexed$iv = this.mappedOptions;
/*     */     int $i$f$forEachIndexed = 0;
/*     */     int index$iv = 0;
/*     */     Iterator<UIComponent> iterator = $this$forEachIndexed$iv.iterator();
/*     */     if (iterator.hasNext()) {
/*     */       Object item$iv = iterator.next();
/*     */       int i = index$iv;
/*     */       index$iv = i + 1;
/*     */       i = i;
/*     */       if (i < 0)
/*     */         CollectionsKt.throwIndexOverflow(); 
/*     */       UIComponent uIComponent = (UIComponent)item$iv;
/*     */       int index = i, $i$a$-forEachIndexed-DropDown$readOptionComponents$1 = 0;
/*     */       if (index != this.selected)
/*     */         ComponentsKt.childOf(uIComponent, (UIComponent)getOptionsHolder()); 
/*     */     } 
/*     */   } }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\clickgui\settings\DropDown.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */