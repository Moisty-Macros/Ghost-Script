/*    */ package xyz.apfelmus.cheeto.client.clickgui.settings;
/*    */ import gg.essential.elementa.UIComponent;
/*    */ import gg.essential.elementa.UIConstraints;
/*    */ import gg.essential.elementa.components.UIImage;
/*    */ import gg.essential.elementa.dsl.UtilitiesKt;
/*    */ import gg.essential.elementa.effects.OutlineEffect;
/*    */ import java.awt.Color;
/*    */ import xyz.apfelmus.cheeto.client.utils.client.ColorUtils;
/*    */ 
/*    */ @Metadata(mv = {1, 6, 0}, k = 1, xi = 48, d1 = {"\000&\n\002\030\002\n\002\030\002\n\000\n\002\020\013\n\002\b\007\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\030\0002\0020\001B\r\022\006\020\002\032\0020\003¢\006\002\020\004J\b\020\f\032\0020\rH\002J\020\020\016\032\n \020*\004\030\0010\0170\017H\002R$\020\006\032\0020\0032\006\020\005\032\0020\003@FX\016¢\006\016\n\000\032\004\b\007\020\b\"\004\b\t\020\004R\016\020\n\032\0020\013X\004¢\006\002\n\000¨\006\021"}, d2 = {"Lxyz/apfelmus/cheeto/client/clickgui/settings/CheckboxComponent;", "Lxyz/apfelmus/cheeto/client/clickgui/settings/SettingComponent;", "initialValue", "", "(Z)V", "value", "checked", "getChecked", "()Z", "setChecked", "checkmark", "Lgg/essential/elementa/components/UIImage;", "getOutlineEffect", "Lgg/essential/elementa/effects/OutlineEffect;", "getSettingColor", "Ljava/awt/Color;", "kotlin.jvm.PlatformType", "Cheeto"})
/*    */ public final class CheckboxComponent extends SettingComponent {
/*    */   public CheckboxComponent(boolean initialValue) {
/* 13 */     this.checked = initialValue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 19 */     UIComponent $this$constrain$iv = (UIComponent)UIImage.Companion.ofResourceCached("/vigilance/check.png"); int $i$f$constrain = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 57 */     UIComponent uIComponent1 = $this$constrain$iv, $this$constrain_u24lambda_u2d0$iv = uIComponent1; int $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 58 */     UIConstraints uIConstraints1 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); CheckboxComponent checkboxComponent = this; int $i$a$-constrain-CheckboxComponent$checkmark$1 = 0; uIConstraints1.setX((XConstraint)new CenterConstraint()); uIConstraints1.setY((YConstraint)new CenterConstraint()); uIConstraints1.setWidth((WidthConstraint)UtilitiesKt.pixels$default(Integer.valueOf(16), false, false, 3, null)); uIConstraints1.setHeight((HeightConstraint)UtilitiesKt.pixels$default(Integer.valueOf(12), false, false, 3, null)); Color color = ColorUtils.SELECTED; Intrinsics.checkNotNullExpressionValue(color, "SELECTED"); uIConstraints1.setColor((ColorConstraint)UtilitiesKt.toConstraint(color)); checkboxComponent.checkmark = (UIImage)ComponentsKt.childOf(uIComponent1, (UIComponent)this); $this$constrain$iv = (UIComponent)this;
/*    */     $i$f$constrain = 0;
/* 60 */     $this$constrain_u24lambda_u2d0$iv = uIComponent1 = $this$constrain$iv; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 61 */     UIConstraints $this$_init__u24lambda_u2d1 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); int $i$a$-constrain-CheckboxComponent$1 = 0; $this$_init__u24lambda_u2d1.setWidth((WidthConstraint)UtilitiesKt.pixels$default(Integer.valueOf(20), false, false, 3, null)); $this$_init__u24lambda_u2d1.setHeight((HeightConstraint)new AspectConstraint(0.0F, 1, null)); ComponentsKt.effect((UIComponent)this, (Effect)getOutlineEffect()); if (!this.checked)
/*    */       this.checkmark.hide(true);  UIComponent $this$onLeftClick$iv = (UIComponent)this; int $i$f$onLeftClick = 0;
/* 63 */     $this$onLeftClick$iv.onMouseClick(new CheckboxComponent$special$$inlined$onLeftClick$1(this));
/*    */   }
/*    */   
/*    */   private boolean checked;
/*    */   @NotNull
/*    */   private final UIImage checkmark;
/*    */   
/*    */   public final boolean getChecked() {
/*    */     return this.checked;
/*    */   }
/*    */   
/*    */   public final void setChecked(boolean value) {
/*    */     SettingComponent.changeValue$default(this, Boolean.valueOf(value), false, 2, null);
/*    */     this.checked = value;
/*    */   }
/*    */   
/*    */   private final OutlineEffect getOutlineEffect() {
/*    */     Color color = getSettingColor();
/*    */     Intrinsics.checkNotNullExpressionValue(color, "getSettingColor()");
/*    */     return new OutlineEffect(color, 1.0F, false, false, null, 28, null);
/*    */   }
/*    */   
/*    */   private final Color getSettingColor() {
/*    */     return this.checked ? ColorUtils.SELECTED : ColorUtils.SELECT;
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\clickgui\settings\CheckboxComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */