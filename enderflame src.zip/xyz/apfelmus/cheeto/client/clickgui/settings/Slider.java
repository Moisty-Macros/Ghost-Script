/*    */ package xyz.apfelmus.cheeto.client.clickgui.settings;
/*    */ import gg.essential.elementa.UIComponent;
/*    */ import gg.essential.elementa.UIConstraints;
/*    */ import java.awt.Color;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ @Metadata(mv = {1, 6, 0}, k = 1, xi = 48, d1 = {"\000,\n\002\030\002\n\002\030\002\n\000\n\002\020\007\n\002\b\002\n\002\030\002\n\000\n\002\020\013\n\002\b\005\n\002\030\002\n\002\020\002\n\002\b\b\030\0002\0020\001B\r\022\006\020\002\032\0020\003¢\006\002\020\004J\006\020\022\032\0020\003J\032\020\r\032\0020\0172\022\020\023\032\016\022\004\022\0020\003\022\004\022\0020\0170\016J\030\020\024\032\0020\0172\006\020\025\032\0020\0032\b\b\002\020\026\032\0020\bR\016\020\005\032\0020\006X\004¢\006\002\n\000R\016\020\007\032\0020\bX\016¢\006\002\n\000R\021\020\t\032\0020\006¢\006\b\n\000\032\004\b\n\020\013R\016\020\f\032\0020\003X\016¢\006\002\n\000R\032\020\r\032\016\022\004\022\0020\003\022\004\022\0020\0170\016X\016¢\006\002\n\000R\016\020\020\032\0020\001X\004¢\006\002\n\000R\016\020\021\032\0020\003X\016¢\006\002\n\000¨\006\027"}, d2 = {"Lxyz/apfelmus/cheeto/client/clickgui/settings/Slider;", "Lgg/essential/elementa/components/UIContainer;", "initialValue", "", "(F)V", "completionBox", "Lgg/essential/elementa/components/UIBlock;", "dragging", "", "grabBox", "getGrabBox", "()Lgg/essential/elementa/components/UIBlock;", "grabOffset", "onValueChange", "Lkotlin/Function1;", "", "outerBox", "percentage", "getCurrentPercentage", "listener", "setCurrentPercentage", "newPercentage", "callListener", "Cheeto"})
/*    */ public final class Slider extends UIContainer {
/*    */   public Slider(float initialValue) {
/* 13 */     this.percentage = initialValue;
/* 14 */     this.onValueChange = Slider$onValueChange$1.INSTANCE;
/*    */ 
/*    */ 
/*    */     
/* 18 */     UIComponent uIComponent1 = (UIComponent)new UIContainer(); int $i$f$constrain = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 84 */     UIComponent uIComponent2 = uIComponent1, $this$constrain_u24lambda_u2d0$iv = uIComponent2; int $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 85 */     UIConstraints uIConstraints1 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); Slider slider = this; int $i$a$-constrain-Slider$outerBox$1 = 0; uIConstraints1.setX(BasicConstraintsKt.basicXConstraint(new Slider$outerBox$1$1())); uIConstraints1.setY((YConstraint)new CenterConstraint()); uIConstraints1.setWidth(BasicConstraintsKt.basicWidthConstraint(new Slider$outerBox$1$2())); uIConstraints1.setHeight((HeightConstraint)new RelativeConstraint(0.5F)); Color color2 = ColorUtils.C_BORDER; Intrinsics.checkNotNullExpressionValue(color2, "C_BORDER"); slider.outerBox = (UIContainer)ComponentsKt.effect(ComponentsKt.childOf(uIComponent2, (UIComponent)this), (Effect)new OutlineEffect(color2, 1.0F, false, false, null, 28, null)); UIComponent $this$constrain$iv = (UIComponent)new UIBlock(null, 1, null);
/*    */     $i$f$constrain = 0;
/* 87 */     $this$constrain_u24lambda_u2d0$iv = uIComponent2 = $this$constrain$iv; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 88 */     UIConstraints $this$outerBox_u24lambda_u2d0 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); slider = this; int $i$a$-constrain-Slider$completionBox$1 = 0; $this$outerBox_u24lambda_u2d0.setWidth((WidthConstraint)new RelativeConstraint(this.percentage)); $this$outerBox_u24lambda_u2d0.setHeight((HeightConstraint)new RelativeConstraint(1.0F)); Color color3 = ColorUtils.SELECTED; Intrinsics.checkNotNullExpressionValue(color3, "SELECTED"); $this$outerBox_u24lambda_u2d0.setColor((ColorConstraint)UtilitiesKt.toConstraint(color3)); slider.completionBox = (UIBlock)ComponentsKt.childOf(uIComponent2, (UIComponent)this.outerBox); $this$constrain$iv = (UIComponent)new UIBlock(null, 1, null);
/*    */     $i$f$constrain = 0;
/* 90 */     $this$constrain_u24lambda_u2d0$iv = uIComponent2 = $this$constrain$iv; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 91 */     UIConstraints $this$completionBox_u24lambda_u2d1 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); slider = this; int $i$a$-constrain-Slider$grabBox$1 = 0; $this$completionBox_u24lambda_u2d1.setX(BasicConstraintsKt.basicXConstraint(new Slider$grabBox$1$1())); $this$completionBox_u24lambda_u2d1.setY((YConstraint)ConstraintsKt.boundTo((SuperConstraint)new CenterConstraint(), (UIComponent)this.outerBox)); $this$completionBox_u24lambda_u2d1.setWidth((WidthConstraint)new AspectConstraint(1.0F)); $this$completionBox_u24lambda_u2d1.setHeight((HeightConstraint)UtilitiesKt.percent(Integer.valueOf(100))); color3 = ColorUtils.SELECTED; Intrinsics.checkNotNullExpressionValue(color3, "SELECTED"); $this$completionBox_u24lambda_u2d1.setColor((ColorConstraint)UtilitiesKt.toConstraint(color3)); Color color1 = ColorUtils.M_BORDER; Intrinsics.checkNotNullExpressionValue(color1, "M_BORDER"); slider.grabBox = (UIBlock)ComponentsKt.effect(ComponentsKt.childOf(uIComponent2, (UIComponent)this), (Effect)new OutlineEffect(color1, 1.0F, false, false, null, 28, null)); UIComponent $this$onLeftClick$iv = (UIComponent)this.grabBox;
/*    */     int $i$f$onLeftClick = 0;
/* 93 */     $this$onLeftClick$iv.onMouseClick(new Slider$special$$inlined$onLeftClick$1(this)).onMouseRelease(new Function1<UIComponent, Unit>() { public final void invoke(@NotNull UIComponent $this$onMouseRelease) { Intrinsics.checkNotNullParameter($this$onMouseRelease, "$this$onMouseRelease"); Slider.this.dragging = false; Slider.this.grabOffset = 0.0F; } }
/*    */       ).onMouseDrag(new Function4<UIComponent, Float, Float, Integer, Unit>() { public final void invoke(@NotNull UIComponent $this$onMouseDrag, float mouseX, float $noName_1, int $noName_2) { Intrinsics.checkNotNullParameter($this$onMouseDrag, "$this$onMouseDrag"); if (!Slider.this.dragging)
/*    */               return;  float clamped = ((Number)RangesKt.coerceIn(Float.valueOf(mouseX + Slider.this.getGrabBox().getLeft() - Slider.this.grabOffset), RangesKt.rangeTo(Slider.this.outerBox.getLeft(), Slider.this.outerBox.getRight()))).floatValue(); float percentage = (clamped - Slider.this.outerBox.getLeft()) / Slider.this.outerBox.getWidth(); Slider.setCurrentPercentage$default(Slider.this, percentage, false, 2, (Object)null); } }
/*    */       ); $this$onLeftClick$iv = (UIComponent)this.outerBox;
/*    */     $i$f$onLeftClick = 0;
/* 98 */     $this$onLeftClick$iv.onMouseClick(new Slider$special$$inlined$onLeftClick$2(this));
/*    */   }
/*    */   
/*    */   private float percentage;
/*    */   @NotNull
/*    */   private Function1<? super Float, Unit> onValueChange;
/*    */   private boolean dragging;
/*    */   private float grabOffset;
/*    */   @NotNull
/*    */   private final UIContainer outerBox;
/*    */   @NotNull
/*    */   private final UIBlock completionBox;
/*    */   @NotNull
/*    */   private final UIBlock grabBox;
/*    */   
/*    */   @Metadata(mv = {1, 6, 0}, k = 3, xi = 48, d1 = {"\000\016\n\000\n\002\020\002\n\000\n\002\020\007\n\000\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "it", "", "invoke"})
/*    */   static final class Slider$onValueChange$1 extends Lambda implements Function1<Float, Unit> {
/*    */     public static final Slider$onValueChange$1 INSTANCE = new Slider$onValueChange$1();
/*    */     
/*    */     Slider$onValueChange$1() {
/*    */       super(1);
/*    */     }
/*    */     
/*    */     public final void invoke(float it) {}
/*    */   }
/*    */   
/*    */   @Metadata(mv = {1, 6, 0}, k = 3, xi = 48, d1 = {"\000\020\n\000\n\002\020\007\n\000\n\002\030\002\n\002\b\002\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\004\b\004\020\005"}, d2 = {"<anonymous>", "", "it", "Lgg/essential/elementa/UIComponent;", "invoke", "(Lgg/essential/elementa/UIComponent;)Ljava/lang/Float;"})
/*    */   static final class Slider$outerBox$1$1 extends Lambda implements Function1<UIComponent, Float> {
/*    */     @NotNull
/*    */     public final Float invoke(@NotNull UIComponent it) {
/*    */       Intrinsics.checkNotNullParameter(it, "it");
/*    */       return Float.valueOf(Slider.this.getLeft() + 1.0F + Slider.this.getHeight() * 0.75F);
/*    */     }
/*    */     
/*    */     Slider$outerBox$1$1() {
/*    */       super(1);
/*    */     }
/*    */   }
/*    */   
/*    */   @Metadata(mv = {1, 6, 0}, k = 3, xi = 48, d1 = {"\000\020\n\000\n\002\020\007\n\000\n\002\030\002\n\002\b\002\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\004\b\004\020\005"}, d2 = {"<anonymous>", "", "it", "Lgg/essential/elementa/UIComponent;", "invoke", "(Lgg/essential/elementa/UIComponent;)Ljava/lang/Float;"})
/*    */   static final class Slider$outerBox$1$2 extends Lambda implements Function1<UIComponent, Float> {
/*    */     @NotNull
/*    */     public final Float invoke(@NotNull UIComponent it) {
/*    */       Intrinsics.checkNotNullParameter(it, "it");
/*    */       return Float.valueOf(Slider.this.getWidth() - 2.0F - Slider.this.getHeight() * 1.5F);
/*    */     }
/*    */     
/*    */     Slider$outerBox$1$2() {
/*    */       super(1);
/*    */     }
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public final UIBlock getGrabBox() {
/*    */     return this.grabBox;
/*    */   }
/*    */   
/*    */   @Metadata(mv = {1, 6, 0}, k = 3, xi = 48, d1 = {"\000\020\n\000\n\002\020\007\n\000\n\002\030\002\n\002\b\002\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\004\b\004\020\005"}, d2 = {"<anonymous>", "", "it", "Lgg/essential/elementa/UIComponent;", "invoke", "(Lgg/essential/elementa/UIComponent;)Ljava/lang/Float;"})
/*    */   static final class Slider$grabBox$1$1 extends Lambda implements Function1<UIComponent, Float> {
/*    */     Slider$grabBox$1$1() {
/*    */       super(1);
/*    */     }
/*    */     
/*    */     @NotNull
/*    */     public final Float invoke(@NotNull UIComponent it) {
/*    */       Intrinsics.checkNotNullParameter(it, "it");
/*    */       return Float.valueOf(Slider.this.completionBox.getRight() - it.getWidth() / 2.0F);
/*    */     }
/*    */   }
/*    */   
/*    */   public final float getCurrentPercentage() {
/*    */     return this.percentage;
/*    */   }
/*    */   
/*    */   public final void setCurrentPercentage(float newPercentage, boolean callListener) {
/*    */     this.percentage = ((Number)RangesKt.coerceIn(Float.valueOf(newPercentage), RangesKt.rangeTo(0.0F, 1.0F))).floatValue();
/*    */     this.completionBox.setWidth((WidthConstraint)new RelativeConstraint(this.percentage));
/*    */     if (callListener)
/*    */       this.onValueChange.invoke(Float.valueOf(this.percentage)); 
/*    */   }
/*    */   
/*    */   public final void onValueChange(@NotNull Function1<? super Float, Unit> listener) {
/*    */     Intrinsics.checkNotNullParameter(listener, "listener");
/*    */     this.onValueChange = listener;
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\clickgui\settings\Slider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */