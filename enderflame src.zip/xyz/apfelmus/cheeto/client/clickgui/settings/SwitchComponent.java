/*    */ package xyz.apfelmus.cheeto.client.clickgui.settings;
/*    */ import gg.essential.elementa.UIComponent;
/*    */ import gg.essential.elementa.UIConstraints;
/*    */ import gg.essential.elementa.constraints.animation.AnimatingConstraints;
/*    */ import gg.essential.elementa.constraints.animation.AnimationStrategy;
/*    */ import gg.essential.elementa.state.State;
/*    */ import java.awt.Color;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ @Metadata(mv = {1, 6, 0}, k = 1, xi = 48, d1 = {"\000.\n\002\030\002\n\002\030\002\n\000\n\002\020\013\n\002\b\006\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\030\0002\0020\001B\r\022\006\020\002\032\0020\003¢\006\002\020\004J\b\020\013\032\0020\fH\002J\016\020\r\032\b\022\004\022\0020\0170\016H\002J\b\020\020\032\0020\021H\002R\032\020\005\032\0020\003X\016¢\006\016\n\000\032\004\b\006\020\007\"\004\b\b\020\004R\016\020\t\032\0020\nX\004¢\006\002\n\000¨\006\022"}, d2 = {"Lxyz/apfelmus/cheeto/client/clickgui/settings/SwitchComponent;", "Lxyz/apfelmus/cheeto/client/clickgui/settings/SettingComponent;", "initialState", "", "(Z)V", "enabled", "getEnabled$Cheeto", "()Z", "setEnabled$Cheeto", "switchBox", "Lgg/essential/elementa/components/UIBlock;", "getOutlineEffect", "Lgg/essential/elementa/effects/OutlineEffect;", "getSwitchColor", "Lgg/essential/elementa/state/BasicState;", "Ljava/awt/Color;", "getSwitchPosition", "Lgg/essential/elementa/constraints/PixelConstraint;", "Cheeto"})
/*    */ public final class SwitchComponent extends SettingComponent {
/*    */   public SwitchComponent(boolean initialState) {
/* 18 */     this.enabled = initialState;
/*    */     
/* 20 */     UIComponent $this$constrain$iv = (UIComponent)new UIBlock((State)getSwitchColor()); int $i$f$constrain = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 68 */     UIComponent uIComponent1 = $this$constrain$iv, $this$constrain_u24lambda_u2d0$iv = uIComponent1; int $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 69 */     UIConstraints uIConstraints1 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); SwitchComponent switchComponent = this; int $i$a$-constrain-SwitchComponent$switchBox$1 = 0; uIConstraints1.setX((XConstraint)getSwitchPosition()); uIConstraints1.setWidth((WidthConstraint)new RelativeConstraint(0.5F)); uIConstraints1.setHeight((HeightConstraint)new RelativeConstraint(1.0F)); switchComponent.switchBox = (UIBlock)ComponentsKt.childOf(uIComponent1, (UIComponent)this); $this$constrain$iv = (UIComponent)this;
/*    */     $i$f$constrain = 0;
/* 71 */     $this$constrain_u24lambda_u2d0$iv = uIComponent1 = $this$constrain$iv; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 72 */     UIConstraints $this$_init__u24lambda_u2d1 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); int $i$a$-constrain-SwitchComponent$1 = 0; $this$_init__u24lambda_u2d1.setWidth((WidthConstraint)UtilitiesKt.pixels$default(Integer.valueOf(20), false, false, 3, null)); $this$_init__u24lambda_u2d1.setHeight((HeightConstraint)UtilitiesKt.pixels$default(Integer.valueOf(10), false, false, 3, null)); ComponentsKt.effect((UIComponent)this, (Effect)getOutlineEffect()); UIComponent $this$onLeftClick$iv = (UIComponent)this;
/*    */     int $i$f$onLeftClick = 0;
/* 74 */     $this$onLeftClick$iv.onMouseClick(new SwitchComponent$special$$inlined$onLeftClick$1(this));
/*    */     onMouseEnter(new Function1<UIComponent, Unit>() {
/*    */           public final void invoke(@NotNull UIComponent $this$onMouseEnter) {
/*    */             Intrinsics.checkNotNullParameter($this$onMouseEnter, "$this$onMouseEnter");
/*    */             UIComponent uIComponent1 = (UIComponent)SwitchComponent.this.switchBox;
/*    */             SwitchComponent switchComponent = SwitchComponent.this;
/*    */             int $i$f$animate = 0;
/*    */             UIComponent uIComponent2 = uIComponent1, $this$animate_u24lambda_u2d0$iv = uIComponent2;
/*    */             int $i$a$-apply-AnimationsKt$animate$1$iv = 0;
/*    */             AnimatingConstraints anim$iv = $this$animate_u24lambda_u2d0$iv.makeAnimation();
/*    */             AnimatingConstraints $this$invoke_u24lambda_u2d0 = anim$iv;
/*    */             int $i$a$-animate-SwitchComponent$3$1 = 0;
/*    */             AnimatingConstraints.setColorAnimation$default($this$invoke_u24lambda_u2d0, (AnimationStrategy)Animations.OUT_EXP, 0.25F, (ColorConstraint)ExtensionsKt.toConstraint((State)switchComponent.getSwitchColor().map(SwitchComponent$3$1$1.INSTANCE)), 0.0F, 8, null);
/*    */             $this$animate_u24lambda_u2d0$iv.animateTo(anim$iv);
/*    */           }
/*    */         });
/*    */     onMouseLeave(new Function1<UIComponent, Unit>() {
/*    */           public final void invoke(@NotNull UIComponent $this$onMouseLeave) {
/*    */             Intrinsics.checkNotNullParameter($this$onMouseLeave, "$this$onMouseLeave");
/*    */             UIComponent uIComponent1 = (UIComponent)SwitchComponent.this.switchBox;
/*    */             SwitchComponent switchComponent = SwitchComponent.this;
/*    */             int $i$f$animate = 0;
/*    */             UIComponent uIComponent2 = uIComponent1, $this$animate_u24lambda_u2d0$iv = uIComponent2;
/*    */             int $i$a$-apply-AnimationsKt$animate$1$iv = 0;
/*    */             AnimatingConstraints anim$iv = $this$animate_u24lambda_u2d0$iv.makeAnimation();
/*    */             AnimatingConstraints $this$invoke_u24lambda_u2d0 = anim$iv;
/*    */             int $i$a$-animate-SwitchComponent$4$1 = 0;
/*    */             AnimatingConstraints.setColorAnimation$default($this$invoke_u24lambda_u2d0, (AnimationStrategy)Animations.OUT_EXP, 0.25F, (ColorConstraint)ExtensionsKt.toConstraint((State)switchComponent.getSwitchColor()), 0.0F, 8, null);
/*    */             $this$animate_u24lambda_u2d0$iv.animateTo(anim$iv);
/*    */           }
/*    */         });
/*    */   }
/*    */   
/*    */   private boolean enabled;
/*    */   @NotNull
/*    */   private final UIBlock switchBox;
/*    */   
/*    */   public final boolean getEnabled$Cheeto() {
/*    */     return this.enabled;
/*    */   }
/*    */   
/*    */   public final void setEnabled$Cheeto(boolean <set-?>) {
/*    */     this.enabled = <set-?>;
/*    */   }
/*    */   
/*    */   private final OutlineEffect getOutlineEffect() {
/*    */     return (new OutlineEffect((Color)getSwitchColor().get(), 1.0F, false, false, null, 28, null)).bindColor((State)getSwitchColor());
/*    */   }
/*    */   
/*    */   private final BasicState<Color> getSwitchColor() {
/*    */     Color color = ColorUtils.SELECTED;
/*    */     Intrinsics.checkNotNullExpressionValue(color, "SELECTED");
/*    */     color = ColorUtils.SELECT;
/*    */     Intrinsics.checkNotNullExpressionValue(color, "SELECT");
/*    */     return this.enabled ? new BasicState(color) : new BasicState(color);
/*    */   }
/*    */   
/*    */   private final PixelConstraint getSwitchPosition() {
/*    */     return this.enabled ? UtilitiesKt.pixels$default(Integer.valueOf(0), true, false, 2, null) : UtilitiesKt.pixels$default(Integer.valueOf(0), false, false, 3, null);
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\clickgui\settings\SwitchComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */