/*    */ package xyz.apfelmus.cheeto.client.clickgui.settings;
/*    */ 
/*    */ import gg.essential.elementa.UIComponent;
/*    */ import gg.essential.elementa.UIConstraints;
/*    */ import gg.essential.elementa.constraints.WidthConstraint;
/*    */ import gg.essential.elementa.constraints.animation.AnimatingConstraints;
/*    */ import gg.essential.elementa.constraints.animation.AnimationStrategy;
/*    */ import gg.essential.elementa.constraints.animation.Animations;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ @Metadata(mv = {1, 6, 0}, k = 1, xi = 48, d1 = {"\0002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\013\n\002\b\002\n\002\030\002\n\002\b\003\n\002\020\002\n\000\n\002\020\007\n\002\b\002\n\002\030\002\n\002\b\002\b&\030\0002\0020\001B\005¢\006\002\020\002J\016\020\n\032\0020\0132\006\020\f\032\0020\rJ\020\020\016\032\0020\0132\006\020\017\032\0020\020H\026J\b\020\021\032\0020\013H\004R\016\020\003\032\0020\004X\016¢\006\002\n\000R\016\020\005\032\0020\004X\016¢\006\002\n\000R\022\020\006\032\0020\007X¤\004¢\006\006\032\004\b\b\020\t¨\006\022"}, d2 = {"Lxyz/apfelmus/cheeto/client/clickgui/settings/AbstractSliderComponent;", "Lxyz/apfelmus/cheeto/client/clickgui/settings/SettingComponent;", "()V", "expanded", "", "mouseHeld", "slider", "Lxyz/apfelmus/cheeto/client/clickgui/settings/Slider;", "getSlider", "()Lxyz/apfelmus/cheeto/client/clickgui/settings/Slider;", "incrementBy", "", "inc", "", "setupParentListeners", "parent", "Lgg/essential/elementa/UIComponent;", "sliderInit", "Cheeto"})
/*    */ public abstract class AbstractSliderComponent extends SettingComponent {
/*    */   private boolean expanded;
/*    */   private boolean mouseHeld;
/*    */   
/* 19 */   public AbstractSliderComponent() { UIComponent $this$constrain$iv = (UIComponent)this; int $i$f$constrain = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 61 */     UIComponent uIComponent1 = $this$constrain$iv, $this$constrain_u24lambda_u2d0$iv = uIComponent1; int $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 62 */     UIConstraints $this$_init__u24lambda_u2d0 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); int $i$a$-constrain-AbstractSliderComponent$1 = 0; $this$_init__u24lambda_u2d0.setWidth((WidthConstraint)new ChildBasedSizeConstraint(0.0F, 1, null)); $this$_init__u24lambda_u2d0.setHeight((HeightConstraint)new ChildBasedMaxSizeConstraint()); } public void setupParentListeners(@NotNull UIComponent parent) { Intrinsics.checkNotNullParameter(parent, "parent"); parent.onMouseEnter(new AbstractSliderComponent$setupParentListeners$1()).onMouseLeave(new AbstractSliderComponent$setupParentListeners$2()); } @Metadata(mv = {1, 6, 0}, k = 3, xi = 48, d1 = {"\000\f\n\000\n\002\020\002\n\002\030\002\n\000\020\000\032\0020\001*\0020\002H\n¢\006\002\b\003"}, d2 = {"<anonymous>", "", "Lgg/essential/elementa/UIComponent;", "invoke"}) static final class AbstractSliderComponent$setupParentListeners$1 extends Lambda implements Function1<UIComponent, Unit> { AbstractSliderComponent$setupParentListeners$1() { super(1); } public final void invoke(@NotNull UIComponent $this$onMouseEnter) { Intrinsics.checkNotNullParameter($this$onMouseEnter, "$this$onMouseEnter"); UIComponent $this$animate$iv = (UIComponent)AbstractSliderComponent.this.getSlider(); int $i$f$animate = 0; UIComponent uIComponent1 = $this$animate$iv, $this$animate_u24lambda_u2d0$iv = uIComponent1; int $i$a$-apply-AnimationsKt$animate$1$iv = 0; AnimatingConstraints anim$iv = $this$animate_u24lambda_u2d0$iv.makeAnimation();
/* 63 */       AnimatingConstraints $this$invoke_u24lambda_u2d0 = anim$iv; int $i$a$-animate-AbstractSliderComponent$setupParentListeners$1$1 = 0; AnimatingConstraints.setWidthAnimation$default($this$invoke_u24lambda_u2d0, (AnimationStrategy)Animations.OUT_EXP, 0.25F, (WidthConstraint)UtilitiesKt.pixels$default(Integer.valueOf(100), false, false, 3, null), 0.0F, 8, null);
/* 64 */       $this$animate_u24lambda_u2d0$iv.animateTo(anim$iv); AbstractSliderComponent.this.expanded = true; } } @Metadata(mv = {1, 6, 0}, k = 3, xi = 48, d1 = {"\000\f\n\000\n\002\020\002\n\002\030\002\n\000\020\000\032\0020\001*\0020\002H\n¢\006\002\b\003"}, d2 = {"<anonymous>", "", "Lgg/essential/elementa/UIComponent;", "invoke"}) static final class AbstractSliderComponent$setupParentListeners$2 extends Lambda implements Function1<UIComponent, Unit> { public final void invoke(@NotNull UIComponent $this$onMouseLeave) { Intrinsics.checkNotNullParameter($this$onMouseLeave, "$this$onMouseLeave"); if (!AbstractSliderComponent.this.mouseHeld) { UIComponent $this$animate$iv = (UIComponent)AbstractSliderComponent.this.getSlider(); int $i$f$animate = 0; UIComponent uIComponent1 = $this$animate$iv, $this$animate_u24lambda_u2d0$iv = uIComponent1; int $i$a$-apply-AnimationsKt$animate$1$iv = 0; AnimatingConstraints anim$iv = $this$animate_u24lambda_u2d0$iv.makeAnimation(); AnimatingConstraints $this$invoke_u24lambda_u2d0 = anim$iv; int $i$a$-animate-AbstractSliderComponent$setupParentListeners$2$1 = 0; AnimatingConstraints.setWidthAnimation$default($this$invoke_u24lambda_u2d0, (AnimationStrategy)Animations.OUT_EXP, 0.25F, (WidthConstraint)UtilitiesKt.pixels$default(Integer.valueOf(60), false, false, 3, null), 0.0F, 8, null); $this$animate_u24lambda_u2d0$iv.animateTo(anim$iv); AbstractSliderComponent.this.expanded = false; }  } AbstractSliderComponent$setupParentListeners$2() { super(1); } } protected final void sliderInit() { UIComponent $this$onLeftClick$iv = (UIComponent)this; int $i$f$onLeftClick = 0; $this$onLeftClick$iv.onMouseClick(new AbstractSliderComponent$sliderInit$$inlined$onLeftClick$1(this)); onMouseRelease(new AbstractSliderComponent$sliderInit$2()); } @Metadata(mv = {1, 6, 0}, k = 3, xi = 48, d1 = {"\000\f\n\000\n\002\020\002\n\002\030\002\n\000\020\000\032\0020\001*\0020\002H\n¢\006\002\b\003"}, d2 = {"<anonymous>", "", "Lgg/essential/elementa/UIComponent;", "invoke"}) static final class AbstractSliderComponent$sliderInit$2 extends Lambda implements Function1<UIComponent, Unit> { public final void invoke(@NotNull UIComponent $this$onMouseRelease) { Intrinsics.checkNotNullParameter($this$onMouseRelease, "$this$onMouseRelease"); AbstractSliderComponent.this.mouseHeld = false; if (AbstractSliderComponent.this.expanded && !AbstractSliderComponent.this.getSlider().isHovered()) { UIComponent $this$animate$iv = (UIComponent)AbstractSliderComponent.this.getSlider(); int $i$f$animate = 0; UIComponent uIComponent1 = $this$animate$iv, $this$animate_u24lambda_u2d0$iv = uIComponent1; int $i$a$-apply-AnimationsKt$animate$1$iv = 0; AnimatingConstraints anim$iv = $this$animate_u24lambda_u2d0$iv.makeAnimation(); AnimatingConstraints $this$invoke_u24lambda_u2d0 = anim$iv; int $i$a$-animate-AbstractSliderComponent$sliderInit$2$1 = 0; AnimatingConstraints.setWidthAnimation$default($this$invoke_u24lambda_u2d0, (AnimationStrategy)Animations.OUT_EXP, 0.25F, (WidthConstraint)UtilitiesKt.pixels$default(Integer.valueOf(60), false, false, 3, null), 0.0F, 8, null); $this$animate_u24lambda_u2d0$iv.animateTo(anim$iv);
/*    */         AbstractSliderComponent.this.expanded = false; }
/*    */        }
/*    */ 
/*    */     
/*    */     AbstractSliderComponent$sliderInit$2() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */   
/*    */   public final void incrementBy(float inc) {
/*    */     Slider.setCurrentPercentage$default(getSlider(), getSlider().getCurrentPercentage() + inc, false, 2, null);
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   protected abstract Slider getSlider();
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\clickgui\settings\AbstractSliderComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */