/*    */ package xyz.apfelmus.cheeto.client.clickgui.settings;
/*    */ import gg.essential.elementa.UIComponent;
/*    */ import kotlin.Unit;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ @Metadata(mv = {1, 6, 0}, k = 1, xi = 48, d1 = {"\000.\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\000\n\000\n\002\030\002\n\002\020\002\n\002\b\003\n\002\020\013\n\002\b\005\n\002\030\002\n\002\b\002\b&\030\000 \0222\0020\001:\001\022B\005¢\006\002\020\002J\032\020\b\032\0020\0072\b\020\t\032\004\030\0010\0042\b\b\002\020\n\032\0020\013J\022\020\f\032\0020\0072\b\b\002\020\r\032\0020\013H\026J\034\020\005\032\0020\0072\024\020\016\032\020\022\006\022\004\030\0010\004\022\004\022\0020\0070\006J\020\020\017\032\0020\0072\006\020\020\032\0020\021H\026R\020\020\003\032\004\030\0010\004X\016¢\006\002\n\000R\034\020\005\032\020\022\006\022\004\030\0010\004\022\004\022\0020\0070\006X\016¢\006\002\n\000¨\006\023"}, d2 = {"Lxyz/apfelmus/cheeto/client/clickgui/settings/SettingComponent;", "Lgg/essential/elementa/components/UIContainer;", "()V", "lastValue", "", "onValueChange", "Lkotlin/Function1;", "", "changeValue", "newValue", "callListener", "", "closePopups", "instantly", "listener", "setupParentListeners", "parent", "Lgg/essential/elementa/UIComponent;", "Companion", "Cheeto"})
/*    */ public abstract class SettingComponent extends UIContainer {
/*    */   @NotNull
/*  9 */   private Function1<Object, Unit> onValueChange = SettingComponent$onValueChange$1.INSTANCE; @NotNull
/*    */   public static final Companion Companion = new Companion(null); @Nullable
/*    */   private Object lastValue; @NotNull
/*    */   public static final String DOWN_ARROW_PNG = "/vigilance/arrow-down.png"; public SettingComponent() {
/* 13 */     UIComponent $this$constrain$iv = (UIComponent)this; int $i$f$constrain = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 39 */     UIComponent uIComponent1 = $this$constrain$iv, $this$constrain_u24lambda_u2d0$iv = uIComponent1; int $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 40 */     UIConstraints $this$_init__u24lambda_u2d0 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); int $i$a$-constrain-SettingComponent$1 = 0;
/*    */     $this$_init__u24lambda_u2d0.setX((XConstraint)new CenterConstraint());
/*    */     $this$_init__u24lambda_u2d0.setY((YConstraint)new CenterConstraint());
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public static final String UP_ARROW_PNG = "/vigilance/arrow-up.png";
/*    */   
/*    */   @Metadata(mv = {1, 6, 0}, k = 3, xi = 48, d1 = {"\000\016\n\000\n\002\020\002\n\000\n\002\020\000\n\000\020\000\032\0020\0012\b\020\002\032\004\030\0010\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "it", "", "invoke"})
/*    */   static final class SettingComponent$onValueChange$1 extends Lambda implements Function1<Object, Unit> {
/*    */     public static final SettingComponent$onValueChange$1 INSTANCE = new SettingComponent$onValueChange$1();
/*    */     
/*    */     SettingComponent$onValueChange$1() {
/*    */       super(1);
/*    */     }
/*    */     
/*    */     public final void invoke(@Nullable Object it) {}
/*    */   }
/*    */   
/*    */   public final void onValueChange(@NotNull Function1<Object, Unit> listener) {
/*    */     Intrinsics.checkNotNullParameter(listener, "listener");
/*    */     this.onValueChange = listener;
/*    */   }
/*    */   
/*    */   public final void changeValue(@Nullable Object newValue, boolean callListener) {
/*    */     if (!Intrinsics.areEqual(newValue, this.lastValue)) {
/*    */       this.lastValue = newValue;
/*    */       this.onValueChange.invoke(newValue);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void closePopups(boolean instantly) {}
/*    */   
/*    */   public void setupParentListeners(@NotNull UIComponent parent) {
/*    */     Intrinsics.checkNotNullParameter(parent, "parent");
/*    */   }
/*    */   
/*    */   @Metadata(mv = {1, 6, 0}, k = 1, xi = 48, d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\002\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004XT¢\006\002\n\000¨\006\006"}, d2 = {"Lxyz/apfelmus/cheeto/client/clickgui/settings/SettingComponent$Companion;", "", "()V", "DOWN_ARROW_PNG", "", "UP_ARROW_PNG", "Cheeto"})
/*    */   public static final class Companion {
/*    */     private Companion() {}
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\clickgui\settings\SettingComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */