/*    */ package xyz.apfelmus.cheeto.client.clickgui;
/*    */ import gg.essential.elementa.UIComponent;
/*    */ import gg.essential.elementa.UIConstraints;
/*    */ import gg.essential.elementa.components.UIContainer;
/*    */ import gg.essential.elementa.constraints.YConstraint;
/*    */ import gg.essential.elementa.dsl.ComponentsKt;
/*    */ import gg.essential.elementa.dsl.UtilitiesKt;
/*    */ import java.awt.Color;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Ref;
/*    */ import kotlin.reflect.KProperty;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import xyz.apfelmus.cf4m.CF4M;
/*    */ import xyz.apfelmus.cheeto.client.clickgui.settings.ButtonComponent;
/*    */ 
/*    */ @Metadata(mv = {1, 6, 0}, k = 1, xi = 48, d1 = {"\000\030\n\002\030\002\n\002\030\002\n\000\n\002\020\000\n\000\n\002\030\002\n\002\b\007\030\0002\0020\001B\025\022\006\020\002\032\0020\003\022\006\020\004\032\0020\005¢\006\002\020\006R\016\020\002\032\0020\003X\004¢\006\002\n\000R\033\020\007\032\0020\0018BX\002¢\006\f\n\004\b\n\020\013\032\004\b\b\020\t¨\006\f"}, d2 = {"Lxyz/apfelmus/cheeto/client/clickgui/KeybindLabel;", "Lgg/essential/elementa/components/UIContainer;", "module", "", "window", "Lgg/essential/elementa/components/Window;", "(Ljava/lang/Object;Lgg/essential/elementa/components/Window;)V", "textContainer", "getTextContainer", "()Lgg/essential/elementa/components/UIContainer;", "textContainer$delegate", "Lkotlin/properties/ReadWriteProperty;", "Cheeto"})
/*    */ public final class KeybindLabel extends UIContainer {
/*    */   public KeybindLabel(@NotNull Object module, @NotNull Window window) {
/* 20 */     this.module = module;
/* 21 */     UIComponent $this$constrain$iv = (UIComponent)new UIContainer(); int $i$f$constrain = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 83 */     UIComponent uIComponent2 = $this$constrain$iv, $this$constrain_u24lambda_u2d0$iv = uIComponent2; int $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 84 */     UIConstraints uIConstraints1 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); KeybindLabel keybindLabel = this; int $i$a$-constrain-KeybindLabel$textContainer$2 = 0; uIConstraints1.setY((YConstraint)new CenterConstraint()); uIConstraints1.setWidth((WidthConstraint)new ChildBasedSizeConstraint(0.0F, 1, null)); uIConstraints1.setHeight((HeightConstraint)new ChildBasedSizeConstraint(0.0F, 1, null)); keybindLabel.textContainer$delegate = ComponentsKt.provideDelegate(ComponentsKt.childOf(uIComponent2, (UIComponent)this), this, $$delegatedProperties[0]); $this$constrain$iv = (UIComponent)new UIText("Enable", false, null, 6, null);
/*    */     $i$f$constrain = 0;
/* 86 */     $this$constrain_u24lambda_u2d0$iv = uIComponent2 = $this$constrain$iv; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 87 */     UIConstraints $this$_init__u24lambda_u2d1 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); int $i$a$-constrain-KeybindLabel$1 = 0; $this$_init__u24lambda_u2d1.setX((XConstraint)UtilitiesKt.pixels$default(Integer.valueOf(10), false, false, 3, null)); $this$_init__u24lambda_u2d1.setY((YConstraint)new CenterConstraint()); $this$_init__u24lambda_u2d1.setTextScale((HeightConstraint)UtilitiesKt.pixels$default(Float.valueOf(1.5F), false, false, 3, null)); Color color2 = ColorUtils.LABEL; Intrinsics.checkNotNullExpressionValue(color2, "LABEL"); $this$_init__u24lambda_u2d1.setColor((ColorConstraint)UtilitiesKt.toConstraint(color2)); $this$_init__u24lambda_u2d1.setFontProvider(DefaultFonts.getVANILLA_FONT_RENDERER()); ComponentsKt.childOf(uIComponent2, (UIComponent)getTextContainer()); $this$constrain$iv = (UIComponent)this;
/*    */     $i$f$constrain = 0;
/* 89 */     $this$constrain_u24lambda_u2d0$iv = uIComponent2 = $this$constrain$iv; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 90 */     UIConstraints $this$_init__u24lambda_u2d2 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); int $i$a$-constrain-KeybindLabel$2 = 0; $this$_init__u24lambda_u2d2.setX((XConstraint)UtilitiesKt.pixels$default(Integer.valueOf(10), false, false, 3, null)); $this$_init__u24lambda_u2d2.setY((YConstraint)ConstraintsKt.plus((SuperConstraint)new SiblingConstraint(0.0F, false, 3, null), (SuperConstraint)UtilitiesKt.pixels$default(Integer.valueOf(10), false, false, 3, null))); $this$_init__u24lambda_u2d2.setWidth((WidthConstraint)ConstraintsKt.minus((SuperConstraint)new FillConstraint(false), (SuperConstraint)UtilitiesKt.pixels$default(Integer.valueOf(10), false, false, 3, null))); $this$_init__u24lambda_u2d2.setHeight((HeightConstraint)UtilitiesKt.pixels$default(Integer.valueOf(45), false, false, 3, null)); Color color1 = ColorUtils.M_BORDER; Intrinsics.checkNotNullExpressionValue(color1, "M_BORDER"); ComponentsKt.effect(uIComponent2, (Effect)new OutlineEffect(color1, 1.0F, false, false, null, 28, null)); CheckboxComponent enable = new CheckboxComponent(CF4M.INSTANCE.moduleManager.isEnabled(this.module)); UIComponent uIComponent1 = (UIComponent)enable;
/*    */     int i = 0;
/* 92 */     UIComponent uIComponent3 = uIComponent1, uIComponent5 = uIComponent3; int k = 0;
/* 93 */     UIConstraints $this$_init__u24lambda_u2d3 = uIComponent5.getConstraints(); int $i$a$-constrain-KeybindLabel$3 = 0; $this$_init__u24lambda_u2d3.setX((XConstraint)new SiblingConstraint(20.0F, false, 2, null)); $this$_init__u24lambda_u2d3.setY((YConstraint)UtilitiesKt.pixels$default(Integer.valueOf(12), false, false, 3, null)); ComponentsKt.childOf(uIComponent3, (UIComponent)this); enable.onValueChange(new Function1<Object, Unit>() { public final void invoke(@Nullable Object it) { if (it == null)
/*    */               throw new NullPointerException("null cannot be cast to non-null type kotlin.Boolean");  KeybindLabel.this.module.setEnabled(it, ((Boolean)it).booleanValue()); } }
/* 95 */       ); String key = Keyboard.getKeyName(CF4M.INSTANCE.moduleManager.getKey(this.module)); Ref.BooleanRef changing = new Ref.BooleanRef(); UIComponent uIComponent4 = (UIComponent)new ButtonComponent(Intrinsics.stringPlus("Keybind: ", key), new KeybindLabel$keybind$1(changing)); int j = 0; UIComponent uIComponent6 = uIComponent5 = uIComponent4; int m = 0;
/* 96 */     UIConstraints $this$_init__u24lambda_u2d4 = uIComponent6.getConstraints(); int $i$a$-constrain-KeybindLabel$keybind$2 = 0; $this$_init__u24lambda_u2d4.setX((XConstraint)UtilitiesKt.pixels$default(Integer.valueOf(12), true, false, 2, null)); $this$_init__u24lambda_u2d4.setY((YConstraint)UtilitiesKt.pixels$default(Integer.valueOf(12), false, false, 3, null)); ButtonComponent keybind = (ButtonComponent)ComponentsKt.childOf(uIComponent5, (UIComponent)this); UIComponent $this$onLeftClick$iv = (UIComponent)keybind;
/*    */     int $i$f$onLeftClick = 0;
/* 98 */     $this$onLeftClick$iv.onMouseClick(new KeybindLabel$special$$inlined$onLeftClick$1(changing, keybind));
/*    */     window.onKeyType(new Function3<UIComponent, Character, Integer, Unit>(keybind, this) {
/*    */           public final void invoke(@NotNull UIComponent $this$onKeyType, char typedChar, int keyCode) {
/*    */             Intrinsics.checkNotNullParameter($this$onKeyType, "$this$onKeyType");
/*    */             if (this.$changing.element) {
/*    */               if (keyCode == 14) {
/*    */                 this.$keybind.setText("Keybind: NONE");
/*    */                 CF4M.INSTANCE.moduleManager.setKey(KeybindLabel.this.module, 0);
/*    */               } else if (keyCode != 1) {
/*    */                 this.$keybind.setText(Intrinsics.stringPlus("Keybind: ", Keyboard.getKeyName(keyCode)));
/*    */                 CF4M.INSTANCE.moduleManager.setKey(KeybindLabel.this.module, keyCode);
/*    */               } 
/*    */               this.$changing.element = false;
/*    */             } 
/*    */           }
/*    */         });
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   private final Object module;
/*    */   @NotNull
/*    */   private final ReadWriteProperty textContainer$delegate;
/*    */   
/*    */   private final UIContainer getTextContainer() {
/*    */     return (UIContainer)this.textContainer$delegate.getValue(this, $$delegatedProperties[0]);
/*    */   }
/*    */   
/*    */   static {
/*    */     KProperty[] arrayOfKProperty = new KProperty[1];
/*    */     arrayOfKProperty[0] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(KeybindLabel.class, "textContainer", "getTextContainer()Lgg/essential/elementa/components/UIContainer;", 0));
/*    */     $$delegatedProperties = (KProperty<Object>[])arrayOfKProperty;
/*    */   }
/*    */   
/*    */   @Metadata(mv = {1, 6, 0}, k = 3, xi = 48, d1 = {"\000\b\n\000\n\002\020\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "", "invoke"})
/*    */   static final class KeybindLabel$keybind$1 extends Lambda implements Function0<Unit> {
/*    */     KeybindLabel$keybind$1(Ref.BooleanRef $changing) {
/*    */       super(0);
/*    */     }
/*    */     
/*    */     public final void invoke() {
/*    */       this.$changing.element = !this.$changing.element;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\clickgui\KeybindLabel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */