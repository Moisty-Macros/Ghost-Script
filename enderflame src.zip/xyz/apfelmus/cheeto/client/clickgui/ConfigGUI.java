/*     */ package xyz.apfelmus.cheeto.client.clickgui;
/*     */ import gg.essential.elementa.UIComponent;
/*     */ import gg.essential.elementa.UIConstraints;
/*     */ import gg.essential.elementa.components.UIBlock;
/*     */ import gg.essential.elementa.components.UIContainer;
/*     */ import gg.essential.elementa.constraints.HeightConstraint;
/*     */ import gg.essential.elementa.constraints.WidthConstraint;
/*     */ import gg.essential.elementa.constraints.XConstraint;
/*     */ import gg.essential.elementa.dsl.ComponentsKt;
/*     */ import gg.essential.elementa.dsl.UtilitiesKt;
/*     */ import java.awt.Color;
/*     */ import kotlin.jvm.internal.PropertyReference1;
/*     */ import kotlin.jvm.internal.PropertyReference1Impl;
/*     */ import kotlin.jvm.internal.Reflection;
/*     */ import kotlin.properties.ReadWriteProperty;
/*     */ import kotlin.reflect.KProperty;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ @Metadata(mv = {1, 6, 0}, k = 1, xi = 48, d1 = {"\000X\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\b\n\002\030\002\n\002\b\n\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\020\n\002\030\002\n\002\b\r\n\002\020\013\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\000\n\002\020\016\n\002\b\002\n\002\020\000\n\002\b\002\030\0002\0020\001B\005¢\006\002\020\002J\b\020>\032\0020?H\026J\b\020@\032\0020AH\026J\016\020B\032\0020A2\006\020C\032\0020DJ\016\020E\032\0020A2\006\020\f\032\0020FJ\016\020G\032\0020A2\006\020H\032\0020IJ\b\020J\032\0020AH\026R\033\020\003\032\0020\0048BX\002¢\006\f\n\004\b\007\020\b\032\004\b\005\020\006R\033\020\t\032\0020\0048BX\002¢\006\f\n\004\b\013\020\b\032\004\b\n\020\006R\033\020\f\032\0020\r8BX\002¢\006\f\n\004\b\020\020\b\032\004\b\016\020\017R\033\020\021\032\0020\0048BX\002¢\006\f\n\004\b\023\020\b\032\004\b\022\020\006R\033\020\024\032\0020\r8BX\002¢\006\f\n\004\b\026\020\b\032\004\b\025\020\017R\033\020\027\032\0020\0308BX\002¢\006\f\n\004\b\033\020\b\032\004\b\031\020\032R\033\020\034\032\0020\r8BX\002¢\006\f\n\004\b\036\020\b\032\004\b\035\020\017R\033\020\037\032\0020 8BX\002¢\006\f\n\004\b#\020\b\032\004\b!\020\"R\033\020$\032\0020\r8BX\002¢\006\f\n\004\b&\020\b\032\004\b%\020\017R\033\020'\032\0020\r8BX\002¢\006\f\n\004\b)\020\b\032\004\b(\020\017R\033\020*\032\0020\0308BX\002¢\006\f\n\004\b,\020\b\032\004\b+\020\032R\033\020-\032\0020\0048BX\002¢\006\f\n\004\b/\020\b\032\004\b.\020\006R\033\0200\032\002018BX\002¢\006\f\n\004\b4\020\b\032\004\b2\0203R\033\0205\032\0020\0048BX\002¢\006\f\n\004\b7\020\b\032\004\b6\020\006R\033\0208\032\0020\r8BX\002¢\006\f\n\004\b:\020\b\032\004\b9\020\017R\033\020;\032\0020\0308BX\002¢\006\f\n\004\b=\020\b\032\004\b<\020\032¨\006K"}, d2 = {"Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;", "Lgg/essential/elementa/WindowScreen;", "()V", "bottomContent", "Lgg/essential/elementa/components/UIContainer;", "getBottomContent", "()Lgg/essential/elementa/components/UIContainer;", "bottomContent$delegate", "Lkotlin/properties/ReadWriteProperty;", "categoryContainer", "getCategoryContainer", "categoryContainer$delegate", "config", "Lgg/essential/elementa/components/UIBlock;", "getConfig", "()Lgg/essential/elementa/components/UIBlock;", "config$delegate", "configContainer", "getConfigContainer", "configContainer$delegate", "configScrollBar", "getConfigScrollBar", "configScrollBar$delegate", "configScroller", "Lgg/essential/elementa/components/ScrollComponent;", "getConfigScroller", "()Lgg/essential/elementa/components/ScrollComponent;", "configScroller$delegate", "configSpacer", "getConfigSpacer", "configSpacer$delegate", "configText", "Lgg/essential/elementa/components/UIText;", "getConfigText", "()Lgg/essential/elementa/components/UIText;", "configText$delegate", "content", "getContent", "content$delegate", "moduleScrollBar", "getModuleScrollBar", "moduleScrollBar$delegate", "moduleScroller", "getModuleScroller", "moduleScroller$delegate", "scrollContainer", "getScrollContainer", "scrollContainer$delegate", "searchBar", "Lxyz/apfelmus/cheeto/client/clickgui/settings/TextComponent;", "getSearchBar", "()Lxyz/apfelmus/cheeto/client/clickgui/settings/TextComponent;", "searchBar$delegate", "settingContainer", "getSettingContainer", "settingContainer$delegate", "settingScrollBar", "getSettingScrollBar", "settingScrollBar$delegate", "settingScroller", "getSettingScroller", "settingScroller$delegate", "doesGuiPauseGame", "", "onScreenClose", "", "selectCategory", "category", "Lxyz/apfelmus/cf4m/module/Category;", "selectConfig", "", "selectModule", "module", "", "updateGuiScale", "Cheeto"})
/*     */ public final class ConfigGUI extends WindowScreen {
/*     */   public ConfigGUI() {
/*  22 */     super(elementaVersion, false, false, true, m, 6, null);
/*  23 */     Color color6 = ColorUtils.MENU_BG; Intrinsics.checkNotNullExpressionValue(color6, "MENU_BG"); UIComponent uIComponent6 = (UIComponent)new UIBlock(color6); int k = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 268 */     UIComponent uIComponent10 = uIComponent6, uIComponent11 = uIComponent10; int $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 269 */     UIConstraints uIConstraints1 = uIComponent11.getConstraints(); ConfigGUI configGUI = this; int $i$a$-constrain-ConfigGUI$content$2 = 0; uIConstraints1.setX((XConstraint)new CenterConstraint()); uIConstraints1.setY((YConstraint)new CenterConstraint()); uIConstraints1.setWidth((WidthConstraint)UtilitiesKt.percent(Integer.valueOf(60))); uIConstraints1.setHeight((HeightConstraint)UtilitiesKt.percent(Integer.valueOf(75))); Color color5 = ColorUtils.M_BORDER; Intrinsics.checkNotNullExpressionValue(color5, "M_BORDER"); color5 = ColorUtils.M_BORDER; Intrinsics.checkNotNullExpressionValue(color5, "M_BORDER"); configGUI.content$delegate = ComponentsKt.provideDelegate(ComponentsKt.effect(ComponentsKt.childOf(uIComponent10, (UIComponent)getWindow()), (Effect)(new OutlineEffect(color5, 1.0F, false, false, null, 28, null)).bindColor((State)new BasicState(color5))), this, $$delegatedProperties[0]); color5 = ColorUtils.MENU_BG; Intrinsics.checkNotNullExpressionValue(color5, "MENU_BG"); UIComponent uIComponent5 = (UIComponent)new UIBlock(color5);
/*     */     k = 0;
/* 271 */     uIComponent11 = uIComponent10 = uIComponent5; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 272 */     UIConstraints $this$content_delegate_u24lambda_u2d0 = uIComponent11.getConstraints(); configGUI = this; int $i$a$-constrain-ConfigGUI$config$2 = 0; $this$content_delegate_u24lambda_u2d0.setX((XConstraint)ConstraintsKt.plus((SuperConstraint)new SiblingConstraint(0.0F, false, 3, null), (SuperConstraint)UtilitiesKt.pixels$default(Integer.valueOf(5), false, false, 3, null))); $this$content_delegate_u24lambda_u2d0.setY((YConstraint)new CenterConstraint()); $this$content_delegate_u24lambda_u2d0.setWidth((WidthConstraint)UtilitiesKt.percent(Integer.valueOf(13))); $this$content_delegate_u24lambda_u2d0.setHeight((HeightConstraint)UtilitiesKt.percent(Integer.valueOf(40))); Color color4 = ColorUtils.M_BORDER; Intrinsics.checkNotNullExpressionValue(color4, "M_BORDER"); configGUI.config$delegate = ComponentsKt.provideDelegate(ComponentsKt.effect(ComponentsKt.childOf(uIComponent10, (UIComponent)getWindow()), (Effect)new OutlineEffect(color4, 1.0F, false, false, null, 28, null)), this, $$delegatedProperties[1]); UIComponent uIComponent4 = (UIComponent)new UIText("Configs", false, null, 6, null);
/*     */     k = 0;
/* 274 */     uIComponent11 = uIComponent10 = uIComponent4; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 275 */     UIConstraints $this$config_delegate_u24lambda_u2d1 = uIComponent11.getConstraints(); configGUI = this; int $i$a$-constrain-ConfigGUI$configText$2 = 0; $this$config_delegate_u24lambda_u2d1.setX((XConstraint)new CenterConstraint()); $this$config_delegate_u24lambda_u2d1.setY((YConstraint)UtilitiesKt.pixels$default(Integer.valueOf(10), false, false, 3, null)); $this$config_delegate_u24lambda_u2d1.setTextScale((HeightConstraint)UtilitiesKt.pixels$default(Float.valueOf(1.5F), false, false, 3, null)); configGUI.configText$delegate = ComponentsKt.provideDelegate(ComponentsKt.childOf(uIComponent10, (UIComponent)getConfig()), this, $$delegatedProperties[2]); Color color3 = ColorUtils.M_BORDER; Intrinsics.checkNotNullExpressionValue(color3, "M_BORDER"); UIComponent uIComponent3 = (UIComponent)new UIBlock(color3);
/*     */     k = 0;
/* 277 */     uIComponent11 = uIComponent10 = uIComponent3; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 278 */     UIConstraints $this$configText_delegate_u24lambda_u2d2 = uIComponent11.getConstraints(); configGUI = this; int $i$a$-constrain-ConfigGUI$configSpacer$2 = 0; $this$configText_delegate_u24lambda_u2d2.setX((XConstraint)new CenterConstraint()); $this$configText_delegate_u24lambda_u2d2.setY((YConstraint)new SiblingConstraint(5.0F, false, 2, null)); $this$configText_delegate_u24lambda_u2d2.setWidth((WidthConstraint)ConstraintsKt.minus((SuperConstraint)UtilitiesKt.percent(Integer.valueOf(100)), (SuperConstraint)UtilitiesKt.pixels$default(Integer.valueOf(20), false, false, 3, null))); $this$configText_delegate_u24lambda_u2d2.setHeight((HeightConstraint)UtilitiesKt.pixel$default(Integer.valueOf(1), false, false, 3, null)); configGUI.configSpacer$delegate = ComponentsKt.provideDelegate(ComponentsKt.childOf(uIComponent10, (UIComponent)getConfig()), this, $$delegatedProperties[3]); uIComponent3 = (UIComponent)new UIContainer();
/*     */     k = 0;
/* 280 */     uIComponent11 = uIComponent10 = uIComponent3; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 281 */     UIConstraints $this$configSpacer_delegate_u24lambda_u2d3 = uIComponent11.getConstraints(); configGUI = this; int $i$a$-constrain-ConfigGUI$configContainer$2 = 0; $this$configSpacer_delegate_u24lambda_u2d3.setX((XConstraint)UtilitiesKt.pixels$default(Integer.valueOf(10), false, false, 3, null)); $this$configSpacer_delegate_u24lambda_u2d3.setY((YConstraint)new SiblingConstraint(5.0F, false, 2, null)); $this$configSpacer_delegate_u24lambda_u2d3.setWidth((WidthConstraint)ConstraintsKt.minus((SuperConstraint)new FillConstraint(false), (SuperConstraint)UtilitiesKt.pixels$default(Integer.valueOf(10), false, false, 3, null))); $this$configSpacer_delegate_u24lambda_u2d3.setHeight((HeightConstraint)new FillConstraint(false)); configGUI.configContainer$delegate = ComponentsKt.provideDelegate(ComponentsKt.childOf(uIComponent10, (UIComponent)getConfig()), this, $$delegatedProperties[4]); uIComponent3 = (UIComponent)new ScrollComponent(null, 0.0F, null, false, false, false, false, 25.0F, 0.0F, null, 895, null);
/*     */     k = 0;
/* 283 */     uIComponent11 = uIComponent10 = uIComponent3; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 284 */     UIConstraints $this$configContainer_delegate_u24lambda_u2d4 = uIComponent11.getConstraints(); configGUI = this; int $i$a$-constrain-ConfigGUI$configScroller$2 = 0; $this$configContainer_delegate_u24lambda_u2d4.setWidth((WidthConstraint)UtilitiesKt.percent(Integer.valueOf(100))); $this$configContainer_delegate_u24lambda_u2d4.setHeight((HeightConstraint)UtilitiesKt.percent(Integer.valueOf(100))); configGUI.configScroller$delegate = ComponentsKt.provideDelegate(ComponentsKt.childOf(uIComponent10, (UIComponent)getConfigContainer()), this, $$delegatedProperties[5]); uIComponent3 = (UIComponent)new UIBlock(null, 1, null);
/*     */     k = 0;
/* 286 */     uIComponent11 = uIComponent10 = uIComponent3; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 287 */     UIConstraints $this$configScroller_delegate_u24lambda_u2d5 = uIComponent11.getConstraints(); configGUI = this; int $i$a$-constrain-ConfigGUI$configScrollBar$2 = 0; $this$configScroller_delegate_u24lambda_u2d5.setX((XConstraint)UtilitiesKt.percent(Integer.valueOf(106))); $this$configScroller_delegate_u24lambda_u2d5.setWidth((WidthConstraint)UtilitiesKt.pixels$default(Integer.valueOf(3), false, false, 3, null)); Color color7 = ColorUtils.M_BORDER; Intrinsics.checkNotNullExpressionValue(color7, "M_BORDER"); $this$configScroller_delegate_u24lambda_u2d5.setColor((ColorConstraint)UtilitiesKt.toConstraint(color7)); configGUI.configScrollBar$delegate = ComponentsKt.provideDelegate(ComponentsKt.childOf(uIComponent10, (UIComponent)getConfigContainer()), this, $$delegatedProperties[6]); getConfigScroller().setVerticalScrollBarComponent((UIComponent)getConfigScrollBar(), true); String active = ClientConfig.getActiveConfig(); List list = ClientConfig.getConfigs(); Intrinsics.checkNotNullExpressionValue(list, "getConfigs()"); Iterable $this$forEach$iv = list;
/*     */     int n = 0;
/* 289 */     Iterator iterator = $this$forEach$iv.iterator(); if (iterator.hasNext()) { Object element$iv = iterator.next(); String cfg = (String)element$iv; int $i$a$-forEach-ConfigGUI$1 = 0; Intrinsics.checkNotNullExpressionValue(cfg, "cfg"); ConfigLabel label = (ConfigLabel)ComponentsKt.childOf((UIComponent)new ConfigLabel(this, cfg), (UIComponent)getConfigScroller()); }
/*     */      UIComponent uIComponent2 = (UIComponent)new UIContainer(); int j = 0;
/* 291 */     UIComponent uIComponent9 = uIComponent2; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 292 */     UIConstraints $this$configScrollBar_delegate_u24lambda_u2d6 = uIComponent11.getConstraints(); configGUI = this; int $i$a$-constrain-ConfigGUI$categoryContainer$2 = 0; $this$configScrollBar_delegate_u24lambda_u2d6.setX((XConstraint)new CenterConstraint()); $this$configScrollBar_delegate_u24lambda_u2d6.setY((YConstraint)UtilitiesKt.pixels$default(Integer.valueOf(5), false, false, 3, null)); $this$configScrollBar_delegate_u24lambda_u2d6.setWidth((WidthConstraint)UtilitiesKt.percent(Integer.valueOf(95))); $this$configScrollBar_delegate_u24lambda_u2d6.setHeight((HeightConstraint)UtilitiesKt.percent(Integer.valueOf(12))); configGUI.categoryContainer$delegate = ComponentsKt.provideDelegate(ComponentsKt.childOf(uIComponent9, (UIComponent)getContent()), this, $$delegatedProperties[7]); Category[] arrayOfCategory1 = Category.values();
/*     */     int $i$f$forEach = 0;
/* 294 */     Category[] arrayOfCategory2 = arrayOfCategory1; byte b = 0; int i1 = arrayOfCategory2.length; if (b < i1) { Object element$iv = arrayOfCategory2[b]; b++; Object object1 = element$iv; int $i$a$-forEach-ConfigGUI$2 = 0; ComponentsKt.childOf((UIComponent)new CategoryLabel(this, (Category)object1), (UIComponent)getCategoryContainer()); }
/*     */      Color color2 = ColorUtils.M_BORDER; Intrinsics.checkNotNullExpressionValue(color2, "M_BORDER"); UIComponent uIComponent1 = (UIComponent)new UIBlock(color2); int i = 0;
/* 296 */     UIComponent uIComponent8 = uIComponent1; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 297 */     UIConstraints $this$_init__u24lambda_u2d10 = uIComponent11.getConstraints(); int $i$a$-constrain-ConfigGUI$3 = 0; $this$_init__u24lambda_u2d10.setX((XConstraint)UtilitiesKt.pixels$default(Integer.valueOf(0), false, false, 3, null)); $this$_init__u24lambda_u2d10.setY((YConstraint)new SiblingConstraint(0.0F, false, 3, null)); $this$_init__u24lambda_u2d10.setWidth((WidthConstraint)new FillConstraint(false)); $this$_init__u24lambda_u2d10.setHeight((HeightConstraint)UtilitiesKt.pixel$default(Integer.valueOf(1), false, false, 3, null)); ComponentsKt.childOf(uIComponent8, (UIComponent)getContent()); uIComponent1 = (UIComponent)new UIContainer();
/*     */     i = 0;
/* 299 */     uIComponent11 = uIComponent8 = uIComponent1; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 300 */     UIConstraints $this$categoryContainer_delegate_u24lambda_u2d8 = uIComponent11.getConstraints(); configGUI = this; int $i$a$-constrain-ConfigGUI$bottomContent$2 = 0; $this$categoryContainer_delegate_u24lambda_u2d8.setX((XConstraint)UtilitiesKt.pixels$default(Integer.valueOf(10), false, false, 3, null)); $this$categoryContainer_delegate_u24lambda_u2d8.setY((YConstraint)new SiblingConstraint(10.0F, false, 2, null)); $this$categoryContainer_delegate_u24lambda_u2d8.setWidth((WidthConstraint)ConstraintsKt.minus((SuperConstraint)new FillConstraint(false), (SuperConstraint)UtilitiesKt.pixels$default(Integer.valueOf(10), false, false, 3, null))); $this$categoryContainer_delegate_u24lambda_u2d8.setHeight((HeightConstraint)ConstraintsKt.minus((SuperConstraint)new FillConstraint(false), (SuperConstraint)UtilitiesKt.pixels$default(Integer.valueOf(10), false, false, 3, null))); configGUI.bottomContent$delegate = ComponentsKt.provideDelegate(ComponentsKt.childOf(uIComponent8, (UIComponent)getContent()), this, $$delegatedProperties[8]); uIComponent1 = (UIComponent)new UIContainer();
/*     */     i = 0;
/* 302 */     uIComponent11 = uIComponent8 = uIComponent1; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 303 */     UIConstraints $this$bottomContent_delegate_u24lambda_u2d11 = uIComponent11.getConstraints(); configGUI = this; int $i$a$-constrain-ConfigGUI$scrollContainer$2 = 0; $this$bottomContent_delegate_u24lambda_u2d11.setX((XConstraint)UtilitiesKt.pixels$default(Integer.valueOf(10), false, false, 3, null)); $this$bottomContent_delegate_u24lambda_u2d11.setY((YConstraint)new SiblingConstraint(10.0F, false, 2, null)); $this$bottomContent_delegate_u24lambda_u2d11.setWidth((WidthConstraint)UtilitiesKt.percent(Double.valueOf(27.5D))); $this$bottomContent_delegate_u24lambda_u2d11.setHeight((HeightConstraint)ConstraintsKt.minus((SuperConstraint)new FillConstraint(false), (SuperConstraint)UtilitiesKt.pixels$default(Integer.valueOf(10), false, false, 3, null))); configGUI.scrollContainer$delegate = ComponentsKt.provideDelegate(ComponentsKt.childOf(uIComponent8, (UIComponent)getBottomContent()), this, $$delegatedProperties[9]); uIComponent1 = (UIComponent)new ScrollComponent(null, 0.0F, null, false, false, false, false, 25.0F, 0.0F, null, 895, null);
/*     */     i = 0;
/* 305 */     uIComponent11 = uIComponent8 = uIComponent1; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 306 */     UIConstraints $this$scrollContainer_delegate_u24lambda_u2d12 = uIComponent11.getConstraints(); configGUI = this; int $i$a$-constrain-ConfigGUI$moduleScroller$2 = 0; $this$scrollContainer_delegate_u24lambda_u2d12.setWidth((WidthConstraint)UtilitiesKt.percent(Integer.valueOf(100))); $this$scrollContainer_delegate_u24lambda_u2d12.setHeight((HeightConstraint)UtilitiesKt.percent(Integer.valueOf(100))); configGUI.moduleScroller$delegate = ComponentsKt.provideDelegate(ComponentsKt.childOf(uIComponent8, (UIComponent)getScrollContainer()), this, $$delegatedProperties[10]); uIComponent1 = (UIComponent)new UIBlock(null, 1, null);
/*     */     i = 0;
/* 308 */     uIComponent11 = uIComponent8 = uIComponent1; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 309 */     UIConstraints $this$moduleScroller_delegate_u24lambda_u2d13 = uIComponent11.getConstraints(); configGUI = this; int $i$a$-constrain-ConfigGUI$moduleScrollBar$2 = 0; $this$moduleScroller_delegate_u24lambda_u2d13.setX((XConstraint)UtilitiesKt.pixels$default(Double.valueOf(7.5D), true, false, 2, null)); $this$moduleScroller_delegate_u24lambda_u2d13.setWidth((WidthConstraint)UtilitiesKt.pixels$default(Integer.valueOf(3), false, false, 3, null)); color7 = ColorUtils.M_BORDER; Intrinsics.checkNotNullExpressionValue(color7, "M_BORDER"); $this$moduleScroller_delegate_u24lambda_u2d13.setColor((ColorConstraint)UtilitiesKt.toConstraint(color7)); configGUI.moduleScrollBar$delegate = ComponentsKt.provideDelegate(ComponentsKt.childOf(uIComponent8, (UIComponent)getScrollContainer()), this, $$delegatedProperties[11]); uIComponent1 = (UIComponent)new UIContainer();
/*     */     i = 0;
/* 311 */     uIComponent11 = uIComponent8 = uIComponent1; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 312 */     UIConstraints $this$moduleScrollBar_delegate_u24lambda_u2d14 = uIComponent11.getConstraints(); configGUI = this; int $i$a$-constrain-ConfigGUI$settingContainer$2 = 0; $this$moduleScrollBar_delegate_u24lambda_u2d14.setX((XConstraint)new SiblingConstraint(0.0F, false, 3, null)); $this$moduleScrollBar_delegate_u24lambda_u2d14.setWidth((WidthConstraint)new FillConstraint(false)); $this$moduleScrollBar_delegate_u24lambda_u2d14.setHeight((HeightConstraint)new FillConstraint(false)); Color color1 = ColorUtils.C_BORDER; Intrinsics.checkNotNullExpressionValue(color1, "C_BORDER"); configGUI.settingContainer$delegate = ComponentsKt.provideDelegate(ComponentsKt.effect(ComponentsKt.childOf(uIComponent8, (UIComponent)getBottomContent()), (Effect)new OutlineEffect(color1, 1.0F, false, false, null, 28, null)), this, $$delegatedProperties[12]); UIComponent $this$constrain$iv = (UIComponent)new ScrollComponent(null, 0.0F, null, false, false, false, false, 25.0F, 0.0F, null, 895, null);
/*     */     i = 0;
/* 314 */     uIComponent11 = uIComponent8 = $this$constrain$iv; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 315 */     UIConstraints $this$settingContainer_delegate_u24lambda_u2d15 = uIComponent11.getConstraints(); configGUI = this; int $i$a$-constrain-ConfigGUI$settingScroller$2 = 0; $this$settingContainer_delegate_u24lambda_u2d15.setWidth((WidthConstraint)UtilitiesKt.percent(Integer.valueOf(100))); $this$settingContainer_delegate_u24lambda_u2d15.setHeight((HeightConstraint)UtilitiesKt.percent(Integer.valueOf(100))); configGUI.settingScroller$delegate = ComponentsKt.provideDelegate(ComponentsKt.childOf(uIComponent8, (UIComponent)getSettingContainer()), this, $$delegatedProperties[13]); $this$constrain$iv = (UIComponent)new UIBlock(null, 1, null);
/*     */     i = 0;
/* 317 */     uIComponent11 = uIComponent8 = $this$constrain$iv; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 318 */     UIConstraints $this$settingScroller_delegate_u24lambda_u2d16 = uIComponent11.getConstraints(); configGUI = this; int $i$a$-constrain-ConfigGUI$settingScrollBar$2 = 0; $this$settingScroller_delegate_u24lambda_u2d16.setX((XConstraint)UtilitiesKt.pixels$default(Double.valueOf(2.5D), true, false, 2, null)); $this$settingScroller_delegate_u24lambda_u2d16.setWidth((WidthConstraint)UtilitiesKt.pixels$default(Integer.valueOf(3), false, false, 3, null)); color7 = ColorUtils.M_BORDER; Intrinsics.checkNotNullExpressionValue(color7, "M_BORDER"); $this$settingScroller_delegate_u24lambda_u2d16.setColor((ColorConstraint)UtilitiesKt.toConstraint(color7)); configGUI.settingScrollBar$delegate = ComponentsKt.provideDelegate(ComponentsKt.childOf(uIComponent8, (UIComponent)getSettingContainer()), this, $$delegatedProperties[14]); getModuleScroller().setVerticalScrollBarComponent((UIComponent)getModuleScrollBar(), true); Iterable $this$filterIsInstance$iv = (Iterable)getCategoryContainer().getChildren();
/*     */     int $i$f$filterIsInstance = 0;
/* 320 */     Iterable iterable1 = $this$filterIsInstance$iv; Collection<Object> collection1 = new ArrayList(); int $i$f$filterIsInstanceTo = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 329 */     for (Object element$iv$iv : iterable1) { if (element$iv$iv instanceof CategoryLabel) collection1.add(element$iv$iv);  }
/* 330 */      (CategoryLabel)CollectionsKt.firstOrNull((List)collection1); ((CategoryLabel)CollectionsKt.firstOrNull((List)collection1)).select(); ((CategoryLabel)CollectionsKt.firstOrNull((List)collection1) == null) ? null : Unit.INSTANCE; getSettingScroller().setVerticalScrollBarComponent((UIComponent)getSettingScrollBar(), true); $this$filterIsInstance$iv = getModuleScroller().getAllChildren(); $i$f$filterIsInstance = 0;
/* 331 */     Iterable $this$filterIsInstanceTo$iv$iv = $this$filterIsInstance$iv; Collection<Object> destination$iv$iv = new ArrayList(); $i$f$filterIsInstanceTo = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 340 */     for (Object element$iv$iv : $this$filterIsInstanceTo$iv$iv) { if (element$iv$iv instanceof ModuleLabel) destination$iv$iv.add(element$iv$iv);  }
/* 341 */      (ModuleLabel)CollectionsKt.firstOrNull((List)destination$iv$iv); ((ModuleLabel)CollectionsKt.firstOrNull((List)destination$iv$iv)).select(); ((ModuleLabel)CollectionsKt.firstOrNull((List)destination$iv$iv) == null) ? null : Unit.INSTANCE; $this$constrain$iv = (UIComponent)new TextComponent("", "Search...", false, false); int $i$f$constrain = 0;
/* 342 */     UIComponent uIComponent7 = $this$constrain$iv, $this$constrain_u24lambda_u2d0$iv = uIComponent7; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 343 */     UIConstraints $this$settingScrollBar_delegate_u24lambda_u2d17 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); configGUI = this; int $i$a$-constrain-ConfigGUI$searchBar$2 = 0;
/*     */     $this$settingScrollBar_delegate_u24lambda_u2d17.setX((XConstraint)new CenterConstraint());
/*     */     $this$settingScrollBar_delegate_u24lambda_u2d17.setY((YConstraint)UtilitiesKt.percent(Double.valueOf(7.5D)));
/*     */     configGUI.searchBar$delegate = ComponentsKt.provideDelegate(ComponentsKt.childOf(uIComponent7, (UIComponent)getWindow()), this, $$delegatedProperties[15]);
/*     */     getSearchBar().onValueChange(new Function1<Object, Unit>() {
/*     */           public final void invoke(@Nullable Object it) {
/*     */             // Byte code:
/*     */             //   0: aload_1
/*     */             //   1: dup
/*     */             //   2: ifnonnull -> 16
/*     */             //   5: pop
/*     */             //   6: new java/lang/NullPointerException
/*     */             //   9: dup
/*     */             //   10: ldc 'null cannot be cast to non-null type kotlin.String'
/*     */             //   12: invokespecial <init> : (Ljava/lang/String;)V
/*     */             //   15: athrow
/*     */             //   16: checkcast java/lang/String
/*     */             //   19: ldc ''
/*     */             //   21: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */             //   24: ifeq -> 387
/*     */             //   27: aload_0
/*     */             //   28: getfield this$0 : Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;
/*     */             //   31: invokestatic access$getCategoryContainer : (Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;)Lgg/essential/elementa/components/UIContainer;
/*     */             //   34: invokevirtual clearChildren : ()Lgg/essential/elementa/UIComponent;
/*     */             //   37: pop
/*     */             //   38: invokestatic values : ()[Lxyz/apfelmus/cf4m/module/Category;
/*     */             //   41: astore_2
/*     */             //   42: aload_0
/*     */             //   43: getfield this$0 : Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;
/*     */             //   46: astore_3
/*     */             //   47: iconst_0
/*     */             //   48: istore #4
/*     */             //   50: aload_2
/*     */             //   51: astore #5
/*     */             //   53: iconst_0
/*     */             //   54: istore #6
/*     */             //   56: aload #5
/*     */             //   58: arraylength
/*     */             //   59: istore #7
/*     */             //   61: iload #6
/*     */             //   63: iload #7
/*     */             //   65: if_icmpge -> 113
/*     */             //   68: aload #5
/*     */             //   70: iload #6
/*     */             //   72: aaload
/*     */             //   73: astore #8
/*     */             //   75: iinc #6, 1
/*     */             //   78: aload #8
/*     */             //   80: astore #9
/*     */             //   82: iconst_0
/*     */             //   83: istore #10
/*     */             //   85: new xyz/apfelmus/cheeto/client/clickgui/CategoryLabel
/*     */             //   88: dup
/*     */             //   89: aload_3
/*     */             //   90: aload #9
/*     */             //   92: invokespecial <init> : (Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;Lxyz/apfelmus/cf4m/module/Category;)V
/*     */             //   95: checkcast gg/essential/elementa/UIComponent
/*     */             //   98: aload_3
/*     */             //   99: invokestatic access$getCategoryContainer : (Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;)Lgg/essential/elementa/components/UIContainer;
/*     */             //   102: checkcast gg/essential/elementa/UIComponent
/*     */             //   105: invokestatic childOf : (Lgg/essential/elementa/UIComponent;Lgg/essential/elementa/UIComponent;)Lgg/essential/elementa/UIComponent;
/*     */             //   108: pop
/*     */             //   109: nop
/*     */             //   110: goto -> 61
/*     */             //   113: nop
/*     */             //   114: aload_0
/*     */             //   115: getfield this$0 : Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;
/*     */             //   118: invokestatic access$getCategoryContainer : (Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;)Lgg/essential/elementa/components/UIContainer;
/*     */             //   121: invokevirtual getChildren : ()Lgg/essential/elementa/utils/ObservableList;
/*     */             //   124: checkcast java/lang/Iterable
/*     */             //   127: astore_3
/*     */             //   128: iconst_0
/*     */             //   129: istore #4
/*     */             //   131: aload_3
/*     */             //   132: astore #5
/*     */             //   134: new java/util/ArrayList
/*     */             //   137: dup
/*     */             //   138: invokespecial <init> : ()V
/*     */             //   141: checkcast java/util/Collection
/*     */             //   144: astore #6
/*     */             //   146: iconst_0
/*     */             //   147: istore #7
/*     */             //   149: aload #5
/*     */             //   151: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */             //   156: astore #8
/*     */             //   158: aload #8
/*     */             //   160: invokeinterface hasNext : ()Z
/*     */             //   165: ifeq -> 198
/*     */             //   168: aload #8
/*     */             //   170: invokeinterface next : ()Ljava/lang/Object;
/*     */             //   175: astore #9
/*     */             //   177: aload #9
/*     */             //   179: instanceof xyz/apfelmus/cheeto/client/clickgui/CategoryLabel
/*     */             //   182: ifeq -> 158
/*     */             //   185: aload #6
/*     */             //   187: aload #9
/*     */             //   189: invokeinterface add : (Ljava/lang/Object;)Z
/*     */             //   194: pop
/*     */             //   195: goto -> 158
/*     */             //   198: aload #6
/*     */             //   200: checkcast java/util/List
/*     */             //   203: nop
/*     */             //   204: checkcast java/lang/Iterable
/*     */             //   207: astore_3
/*     */             //   208: nop
/*     */             //   209: iconst_0
/*     */             //   210: istore #4
/*     */             //   212: aload_3
/*     */             //   213: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */             //   218: astore #5
/*     */             //   220: aload #5
/*     */             //   222: invokeinterface hasNext : ()Z
/*     */             //   227: ifeq -> 262
/*     */             //   230: aload #5
/*     */             //   232: invokeinterface next : ()Ljava/lang/Object;
/*     */             //   237: astore #6
/*     */             //   239: aload #6
/*     */             //   241: checkcast xyz/apfelmus/cheeto/client/clickgui/CategoryLabel
/*     */             //   244: astore #7
/*     */             //   246: iconst_0
/*     */             //   247: istore #8
/*     */             //   249: aload #7
/*     */             //   251: invokevirtual isSelected : ()Z
/*     */             //   254: ifeq -> 220
/*     */             //   257: aload #6
/*     */             //   259: goto -> 263
/*     */             //   262: aconst_null
/*     */             //   263: checkcast xyz/apfelmus/cheeto/client/clickgui/CategoryLabel
/*     */             //   266: dup
/*     */             //   267: ifnonnull -> 274
/*     */             //   270: pop
/*     */             //   271: goto -> 277
/*     */             //   274: invokevirtual deselect : ()V
/*     */             //   277: aload_0
/*     */             //   278: getfield this$0 : Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;
/*     */             //   281: invokestatic access$getCategoryContainer : (Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;)Lgg/essential/elementa/components/UIContainer;
/*     */             //   284: invokevirtual getChildren : ()Lgg/essential/elementa/utils/ObservableList;
/*     */             //   287: checkcast java/lang/Iterable
/*     */             //   290: astore_3
/*     */             //   291: iconst_0
/*     */             //   292: istore #4
/*     */             //   294: aload_3
/*     */             //   295: astore #5
/*     */             //   297: new java/util/ArrayList
/*     */             //   300: dup
/*     */             //   301: invokespecial <init> : ()V
/*     */             //   304: checkcast java/util/Collection
/*     */             //   307: astore #6
/*     */             //   309: iconst_0
/*     */             //   310: istore #7
/*     */             //   312: aload #5
/*     */             //   314: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */             //   319: astore #8
/*     */             //   321: aload #8
/*     */             //   323: invokeinterface hasNext : ()Z
/*     */             //   328: ifeq -> 361
/*     */             //   331: aload #8
/*     */             //   333: invokeinterface next : ()Ljava/lang/Object;
/*     */             //   338: astore #9
/*     */             //   340: aload #9
/*     */             //   342: instanceof xyz/apfelmus/cheeto/client/clickgui/CategoryLabel
/*     */             //   345: ifeq -> 321
/*     */             //   348: aload #6
/*     */             //   350: aload #9
/*     */             //   352: invokeinterface add : (Ljava/lang/Object;)Z
/*     */             //   357: pop
/*     */             //   358: goto -> 321
/*     */             //   361: aload #6
/*     */             //   363: checkcast java/util/List
/*     */             //   366: nop
/*     */             //   367: invokestatic firstOrNull : (Ljava/util/List;)Ljava/lang/Object;
/*     */             //   370: checkcast xyz/apfelmus/cheeto/client/clickgui/CategoryLabel
/*     */             //   373: dup
/*     */             //   374: ifnonnull -> 381
/*     */             //   377: pop
/*     */             //   378: goto -> 911
/*     */             //   381: invokevirtual select : ()V
/*     */             //   384: goto -> 911
/*     */             //   387: aload_0
/*     */             //   388: getfield this$0 : Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;
/*     */             //   391: invokestatic access$getCategoryContainer : (Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;)Lgg/essential/elementa/components/UIContainer;
/*     */             //   394: invokevirtual clearChildren : ()Lgg/essential/elementa/UIComponent;
/*     */             //   397: pop
/*     */             //   398: new xyz/apfelmus/cheeto/client/clickgui/CategoryLabel
/*     */             //   401: dup
/*     */             //   402: aload_0
/*     */             //   403: getfield this$0 : Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;
/*     */             //   406: getstatic xyz/apfelmus/cf4m/module/Category.NONE : Lxyz/apfelmus/cf4m/module/Category;
/*     */             //   409: invokespecial <init> : (Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;Lxyz/apfelmus/cf4m/module/Category;)V
/*     */             //   412: checkcast gg/essential/elementa/UIComponent
/*     */             //   415: aload_0
/*     */             //   416: getfield this$0 : Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;
/*     */             //   419: invokestatic access$getCategoryContainer : (Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;)Lgg/essential/elementa/components/UIContainer;
/*     */             //   422: checkcast gg/essential/elementa/UIComponent
/*     */             //   425: invokestatic childOf : (Lgg/essential/elementa/UIComponent;Lgg/essential/elementa/UIComponent;)Lgg/essential/elementa/UIComponent;
/*     */             //   428: checkcast xyz/apfelmus/cheeto/client/clickgui/CategoryLabel
/*     */             //   431: astore_2
/*     */             //   432: aload_2
/*     */             //   433: invokevirtual select : ()V
/*     */             //   436: aload_0
/*     */             //   437: getfield this$0 : Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;
/*     */             //   440: invokestatic access$getModuleScroller : (Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;)Lgg/essential/elementa/components/ScrollComponent;
/*     */             //   443: invokevirtual clearChildren : ()Lgg/essential/elementa/components/ScrollComponent;
/*     */             //   446: pop
/*     */             //   447: getstatic xyz/apfelmus/cf4m/CF4M.INSTANCE : Lxyz/apfelmus/cf4m/CF4M;
/*     */             //   450: getfield moduleManager : Lxyz/apfelmus/cf4m/manager/ModuleManager;
/*     */             //   453: invokevirtual getModules : ()Ljava/util/ArrayList;
/*     */             //   456: astore_3
/*     */             //   457: aload_3
/*     */             //   458: ldc 'INSTANCE.moduleManager.modules'
/*     */             //   460: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */             //   463: aload_3
/*     */             //   464: checkcast java/lang/Iterable
/*     */             //   467: astore_3
/*     */             //   468: aload_0
/*     */             //   469: getfield this$0 : Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;
/*     */             //   472: astore #4
/*     */             //   474: iconst_0
/*     */             //   475: istore #5
/*     */             //   477: aload_3
/*     */             //   478: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */             //   483: astore #6
/*     */             //   485: aload #6
/*     */             //   487: invokeinterface hasNext : ()Z
/*     */             //   492: ifeq -> 623
/*     */             //   495: aload #6
/*     */             //   497: invokeinterface next : ()Ljava/lang/Object;
/*     */             //   502: astore #7
/*     */             //   504: aload #7
/*     */             //   506: astore #8
/*     */             //   508: iconst_0
/*     */             //   509: istore #9
/*     */             //   511: getstatic xyz/apfelmus/cf4m/CF4M.INSTANCE : Lxyz/apfelmus/cf4m/CF4M;
/*     */             //   514: getfield moduleManager : Lxyz/apfelmus/cf4m/manager/ModuleManager;
/*     */             //   517: aload #8
/*     */             //   519: invokevirtual getName : (Ljava/lang/Object;)Ljava/lang/String;
/*     */             //   522: astore #10
/*     */             //   524: aload #10
/*     */             //   526: ldc 'INSTANCE.moduleManager.getName(mod)'
/*     */             //   528: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */             //   531: aload #10
/*     */             //   533: getstatic java/util/Locale.ROOT : Ljava/util/Locale;
/*     */             //   536: invokevirtual toLowerCase : (Ljava/util/Locale;)Ljava/lang/String;
/*     */             //   539: astore #11
/*     */             //   541: aload #11
/*     */             //   543: ldc 'this as java.lang.String).toLowerCase(Locale.ROOT)'
/*     */             //   545: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */             //   548: aload #11
/*     */             //   550: checkcast java/lang/CharSequence
/*     */             //   553: aload_1
/*     */             //   554: checkcast java/lang/String
/*     */             //   557: getstatic java/util/Locale.ROOT : Ljava/util/Locale;
/*     */             //   560: invokevirtual toLowerCase : (Ljava/util/Locale;)Ljava/lang/String;
/*     */             //   563: astore #11
/*     */             //   565: aload #11
/*     */             //   567: ldc 'this as java.lang.String).toLowerCase(Locale.ROOT)'
/*     */             //   569: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */             //   572: aload #11
/*     */             //   574: checkcast java/lang/CharSequence
/*     */             //   577: iconst_0
/*     */             //   578: iconst_2
/*     */             //   579: aconst_null
/*     */             //   580: invokestatic contains$default : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z
/*     */             //   583: ifeq -> 619
/*     */             //   586: new xyz/apfelmus/cheeto/client/clickgui/ModuleLabel
/*     */             //   589: dup
/*     */             //   590: aload #4
/*     */             //   592: aload #8
/*     */             //   594: ldc 'mod'
/*     */             //   596: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */             //   599: aload #8
/*     */             //   601: invokespecial <init> : (Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;Ljava/lang/Object;)V
/*     */             //   604: checkcast gg/essential/elementa/UIComponent
/*     */             //   607: aload #4
/*     */             //   609: invokestatic access$getModuleScroller : (Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;)Lgg/essential/elementa/components/ScrollComponent;
/*     */             //   612: checkcast gg/essential/elementa/UIComponent
/*     */             //   615: invokestatic childOf : (Lgg/essential/elementa/UIComponent;Lgg/essential/elementa/UIComponent;)Lgg/essential/elementa/UIComponent;
/*     */             //   618: pop
/*     */             //   619: nop
/*     */             //   620: goto -> 485
/*     */             //   623: nop
/*     */             //   624: aload_0
/*     */             //   625: getfield this$0 : Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;
/*     */             //   628: invokestatic access$getSettingScroller : (Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;)Lgg/essential/elementa/components/ScrollComponent;
/*     */             //   631: invokevirtual clearChildren : ()Lgg/essential/elementa/components/ScrollComponent;
/*     */             //   634: pop
/*     */             //   635: aload_0
/*     */             //   636: getfield this$0 : Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;
/*     */             //   639: invokestatic access$getModuleScroller : (Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;)Lgg/essential/elementa/components/ScrollComponent;
/*     */             //   642: invokevirtual getAllChildren : ()Ljava/util/concurrent/CopyOnWriteArrayList;
/*     */             //   645: checkcast java/lang/Iterable
/*     */             //   648: astore #4
/*     */             //   650: iconst_0
/*     */             //   651: istore #5
/*     */             //   653: aload #4
/*     */             //   655: astore #6
/*     */             //   657: new java/util/ArrayList
/*     */             //   660: dup
/*     */             //   661: invokespecial <init> : ()V
/*     */             //   664: checkcast java/util/Collection
/*     */             //   667: astore #7
/*     */             //   669: iconst_0
/*     */             //   670: istore #8
/*     */             //   672: aload #6
/*     */             //   674: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */             //   679: astore #9
/*     */             //   681: aload #9
/*     */             //   683: invokeinterface hasNext : ()Z
/*     */             //   688: ifeq -> 721
/*     */             //   691: aload #9
/*     */             //   693: invokeinterface next : ()Ljava/lang/Object;
/*     */             //   698: astore #10
/*     */             //   700: aload #10
/*     */             //   702: instanceof xyz/apfelmus/cheeto/client/clickgui/ModuleLabel
/*     */             //   705: ifeq -> 681
/*     */             //   708: aload #7
/*     */             //   710: aload #10
/*     */             //   712: invokeinterface add : (Ljava/lang/Object;)Z
/*     */             //   717: pop
/*     */             //   718: goto -> 681
/*     */             //   721: aload #7
/*     */             //   723: checkcast java/util/List
/*     */             //   726: nop
/*     */             //   727: checkcast java/lang/Iterable
/*     */             //   730: astore #4
/*     */             //   732: nop
/*     */             //   733: iconst_0
/*     */             //   734: istore #5
/*     */             //   736: aload #4
/*     */             //   738: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */             //   743: astore #6
/*     */             //   745: aload #6
/*     */             //   747: invokeinterface hasNext : ()Z
/*     */             //   752: ifeq -> 787
/*     */             //   755: aload #6
/*     */             //   757: invokeinterface next : ()Ljava/lang/Object;
/*     */             //   762: astore #7
/*     */             //   764: aload #7
/*     */             //   766: checkcast xyz/apfelmus/cheeto/client/clickgui/ModuleLabel
/*     */             //   769: astore #8
/*     */             //   771: iconst_0
/*     */             //   772: istore #9
/*     */             //   774: aload #8
/*     */             //   776: invokevirtual isSelected : ()Z
/*     */             //   779: ifeq -> 745
/*     */             //   782: aload #7
/*     */             //   784: goto -> 788
/*     */             //   787: aconst_null
/*     */             //   788: checkcast xyz/apfelmus/cheeto/client/clickgui/ModuleLabel
/*     */             //   791: dup
/*     */             //   792: ifnonnull -> 799
/*     */             //   795: pop
/*     */             //   796: goto -> 802
/*     */             //   799: invokevirtual deselect : ()V
/*     */             //   802: aload_0
/*     */             //   803: getfield this$0 : Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;
/*     */             //   806: invokestatic access$getModuleScroller : (Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;)Lgg/essential/elementa/components/ScrollComponent;
/*     */             //   809: invokevirtual getAllChildren : ()Ljava/util/concurrent/CopyOnWriteArrayList;
/*     */             //   812: checkcast java/lang/Iterable
/*     */             //   815: astore #4
/*     */             //   817: iconst_0
/*     */             //   818: istore #5
/*     */             //   820: aload #4
/*     */             //   822: astore #6
/*     */             //   824: new java/util/ArrayList
/*     */             //   827: dup
/*     */             //   828: invokespecial <init> : ()V
/*     */             //   831: checkcast java/util/Collection
/*     */             //   834: astore #7
/*     */             //   836: iconst_0
/*     */             //   837: istore #8
/*     */             //   839: aload #6
/*     */             //   841: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */             //   846: astore #9
/*     */             //   848: aload #9
/*     */             //   850: invokeinterface hasNext : ()Z
/*     */             //   855: ifeq -> 888
/*     */             //   858: aload #9
/*     */             //   860: invokeinterface next : ()Ljava/lang/Object;
/*     */             //   865: astore #10
/*     */             //   867: aload #10
/*     */             //   869: instanceof xyz/apfelmus/cheeto/client/clickgui/ModuleLabel
/*     */             //   872: ifeq -> 848
/*     */             //   875: aload #7
/*     */             //   877: aload #10
/*     */             //   879: invokeinterface add : (Ljava/lang/Object;)Z
/*     */             //   884: pop
/*     */             //   885: goto -> 848
/*     */             //   888: aload #7
/*     */             //   890: checkcast java/util/List
/*     */             //   893: nop
/*     */             //   894: invokestatic firstOrNull : (Ljava/util/List;)Ljava/lang/Object;
/*     */             //   897: checkcast xyz/apfelmus/cheeto/client/clickgui/ModuleLabel
/*     */             //   900: dup
/*     */             //   901: ifnonnull -> 908
/*     */             //   904: pop
/*     */             //   905: goto -> 911
/*     */             //   908: invokevirtual select : ()V
/*     */             //   911: return
/*     */             // Line number table:
/*     */             //   Java source line number -> byte code offset
/*     */             //   #158	-> 0
/*     */             //   #159	-> 27
/*     */             //   #160	-> 38
/*     */             //   #268	-> 50
/*     */             //   #161	-> 85
/*     */             //   #162	-> 109
/*     */             //   #269	-> 113
/*     */             //   #163	-> 114
/*     */             //   #270	-> 131
/*     */             //   #279	-> 149
/*     */             //   #280	-> 198
/*     */             //   #270	-> 203
/*     */             //   #163	-> 208
/*     */             //   #281	-> 212
/*     */             //   #163	-> 249
/*     */             //   #282	-> 262
/*     */             //   #163	-> 263
/*     */             //   #164	-> 277
/*     */             //   #283	-> 294
/*     */             //   #292	-> 312
/*     */             //   #293	-> 361
/*     */             //   #283	-> 366
/*     */             //   #164	-> 367
/*     */             //   #166	-> 387
/*     */             //   #167	-> 398
/*     */             //   #168	-> 432
/*     */             //   #169	-> 436
/*     */             //   #170	-> 447
/*     */             //   #294	-> 477
/*     */             //   #171	-> 511
/*     */             //   #171	-> 550
/*     */             //   #171	-> 574
/*     */             //   #172	-> 586
/*     */             //   #174	-> 619
/*     */             //   #295	-> 623
/*     */             //   #175	-> 624
/*     */             //   #176	-> 635
/*     */             //   #296	-> 653
/*     */             //   #305	-> 672
/*     */             //   #306	-> 721
/*     */             //   #296	-> 726
/*     */             //   #176	-> 732
/*     */             //   #307	-> 736
/*     */             //   #176	-> 774
/*     */             //   #308	-> 787
/*     */             //   #176	-> 788
/*     */             //   #177	-> 802
/*     */             //   #309	-> 820
/*     */             //   #318	-> 839
/*     */             //   #319	-> 888
/*     */             //   #309	-> 893
/*     */             //   #177	-> 894
/*     */             //   #213	-> 911
/*     */             // Local variable table:
/*     */             //   start	length	slot	name	descriptor
/*     */             //   85	25	10	$i$a$-forEach-ConfigGUI$4$1	I
/*     */             //   82	28	9	category	Lxyz/apfelmus/cf4m/module/Category;
/*     */             //   75	38	8	element$iv	Ljava/lang/Object;
/*     */             //   50	64	4	$i$f$forEach	I
/*     */             //   47	67	2	$this$forEach$iv	[Ljava/lang/Object;
/*     */             //   177	18	9	element$iv$iv	Ljava/lang/Object;
/*     */             //   149	51	7	$i$f$filterIsInstanceTo	I
/*     */             //   146	54	5	$this$filterIsInstanceTo$iv$iv	Ljava/lang/Iterable;
/*     */             //   146	54	6	destination$iv$iv	Ljava/util/Collection;
/*     */             //   131	73	4	$i$f$filterIsInstance	I
/*     */             //   128	76	3	$this$filterIsInstance$iv	Ljava/lang/Iterable;
/*     */             //   249	5	8	$i$a$-firstOrNull-ConfigGUI$4$2	I
/*     */             //   246	8	7	it	Lxyz/apfelmus/cheeto/client/clickgui/CategoryLabel;
/*     */             //   239	23	6	element$iv	Ljava/lang/Object;
/*     */             //   212	51	4	$i$f$firstOrNull	I
/*     */             //   209	54	3	$this$firstOrNull$iv	Ljava/lang/Iterable;
/*     */             //   340	18	9	element$iv$iv	Ljava/lang/Object;
/*     */             //   312	51	7	$i$f$filterIsInstanceTo	I
/*     */             //   309	54	5	$this$filterIsInstanceTo$iv$iv	Ljava/lang/Iterable;
/*     */             //   309	54	6	destination$iv$iv	Ljava/util/Collection;
/*     */             //   294	73	4	$i$f$filterIsInstance	I
/*     */             //   291	76	3	$this$filterIsInstance$iv	Ljava/lang/Iterable;
/*     */             //   511	109	9	$i$a$-forEach-ConfigGUI$4$3	I
/*     */             //   508	112	8	mod	Ljava/lang/Object;
/*     */             //   504	116	7	element$iv	Ljava/lang/Object;
/*     */             //   477	147	5	$i$f$forEach	I
/*     */             //   474	150	3	$this$forEach$iv	Ljava/lang/Iterable;
/*     */             //   700	18	10	element$iv$iv	Ljava/lang/Object;
/*     */             //   672	51	8	$i$f$filterIsInstanceTo	I
/*     */             //   669	54	6	$this$filterIsInstanceTo$iv$iv	Ljava/lang/Iterable;
/*     */             //   669	54	7	destination$iv$iv	Ljava/util/Collection;
/*     */             //   653	74	5	$i$f$filterIsInstance	I
/*     */             //   650	77	4	$this$filterIsInstance$iv	Ljava/lang/Iterable;
/*     */             //   774	5	9	$i$a$-firstOrNull-ConfigGUI$4$4	I
/*     */             //   771	8	8	it	Lxyz/apfelmus/cheeto/client/clickgui/ModuleLabel;
/*     */             //   764	23	7	element$iv	Ljava/lang/Object;
/*     */             //   736	52	5	$i$f$firstOrNull	I
/*     */             //   733	55	4	$this$firstOrNull$iv	Ljava/lang/Iterable;
/*     */             //   867	18	10	element$iv$iv	Ljava/lang/Object;
/*     */             //   839	51	8	$i$f$filterIsInstanceTo	I
/*     */             //   836	54	6	$this$filterIsInstanceTo$iv$iv	Ljava/lang/Iterable;
/*     */             //   836	54	7	destination$iv$iv	Ljava/util/Collection;
/*     */             //   820	74	5	$i$f$filterIsInstance	I
/*     */             //   817	77	4	$this$filterIsInstance$iv	Ljava/lang/Iterable;
/*     */             //   432	479	2	cat	Lxyz/apfelmus/cheeto/client/clickgui/CategoryLabel;
/*     */             //   0	912	0	this	Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI$4;
/*     */             //   0	912	1	it	Ljava/lang/Object;
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   private final ReadWriteProperty content$delegate;
/*     */   @NotNull
/*     */   private final ReadWriteProperty config$delegate;
/*     */   @NotNull
/*     */   private final ReadWriteProperty configText$delegate;
/*     */   @NotNull
/*     */   private final ReadWriteProperty configSpacer$delegate;
/*     */   @NotNull
/*     */   private final ReadWriteProperty configContainer$delegate;
/*     */   @NotNull
/*     */   private final ReadWriteProperty configScroller$delegate;
/*     */   @NotNull
/*     */   private final ReadWriteProperty configScrollBar$delegate;
/*     */   @NotNull
/*     */   private final ReadWriteProperty categoryContainer$delegate;
/*     */   @NotNull
/*     */   private final ReadWriteProperty bottomContent$delegate;
/*     */   @NotNull
/*     */   private final ReadWriteProperty scrollContainer$delegate;
/*     */   @NotNull
/*     */   private final ReadWriteProperty moduleScroller$delegate;
/*     */   @NotNull
/*     */   private final ReadWriteProperty moduleScrollBar$delegate;
/*     */   @NotNull
/*     */   private final ReadWriteProperty settingContainer$delegate;
/*     */   @NotNull
/*     */   private final ReadWriteProperty settingScroller$delegate;
/*     */   @NotNull
/*     */   private final ReadWriteProperty settingScrollBar$delegate;
/*     */   @NotNull
/*     */   private final ReadWriteProperty searchBar$delegate;
/*     */   
/*     */   private final UIBlock getContent() {
/*     */     return (UIBlock)this.content$delegate.getValue(this, $$delegatedProperties[0]);
/*     */   }
/*     */   
/*     */   static {
/*     */     KProperty[] arrayOfKProperty = new KProperty[16];
/*     */     arrayOfKProperty[0] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(ConfigGUI.class, "content", "getContent()Lgg/essential/elementa/components/UIBlock;", 0));
/*     */     arrayOfKProperty[1] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(ConfigGUI.class, "config", "getConfig()Lgg/essential/elementa/components/UIBlock;", 0));
/*     */     arrayOfKProperty[2] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(ConfigGUI.class, "configText", "getConfigText()Lgg/essential/elementa/components/UIText;", 0));
/*     */     arrayOfKProperty[3] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(ConfigGUI.class, "configSpacer", "getConfigSpacer()Lgg/essential/elementa/components/UIBlock;", 0));
/*     */     arrayOfKProperty[4] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(ConfigGUI.class, "configContainer", "getConfigContainer()Lgg/essential/elementa/components/UIContainer;", 0));
/*     */     arrayOfKProperty[5] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(ConfigGUI.class, "configScroller", "getConfigScroller()Lgg/essential/elementa/components/ScrollComponent;", 0));
/*     */     arrayOfKProperty[6] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(ConfigGUI.class, "configScrollBar", "getConfigScrollBar()Lgg/essential/elementa/components/UIBlock;", 0));
/*     */     arrayOfKProperty[7] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(ConfigGUI.class, "categoryContainer", "getCategoryContainer()Lgg/essential/elementa/components/UIContainer;", 0));
/*     */     arrayOfKProperty[8] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(ConfigGUI.class, "bottomContent", "getBottomContent()Lgg/essential/elementa/components/UIContainer;", 0));
/*     */     arrayOfKProperty[9] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(ConfigGUI.class, "scrollContainer", "getScrollContainer()Lgg/essential/elementa/components/UIContainer;", 0));
/*     */     arrayOfKProperty[10] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(ConfigGUI.class, "moduleScroller", "getModuleScroller()Lgg/essential/elementa/components/ScrollComponent;", 0));
/*     */     arrayOfKProperty[11] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(ConfigGUI.class, "moduleScrollBar", "getModuleScrollBar()Lgg/essential/elementa/components/UIBlock;", 0));
/*     */     arrayOfKProperty[12] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(ConfigGUI.class, "settingContainer", "getSettingContainer()Lgg/essential/elementa/components/UIContainer;", 0));
/*     */     arrayOfKProperty[13] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(ConfigGUI.class, "settingScroller", "getSettingScroller()Lgg/essential/elementa/components/ScrollComponent;", 0));
/*     */     arrayOfKProperty[14] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(ConfigGUI.class, "settingScrollBar", "getSettingScrollBar()Lgg/essential/elementa/components/UIBlock;", 0));
/*     */     arrayOfKProperty[15] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(ConfigGUI.class, "searchBar", "getSearchBar()Lxyz/apfelmus/cheeto/client/clickgui/settings/TextComponent;", 0));
/*     */     $$delegatedProperties = (KProperty<Object>[])arrayOfKProperty;
/*     */   }
/*     */   
/*     */   private final UIBlock getConfig() {
/*     */     return (UIBlock)this.config$delegate.getValue(this, $$delegatedProperties[1]);
/*     */   }
/*     */   
/*     */   private final UIText getConfigText() {
/*     */     return (UIText)this.configText$delegate.getValue(this, $$delegatedProperties[2]);
/*     */   }
/*     */   
/*     */   private final UIBlock getConfigSpacer() {
/*     */     return (UIBlock)this.configSpacer$delegate.getValue(this, $$delegatedProperties[3]);
/*     */   }
/*     */   
/*     */   private final UIContainer getConfigContainer() {
/*     */     return (UIContainer)this.configContainer$delegate.getValue(this, $$delegatedProperties[4]);
/*     */   }
/*     */   
/*     */   private final ScrollComponent getConfigScroller() {
/*     */     return (ScrollComponent)this.configScroller$delegate.getValue(this, $$delegatedProperties[5]);
/*     */   }
/*     */   
/*     */   private final UIBlock getConfigScrollBar() {
/*     */     return (UIBlock)this.configScrollBar$delegate.getValue(this, $$delegatedProperties[6]);
/*     */   }
/*     */   
/*     */   private final UIContainer getCategoryContainer() {
/*     */     return (UIContainer)this.categoryContainer$delegate.getValue(this, $$delegatedProperties[7]);
/*     */   }
/*     */   
/*     */   private final UIContainer getBottomContent() {
/*     */     return (UIContainer)this.bottomContent$delegate.getValue(this, $$delegatedProperties[8]);
/*     */   }
/*     */   
/*     */   private final UIContainer getScrollContainer() {
/*     */     return (UIContainer)this.scrollContainer$delegate.getValue(this, $$delegatedProperties[9]);
/*     */   }
/*     */   
/*     */   private final ScrollComponent getModuleScroller() {
/*     */     return (ScrollComponent)this.moduleScroller$delegate.getValue(this, $$delegatedProperties[10]);
/*     */   }
/*     */   
/*     */   private final UIBlock getModuleScrollBar() {
/*     */     return (UIBlock)this.moduleScrollBar$delegate.getValue(this, $$delegatedProperties[11]);
/*     */   }
/*     */   
/*     */   private final UIContainer getSettingContainer() {
/*     */     return (UIContainer)this.settingContainer$delegate.getValue(this, $$delegatedProperties[12]);
/*     */   }
/*     */   
/*     */   private final ScrollComponent getSettingScroller() {
/*     */     return (ScrollComponent)this.settingScroller$delegate.getValue(this, $$delegatedProperties[13]);
/*     */   }
/*     */   
/*     */   private final UIBlock getSettingScrollBar() {
/*     */     return (UIBlock)this.settingScrollBar$delegate.getValue(this, $$delegatedProperties[14]);
/*     */   }
/*     */   
/*     */   private final TextComponent getSearchBar() {
/*     */     return (TextComponent)this.searchBar$delegate.getValue(this, $$delegatedProperties[15]);
/*     */   }
/*     */   
/*     */   public final void selectCategory(@NotNull Category category) {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: ldc_w 'category'
/*     */     //   4: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   7: aload_0
/*     */     //   8: invokespecial getModuleScroller : ()Lgg/essential/elementa/components/ScrollComponent;
/*     */     //   11: invokevirtual clearChildren : ()Lgg/essential/elementa/components/ScrollComponent;
/*     */     //   14: pop
/*     */     //   15: getstatic xyz/apfelmus/cf4m/CF4M.INSTANCE : Lxyz/apfelmus/cf4m/CF4M;
/*     */     //   18: getfield moduleManager : Lxyz/apfelmus/cf4m/manager/ModuleManager;
/*     */     //   21: aload_1
/*     */     //   22: invokevirtual getModules : (Lxyz/apfelmus/cf4m/module/Category;)Ljava/util/ArrayList;
/*     */     //   25: astore_2
/*     */     //   26: aload_2
/*     */     //   27: ldc_w 'INSTANCE.moduleManager.getModules(category)'
/*     */     //   30: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   33: aload_2
/*     */     //   34: checkcast java/lang/Iterable
/*     */     //   37: astore_2
/*     */     //   38: iconst_0
/*     */     //   39: istore_3
/*     */     //   40: aload_2
/*     */     //   41: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   46: astore #4
/*     */     //   48: aload #4
/*     */     //   50: invokeinterface hasNext : ()Z
/*     */     //   55: ifeq -> 110
/*     */     //   58: aload #4
/*     */     //   60: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   65: astore #5
/*     */     //   67: aload #5
/*     */     //   69: astore #6
/*     */     //   71: iconst_0
/*     */     //   72: istore #7
/*     */     //   74: new xyz/apfelmus/cheeto/client/clickgui/ModuleLabel
/*     */     //   77: dup
/*     */     //   78: aload_0
/*     */     //   79: aload #6
/*     */     //   81: ldc_w 'module'
/*     */     //   84: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   87: aload #6
/*     */     //   89: invokespecial <init> : (Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;Ljava/lang/Object;)V
/*     */     //   92: checkcast gg/essential/elementa/UIComponent
/*     */     //   95: aload_0
/*     */     //   96: invokespecial getModuleScroller : ()Lgg/essential/elementa/components/ScrollComponent;
/*     */     //   99: checkcast gg/essential/elementa/UIComponent
/*     */     //   102: invokestatic childOf : (Lgg/essential/elementa/UIComponent;Lgg/essential/elementa/UIComponent;)Lgg/essential/elementa/UIComponent;
/*     */     //   105: pop
/*     */     //   106: nop
/*     */     //   107: goto -> 48
/*     */     //   110: nop
/*     */     //   111: aload_0
/*     */     //   112: invokespecial getModuleScroller : ()Lgg/essential/elementa/components/ScrollComponent;
/*     */     //   115: invokevirtual getAllChildren : ()Ljava/util/concurrent/CopyOnWriteArrayList;
/*     */     //   118: checkcast java/lang/Iterable
/*     */     //   121: astore_2
/*     */     //   122: iconst_0
/*     */     //   123: istore_3
/*     */     //   124: aload_2
/*     */     //   125: astore #4
/*     */     //   127: new java/util/ArrayList
/*     */     //   130: dup
/*     */     //   131: invokespecial <init> : ()V
/*     */     //   134: checkcast java/util/Collection
/*     */     //   137: astore #5
/*     */     //   139: iconst_0
/*     */     //   140: istore #6
/*     */     //   142: aload #4
/*     */     //   144: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   149: astore #7
/*     */     //   151: aload #7
/*     */     //   153: invokeinterface hasNext : ()Z
/*     */     //   158: ifeq -> 191
/*     */     //   161: aload #7
/*     */     //   163: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   168: astore #8
/*     */     //   170: aload #8
/*     */     //   172: instanceof xyz/apfelmus/cheeto/client/clickgui/ModuleLabel
/*     */     //   175: ifeq -> 151
/*     */     //   178: aload #5
/*     */     //   180: aload #8
/*     */     //   182: invokeinterface add : (Ljava/lang/Object;)Z
/*     */     //   187: pop
/*     */     //   188: goto -> 151
/*     */     //   191: aload #5
/*     */     //   193: checkcast java/util/List
/*     */     //   196: nop
/*     */     //   197: checkcast java/util/Collection
/*     */     //   200: invokeinterface isEmpty : ()Z
/*     */     //   205: ifne -> 212
/*     */     //   208: iconst_1
/*     */     //   209: goto -> 213
/*     */     //   212: iconst_0
/*     */     //   213: ifeq -> 314
/*     */     //   216: aload_0
/*     */     //   217: invokespecial getModuleScroller : ()Lgg/essential/elementa/components/ScrollComponent;
/*     */     //   220: invokevirtual getAllChildren : ()Ljava/util/concurrent/CopyOnWriteArrayList;
/*     */     //   223: checkcast java/lang/Iterable
/*     */     //   226: astore_2
/*     */     //   227: iconst_0
/*     */     //   228: istore_3
/*     */     //   229: aload_2
/*     */     //   230: astore #4
/*     */     //   232: new java/util/ArrayList
/*     */     //   235: dup
/*     */     //   236: invokespecial <init> : ()V
/*     */     //   239: checkcast java/util/Collection
/*     */     //   242: astore #5
/*     */     //   244: iconst_0
/*     */     //   245: istore #6
/*     */     //   247: aload #4
/*     */     //   249: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   254: astore #7
/*     */     //   256: aload #7
/*     */     //   258: invokeinterface hasNext : ()Z
/*     */     //   263: ifeq -> 296
/*     */     //   266: aload #7
/*     */     //   268: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   273: astore #8
/*     */     //   275: aload #8
/*     */     //   277: instanceof xyz/apfelmus/cheeto/client/clickgui/ModuleLabel
/*     */     //   280: ifeq -> 256
/*     */     //   283: aload #5
/*     */     //   285: aload #8
/*     */     //   287: invokeinterface add : (Ljava/lang/Object;)Z
/*     */     //   292: pop
/*     */     //   293: goto -> 256
/*     */     //   296: aload #5
/*     */     //   298: checkcast java/util/List
/*     */     //   301: nop
/*     */     //   302: invokestatic first : (Ljava/util/List;)Ljava/lang/Object;
/*     */     //   305: checkcast xyz/apfelmus/cheeto/client/clickgui/ModuleLabel
/*     */     //   308: invokevirtual select : ()V
/*     */     //   311: goto -> 322
/*     */     //   314: aload_0
/*     */     //   315: invokespecial getSettingScroller : ()Lgg/essential/elementa/components/ScrollComponent;
/*     */     //   318: invokevirtual clearChildren : ()Lgg/essential/elementa/components/ScrollComponent;
/*     */     //   321: pop
/*     */     //   322: aload_0
/*     */     //   323: invokespecial getCategoryContainer : ()Lgg/essential/elementa/components/UIContainer;
/*     */     //   326: invokevirtual getChildren : ()Lgg/essential/elementa/utils/ObservableList;
/*     */     //   329: checkcast java/lang/Iterable
/*     */     //   332: astore_3
/*     */     //   333: iconst_0
/*     */     //   334: istore #4
/*     */     //   336: aload_3
/*     */     //   337: astore #5
/*     */     //   339: new java/util/ArrayList
/*     */     //   342: dup
/*     */     //   343: invokespecial <init> : ()V
/*     */     //   346: checkcast java/util/Collection
/*     */     //   349: astore #6
/*     */     //   351: iconst_0
/*     */     //   352: istore #7
/*     */     //   354: aload #5
/*     */     //   356: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   361: astore #8
/*     */     //   363: aload #8
/*     */     //   365: invokeinterface hasNext : ()Z
/*     */     //   370: ifeq -> 403
/*     */     //   373: aload #8
/*     */     //   375: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   380: astore #9
/*     */     //   382: aload #9
/*     */     //   384: instanceof xyz/apfelmus/cheeto/client/clickgui/CategoryLabel
/*     */     //   387: ifeq -> 363
/*     */     //   390: aload #6
/*     */     //   392: aload #9
/*     */     //   394: invokeinterface add : (Ljava/lang/Object;)Z
/*     */     //   399: pop
/*     */     //   400: goto -> 363
/*     */     //   403: aload #6
/*     */     //   405: checkcast java/util/List
/*     */     //   408: nop
/*     */     //   409: checkcast java/lang/Iterable
/*     */     //   412: astore_3
/*     */     //   413: nop
/*     */     //   414: iconst_0
/*     */     //   415: istore #4
/*     */     //   417: aload_3
/*     */     //   418: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   423: astore #5
/*     */     //   425: aload #5
/*     */     //   427: invokeinterface hasNext : ()Z
/*     */     //   432: ifeq -> 467
/*     */     //   435: aload #5
/*     */     //   437: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   442: astore #6
/*     */     //   444: aload #6
/*     */     //   446: checkcast xyz/apfelmus/cheeto/client/clickgui/CategoryLabel
/*     */     //   449: astore #7
/*     */     //   451: iconst_0
/*     */     //   452: istore #8
/*     */     //   454: aload #7
/*     */     //   456: invokevirtual isSelected : ()Z
/*     */     //   459: ifeq -> 425
/*     */     //   462: aload #6
/*     */     //   464: goto -> 468
/*     */     //   467: aconst_null
/*     */     //   468: checkcast xyz/apfelmus/cheeto/client/clickgui/CategoryLabel
/*     */     //   471: dup
/*     */     //   472: ifnonnull -> 479
/*     */     //   475: pop
/*     */     //   476: goto -> 482
/*     */     //   479: invokevirtual deselect : ()V
/*     */     //   482: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #217	-> 7
/*     */     //   #219	-> 15
/*     */     //   #345	-> 40
/*     */     //   #220	-> 74
/*     */     //   #221	-> 106
/*     */     //   #346	-> 110
/*     */     //   #223	-> 111
/*     */     //   #347	-> 124
/*     */     //   #356	-> 142
/*     */     //   #357	-> 191
/*     */     //   #347	-> 196
/*     */     //   #223	-> 197
/*     */     //   #223	-> 213
/*     */     //   #224	-> 216
/*     */     //   #358	-> 229
/*     */     //   #367	-> 247
/*     */     //   #368	-> 296
/*     */     //   #358	-> 301
/*     */     //   #224	-> 302
/*     */     //   #226	-> 314
/*     */     //   #229	-> 322
/*     */     //   #369	-> 336
/*     */     //   #378	-> 354
/*     */     //   #379	-> 403
/*     */     //   #369	-> 408
/*     */     //   #229	-> 413
/*     */     //   #380	-> 417
/*     */     //   #229	-> 454
/*     */     //   #381	-> 467
/*     */     //   #229	-> 468
/*     */     //   #230	-> 482
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   74	33	7	$i$a$-forEach-ConfigGUI$selectCategory$1	I
/*     */     //   71	36	6	module	Ljava/lang/Object;
/*     */     //   67	40	5	element$iv	Ljava/lang/Object;
/*     */     //   40	71	3	$i$f$forEach	I
/*     */     //   38	73	2	$this$forEach$iv	Ljava/lang/Iterable;
/*     */     //   170	18	8	element$iv$iv	Ljava/lang/Object;
/*     */     //   142	51	6	$i$f$filterIsInstanceTo	I
/*     */     //   139	54	4	$this$filterIsInstanceTo$iv$iv	Ljava/lang/Iterable;
/*     */     //   139	54	5	destination$iv$iv	Ljava/util/Collection;
/*     */     //   124	73	3	$i$f$filterIsInstance	I
/*     */     //   122	75	2	$this$filterIsInstance$iv	Ljava/lang/Iterable;
/*     */     //   275	18	8	element$iv$iv	Ljava/lang/Object;
/*     */     //   247	51	6	$i$f$filterIsInstanceTo	I
/*     */     //   244	54	4	$this$filterIsInstanceTo$iv$iv	Ljava/lang/Iterable;
/*     */     //   244	54	5	destination$iv$iv	Ljava/util/Collection;
/*     */     //   229	73	3	$i$f$filterIsInstance	I
/*     */     //   227	75	2	$this$filterIsInstance$iv	Ljava/lang/Iterable;
/*     */     //   382	18	9	element$iv$iv	Ljava/lang/Object;
/*     */     //   354	51	7	$i$f$filterIsInstanceTo	I
/*     */     //   351	54	5	$this$filterIsInstanceTo$iv$iv	Ljava/lang/Iterable;
/*     */     //   351	54	6	destination$iv$iv	Ljava/util/Collection;
/*     */     //   336	73	4	$i$f$filterIsInstance	I
/*     */     //   333	76	3	$this$filterIsInstance$iv	Ljava/lang/Iterable;
/*     */     //   454	5	8	$i$a$-firstOrNull-ConfigGUI$selectCategory$2	I
/*     */     //   451	8	7	it	Lxyz/apfelmus/cheeto/client/clickgui/CategoryLabel;
/*     */     //   444	23	6	element$iv	Ljava/lang/Object;
/*     */     //   417	51	4	$i$f$firstOrNull	I
/*     */     //   414	54	3	$this$firstOrNull$iv	Ljava/lang/Iterable;
/*     */     //   0	483	0	this	Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;
/*     */     //   0	483	1	category	Lxyz/apfelmus/cf4m/module/Category;
/*     */   }
/*     */   
/*     */   public final void selectModule(@NotNull Object module) {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: ldc_w 'module'
/*     */     //   4: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   7: aload_0
/*     */     //   8: invokespecial getSettingScroller : ()Lgg/essential/elementa/components/ScrollComponent;
/*     */     //   11: invokevirtual clearChildren : ()Lgg/essential/elementa/components/ScrollComponent;
/*     */     //   14: pop
/*     */     //   15: new xyz/apfelmus/cheeto/client/clickgui/KeybindLabel
/*     */     //   18: dup
/*     */     //   19: aload_1
/*     */     //   20: aload_0
/*     */     //   21: invokevirtual getWindow : ()Lgg/essential/elementa/components/Window;
/*     */     //   24: invokespecial <init> : (Ljava/lang/Object;Lgg/essential/elementa/components/Window;)V
/*     */     //   27: checkcast gg/essential/elementa/UIComponent
/*     */     //   30: aload_0
/*     */     //   31: invokespecial getSettingScroller : ()Lgg/essential/elementa/components/ScrollComponent;
/*     */     //   34: checkcast gg/essential/elementa/UIComponent
/*     */     //   37: invokestatic childOf : (Lgg/essential/elementa/UIComponent;Lgg/essential/elementa/UIComponent;)Lgg/essential/elementa/UIComponent;
/*     */     //   40: pop
/*     */     //   41: getstatic xyz/apfelmus/cf4m/CF4M.INSTANCE : Lxyz/apfelmus/cf4m/CF4M;
/*     */     //   44: getfield settingManager : Lxyz/apfelmus/cf4m/manager/SettingManager;
/*     */     //   47: aload_1
/*     */     //   48: invokevirtual getSettings : (Ljava/lang/Object;)Ljava/util/ArrayList;
/*     */     //   51: astore_2
/*     */     //   52: aload_2
/*     */     //   53: ifnull -> 209
/*     */     //   56: getstatic xyz/apfelmus/cf4m/CF4M.INSTANCE : Lxyz/apfelmus/cf4m/CF4M;
/*     */     //   59: getfield settingManager : Lxyz/apfelmus/cf4m/manager/SettingManager;
/*     */     //   62: aload_1
/*     */     //   63: invokevirtual getSettings : (Ljava/lang/Object;)Ljava/util/ArrayList;
/*     */     //   66: astore_3
/*     */     //   67: aload_3
/*     */     //   68: ldc_w 'INSTANCE.settingManager.getSettings(module)'
/*     */     //   71: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   74: aload_3
/*     */     //   75: checkcast java/lang/Iterable
/*     */     //   78: astore_3
/*     */     //   79: iconst_0
/*     */     //   80: istore #4
/*     */     //   82: aload_3
/*     */     //   83: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   88: astore #5
/*     */     //   90: aload #5
/*     */     //   92: invokeinterface hasNext : ()Z
/*     */     //   97: ifeq -> 152
/*     */     //   100: aload #5
/*     */     //   102: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   107: astore #6
/*     */     //   109: aload #6
/*     */     //   111: astore #7
/*     */     //   113: iconst_0
/*     */     //   114: istore #8
/*     */     //   116: new xyz/apfelmus/cheeto/client/clickgui/SettingLabel
/*     */     //   119: dup
/*     */     //   120: aload_1
/*     */     //   121: aload #7
/*     */     //   123: ldc_w 'setting'
/*     */     //   126: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   129: aload #7
/*     */     //   131: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   134: checkcast gg/essential/elementa/UIComponent
/*     */     //   137: aload_0
/*     */     //   138: invokespecial getSettingScroller : ()Lgg/essential/elementa/components/ScrollComponent;
/*     */     //   141: checkcast gg/essential/elementa/UIComponent
/*     */     //   144: invokestatic childOf : (Lgg/essential/elementa/UIComponent;Lgg/essential/elementa/UIComponent;)Lgg/essential/elementa/UIComponent;
/*     */     //   147: pop
/*     */     //   148: nop
/*     */     //   149: goto -> 90
/*     */     //   152: nop
/*     */     //   153: new gg/essential/elementa/components/UIContainer
/*     */     //   156: dup
/*     */     //   157: invokespecial <init> : ()V
/*     */     //   160: new gg/essential/elementa/constraints/SiblingConstraint
/*     */     //   163: dup
/*     */     //   164: fconst_0
/*     */     //   165: iconst_0
/*     */     //   166: iconst_3
/*     */     //   167: aconst_null
/*     */     //   168: invokespecial <init> : (FZILkotlin/jvm/internal/DefaultConstructorMarker;)V
/*     */     //   171: checkcast gg/essential/elementa/constraints/YConstraint
/*     */     //   174: invokevirtual setY : (Lgg/essential/elementa/constraints/YConstraint;)Lgg/essential/elementa/UIComponent;
/*     */     //   177: bipush #20
/*     */     //   179: invokestatic valueOf : (I)Ljava/lang/Integer;
/*     */     //   182: checkcast java/lang/Number
/*     */     //   185: iconst_0
/*     */     //   186: iconst_0
/*     */     //   187: iconst_3
/*     */     //   188: aconst_null
/*     */     //   189: invokestatic pixels$default : (Ljava/lang/Number;ZZILjava/lang/Object;)Lgg/essential/elementa/constraints/PixelConstraint;
/*     */     //   192: checkcast gg/essential/elementa/constraints/HeightConstraint
/*     */     //   195: invokevirtual setHeight : (Lgg/essential/elementa/constraints/HeightConstraint;)Lgg/essential/elementa/UIComponent;
/*     */     //   198: aload_0
/*     */     //   199: invokespecial getSettingScroller : ()Lgg/essential/elementa/components/ScrollComponent;
/*     */     //   202: checkcast gg/essential/elementa/UIComponent
/*     */     //   205: invokestatic childOf : (Lgg/essential/elementa/UIComponent;Lgg/essential/elementa/UIComponent;)Lgg/essential/elementa/UIComponent;
/*     */     //   208: pop
/*     */     //   209: aload_0
/*     */     //   210: invokespecial getModuleScroller : ()Lgg/essential/elementa/components/ScrollComponent;
/*     */     //   213: invokevirtual getAllChildren : ()Ljava/util/concurrent/CopyOnWriteArrayList;
/*     */     //   216: checkcast java/lang/Iterable
/*     */     //   219: astore #4
/*     */     //   221: iconst_0
/*     */     //   222: istore #5
/*     */     //   224: aload #4
/*     */     //   226: astore #6
/*     */     //   228: new java/util/ArrayList
/*     */     //   231: dup
/*     */     //   232: invokespecial <init> : ()V
/*     */     //   235: checkcast java/util/Collection
/*     */     //   238: astore #7
/*     */     //   240: iconst_0
/*     */     //   241: istore #8
/*     */     //   243: aload #6
/*     */     //   245: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   250: astore #9
/*     */     //   252: aload #9
/*     */     //   254: invokeinterface hasNext : ()Z
/*     */     //   259: ifeq -> 292
/*     */     //   262: aload #9
/*     */     //   264: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   269: astore #10
/*     */     //   271: aload #10
/*     */     //   273: instanceof xyz/apfelmus/cheeto/client/clickgui/ModuleLabel
/*     */     //   276: ifeq -> 252
/*     */     //   279: aload #7
/*     */     //   281: aload #10
/*     */     //   283: invokeinterface add : (Ljava/lang/Object;)Z
/*     */     //   288: pop
/*     */     //   289: goto -> 252
/*     */     //   292: aload #7
/*     */     //   294: checkcast java/util/List
/*     */     //   297: nop
/*     */     //   298: checkcast java/lang/Iterable
/*     */     //   301: astore #4
/*     */     //   303: nop
/*     */     //   304: iconst_0
/*     */     //   305: istore #5
/*     */     //   307: aload #4
/*     */     //   309: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   314: astore #6
/*     */     //   316: aload #6
/*     */     //   318: invokeinterface hasNext : ()Z
/*     */     //   323: ifeq -> 358
/*     */     //   326: aload #6
/*     */     //   328: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   333: astore #7
/*     */     //   335: aload #7
/*     */     //   337: checkcast xyz/apfelmus/cheeto/client/clickgui/ModuleLabel
/*     */     //   340: astore #8
/*     */     //   342: iconst_0
/*     */     //   343: istore #9
/*     */     //   345: aload #8
/*     */     //   347: invokevirtual isSelected : ()Z
/*     */     //   350: ifeq -> 316
/*     */     //   353: aload #7
/*     */     //   355: goto -> 359
/*     */     //   358: aconst_null
/*     */     //   359: checkcast xyz/apfelmus/cheeto/client/clickgui/ModuleLabel
/*     */     //   362: dup
/*     */     //   363: ifnonnull -> 370
/*     */     //   366: pop
/*     */     //   367: goto -> 373
/*     */     //   370: invokevirtual deselect : ()V
/*     */     //   373: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #233	-> 7
/*     */     //   #235	-> 15
/*     */     //   #236	-> 41
/*     */     //   #237	-> 52
/*     */     //   #238	-> 56
/*     */     //   #382	-> 82
/*     */     //   #239	-> 116
/*     */     //   #240	-> 148
/*     */     //   #383	-> 152
/*     */     //   #241	-> 153
/*     */     //   #244	-> 209
/*     */     //   #384	-> 224
/*     */     //   #393	-> 243
/*     */     //   #394	-> 292
/*     */     //   #384	-> 297
/*     */     //   #244	-> 303
/*     */     //   #395	-> 307
/*     */     //   #244	-> 345
/*     */     //   #396	-> 358
/*     */     //   #244	-> 359
/*     */     //   #245	-> 373
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   116	33	8	$i$a$-forEach-ConfigGUI$selectModule$1	I
/*     */     //   113	36	7	setting	Ljava/lang/Object;
/*     */     //   109	40	6	element$iv	Ljava/lang/Object;
/*     */     //   82	71	4	$i$f$forEach	I
/*     */     //   79	74	3	$this$forEach$iv	Ljava/lang/Iterable;
/*     */     //   271	18	10	element$iv$iv	Ljava/lang/Object;
/*     */     //   243	51	8	$i$f$filterIsInstanceTo	I
/*     */     //   240	54	6	$this$filterIsInstanceTo$iv$iv	Ljava/lang/Iterable;
/*     */     //   240	54	7	destination$iv$iv	Ljava/util/Collection;
/*     */     //   224	74	5	$i$f$filterIsInstance	I
/*     */     //   221	77	4	$this$filterIsInstance$iv	Ljava/lang/Iterable;
/*     */     //   345	5	9	$i$a$-firstOrNull-ConfigGUI$selectModule$2	I
/*     */     //   342	8	8	it	Lxyz/apfelmus/cheeto/client/clickgui/ModuleLabel;
/*     */     //   335	23	7	element$iv	Ljava/lang/Object;
/*     */     //   307	52	5	$i$f$firstOrNull	I
/*     */     //   304	55	4	$this$firstOrNull$iv	Ljava/lang/Iterable;
/*     */     //   52	322	2	settings	Ljava/util/ArrayList;
/*     */     //   0	374	0	this	Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;
/*     */     //   0	374	1	module	Ljava/lang/Object;
/*     */   }
/*     */   
/*     */   public final void selectConfig(@NotNull String config) {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: ldc_w 'config'
/*     */     //   4: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   7: aload_1
/*     */     //   8: invokestatic setActiveConfig : (Ljava/lang/String;)Z
/*     */     //   11: pop
/*     */     //   12: aload_0
/*     */     //   13: invokespecial getConfigScroller : ()Lgg/essential/elementa/components/ScrollComponent;
/*     */     //   16: invokevirtual getAllChildren : ()Ljava/util/concurrent/CopyOnWriteArrayList;
/*     */     //   19: checkcast java/lang/Iterable
/*     */     //   22: astore_2
/*     */     //   23: iconst_0
/*     */     //   24: istore_3
/*     */     //   25: aload_2
/*     */     //   26: astore #4
/*     */     //   28: new java/util/ArrayList
/*     */     //   31: dup
/*     */     //   32: invokespecial <init> : ()V
/*     */     //   35: checkcast java/util/Collection
/*     */     //   38: astore #5
/*     */     //   40: iconst_0
/*     */     //   41: istore #6
/*     */     //   43: aload #4
/*     */     //   45: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   50: astore #7
/*     */     //   52: aload #7
/*     */     //   54: invokeinterface hasNext : ()Z
/*     */     //   59: ifeq -> 92
/*     */     //   62: aload #7
/*     */     //   64: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   69: astore #8
/*     */     //   71: aload #8
/*     */     //   73: instanceof xyz/apfelmus/cheeto/client/clickgui/ConfigLabel
/*     */     //   76: ifeq -> 52
/*     */     //   79: aload #5
/*     */     //   81: aload #8
/*     */     //   83: invokeinterface add : (Ljava/lang/Object;)Z
/*     */     //   88: pop
/*     */     //   89: goto -> 52
/*     */     //   92: aload #5
/*     */     //   94: checkcast java/util/List
/*     */     //   97: nop
/*     */     //   98: checkcast java/lang/Iterable
/*     */     //   101: astore_2
/*     */     //   102: nop
/*     */     //   103: iconst_0
/*     */     //   104: istore_3
/*     */     //   105: aload_2
/*     */     //   106: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   111: astore #4
/*     */     //   113: aload #4
/*     */     //   115: invokeinterface hasNext : ()Z
/*     */     //   120: ifeq -> 155
/*     */     //   123: aload #4
/*     */     //   125: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   130: astore #5
/*     */     //   132: aload #5
/*     */     //   134: checkcast xyz/apfelmus/cheeto/client/clickgui/ConfigLabel
/*     */     //   137: astore #6
/*     */     //   139: iconst_0
/*     */     //   140: istore #7
/*     */     //   142: aload #6
/*     */     //   144: invokevirtual isSelected : ()Z
/*     */     //   147: ifeq -> 113
/*     */     //   150: aload #5
/*     */     //   152: goto -> 156
/*     */     //   155: aconst_null
/*     */     //   156: checkcast xyz/apfelmus/cheeto/client/clickgui/ConfigLabel
/*     */     //   159: dup
/*     */     //   160: ifnonnull -> 167
/*     */     //   163: pop
/*     */     //   164: goto -> 170
/*     */     //   167: invokevirtual deselect : ()V
/*     */     //   170: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #248	-> 7
/*     */     //   #250	-> 12
/*     */     //   #397	-> 25
/*     */     //   #406	-> 43
/*     */     //   #407	-> 92
/*     */     //   #397	-> 97
/*     */     //   #250	-> 102
/*     */     //   #408	-> 105
/*     */     //   #250	-> 142
/*     */     //   #409	-> 155
/*     */     //   #250	-> 156
/*     */     //   #251	-> 170
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   71	18	8	element$iv$iv	Ljava/lang/Object;
/*     */     //   43	51	6	$i$f$filterIsInstanceTo	I
/*     */     //   40	54	4	$this$filterIsInstanceTo$iv$iv	Ljava/lang/Iterable;
/*     */     //   40	54	5	destination$iv$iv	Ljava/util/Collection;
/*     */     //   25	73	3	$i$f$filterIsInstance	I
/*     */     //   23	75	2	$this$filterIsInstance$iv	Ljava/lang/Iterable;
/*     */     //   142	5	7	$i$a$-firstOrNull-ConfigGUI$selectConfig$1	I
/*     */     //   139	8	6	it	Lxyz/apfelmus/cheeto/client/clickgui/ConfigLabel;
/*     */     //   132	23	5	element$iv	Ljava/lang/Object;
/*     */     //   105	51	3	$i$f$firstOrNull	I
/*     */     //   103	53	2	$this$firstOrNull$iv	Ljava/lang/Iterable;
/*     */     //   0	171	0	this	Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;
/*     */     //   0	171	1	config	Ljava/lang/String;
/*     */   }
/*     */   
/*     */   public void updateGuiScale() {
/*     */     setNewGuiScale(GuiScale.Companion.scaleForScreenSize$default(GuiScale.Companion, 0, 1, null).ordinal());
/*     */     super.updateGuiScale();
/*     */   }
/*     */   
/*     */   public boolean func_73868_f() {
/*     */     return false;
/*     */   }
/*     */   
/*     */   public void onScreenClose() {
/*     */     super.onScreenClose();
/*     */     if (CF4M.INSTANCE.moduleManager.isEnabled("ClickGUI"))
/*     */       CF4M.INSTANCE.moduleManager.toggle("ClickGUI"); 
/*     */     CF4M.INSTANCE.configManager.save();
/*     */   }
/*     */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\clickgui\ConfigGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */