/*    */ package xyz.apfelmus.cheeto.client.clickgui;
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 6, 0}, k = 1, xi = 48, d1 = {"\0000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\016\n\002\b\002\n\002\020\013\n\002\b\004\n\002\030\002\n\002\b\005\n\002\020\002\n\002\b\002\030\0002\0020\001B\025\022\006\020\002\032\0020\003\022\006\020\004\032\0020\005¢\006\002\020\006J\006\020\022\032\0020\023J\006\020\024\032\0020\023R\016\020\004\032\0020\005X\004¢\006\002\n\000R\016\020\002\032\0020\003X\004¢\006\002\n\000R\032\020\007\032\0020\bX\016¢\006\016\n\000\032\004\b\007\020\t\"\004\b\n\020\013R\033\020\f\032\0020\r8BX\002¢\006\f\n\004\b\020\020\021\032\004\b\016\020\017¨\006\025"}, d2 = {"Lxyz/apfelmus/cheeto/client/clickgui/ConfigLabel;", "Lgg/essential/elementa/components/UIContainer;", "gui", "Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;", "config", "", "(Lxyz/apfelmus/cheeto/client/clickgui/ConfigGUI;Ljava/lang/String;)V", "isSelected", "", "()Z", "setSelected", "(Z)V", "text", "Lgg/essential/elementa/components/UIText;", "getText", "()Lgg/essential/elementa/components/UIText;", "text$delegate", "Lkotlin/properties/ReadWriteProperty;", "deselect", "", "select", "Cheeto"})
/*    */ public final class ConfigLabel extends UIContainer {
/*    */   @NotNull
/*    */   private final ConfigGUI gui;
/*    */   @NotNull
/*    */   private final String config;
/*    */   @NotNull
/*    */   private final ReadWriteProperty text$delegate;
/*    */   private boolean isSelected;
/*    */   
/* 14 */   public ConfigLabel(@NotNull ConfigGUI gui, @NotNull String config) { this.gui = gui; this.config = config;
/* 15 */     UIComponent $this$constrain$iv = (UIComponent)new UIText(this.config, false, null, 6, null); int $i$f$constrain = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 73 */     UIComponent uIComponent1 = $this$constrain$iv, $this$constrain_u24lambda_u2d0$iv = uIComponent1; int $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 74 */     UIConstraints uIConstraints1 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); ConfigLabel configLabel = this; int $i$a$-constrain-ConfigLabel$text$2 = 0; uIConstraints1.setX((XConstraint)new CenterConstraint()); uIConstraints1.setY((YConstraint)new CenterConstraint()); uIConstraints1.setTextScale((HeightConstraint)UtilitiesKt.pixels$default(Integer.valueOf(1), false, false, 3, null)); Color color = ColorUtils.LABEL; Intrinsics.checkNotNullExpressionValue(color, "LABEL"); uIConstraints1.setColor((ColorConstraint)UtilitiesKt.toConstraint(color)); uIConstraints1.setFontProvider(DefaultFonts.getVANILLA_FONT_RENDERER()); configLabel.text$delegate = ComponentsKt.provideDelegate(ComponentsKt.childOf(uIComponent1, (UIComponent)this), this, $$delegatedProperties[0]); $this$constrain$iv = (UIComponent)this;
/*    */     $i$f$constrain = 0;
/* 76 */     $this$constrain_u24lambda_u2d0$iv = uIComponent1 = $this$constrain$iv; $i$a$-apply-ComponentsKt$constrain$1$iv = 0;
/* 77 */     UIConstraints $this$_init__u24lambda_u2d1 = $this$constrain_u24lambda_u2d0$iv.getConstraints(); int $i$a$-constrain-ConfigLabel$1 = 0; $this$_init__u24lambda_u2d1.setX((XConstraint)UtilitiesKt.pixels$default(Integer.valueOf(0), false, false, 3, null)); $this$_init__u24lambda_u2d1.setY((YConstraint)new SiblingConstraint(0.0F, false, 3, null)); $this$_init__u24lambda_u2d1.setWidth((WidthConstraint)new ChildBasedMaxSizeConstraint()); $this$_init__u24lambda_u2d1.setHeight((HeightConstraint)UtilitiesKt.pixels$default(Integer.valueOf(20), false, false, 3, null)); UIComponent $this$onLeftClick$iv = (UIComponent)this;
/*    */     int $i$f$onLeftClick = 0;
/* 79 */     $this$onLeftClick$iv.onMouseClick(new ConfigLabel$special$$inlined$onLeftClick$1(this)); onMouseEnter(new Function1<UIComponent, Unit>() {
/*    */           public final void invoke(@NotNull UIComponent $this$onMouseEnter) { Intrinsics.checkNotNullParameter($this$onMouseEnter, "$this$onMouseEnter"); if (!ConfigLabel.this.isSelected()) { UIComponent $this$animate$iv = (UIComponent)ConfigLabel.this.getText(); int $i$f$animate = 0; UIComponent uIComponent1 = $this$animate$iv, $this$animate_u24lambda_u2d0$iv = uIComponent1; int $i$a$-apply-AnimationsKt$animate$1$iv = 0; AnimatingConstraints anim$iv = $this$animate_u24lambda_u2d0$iv.makeAnimation(); AnimatingConstraints $this$invoke_u24lambda_u2d0 = anim$iv; int $i$a$-animate-ConfigLabel$3$1 = 0; Color color = ColorUtils.TEXT_HOVERED; Intrinsics.checkNotNullExpressionValue(color, "TEXT_HOVERED"); AnimatingConstraints.setColorAnimation$default($this$invoke_u24lambda_u2d0, (AnimationStrategy)Animations.OUT_EXP, 0.5F, (ColorConstraint)UtilitiesKt.toConstraint(color), 0.0F, 8, null); $this$animate_u24lambda_u2d0$iv.animateTo(anim$iv); }  }
/*    */         }); onMouseLeave(new Function1<UIComponent, Unit>() {
/*    */           public final void invoke(@NotNull UIComponent $this$onMouseLeave) { Intrinsics.checkNotNullParameter($this$onMouseLeave, "$this$onMouseLeave"); if (!ConfigLabel.this.isSelected()) { UIComponent $this$animate$iv = (UIComponent)ConfigLabel.this.getText(); int $i$f$animate = 0; UIComponent uIComponent1 = $this$animate$iv, $this$animate_u24lambda_u2d0$iv = uIComponent1; int $i$a$-apply-AnimationsKt$animate$1$iv = 0; AnimatingConstraints anim$iv = $this$animate_u24lambda_u2d0$iv.makeAnimation(); AnimatingConstraints $this$invoke_u24lambda_u2d0 = anim$iv; int $i$a$-animate-ConfigLabel$4$1 = 0; Color color = ColorUtils.LABEL; Intrinsics.checkNotNullExpressionValue(color, "LABEL"); AnimatingConstraints.setColorAnimation$default($this$invoke_u24lambda_u2d0, (AnimationStrategy)Animations.OUT_EXP, 0.5F, (ColorConstraint)UtilitiesKt.toConstraint(color), 0.0F, 8, null); $this$animate_u24lambda_u2d0$iv.animateTo(anim$iv); }
/*    */              }
/* 84 */         }); } private final UIText getText() { return (UIText)this.text$delegate.getValue(this, $$delegatedProperties[0]); } static { KProperty[] arrayOfKProperty = new KProperty[1]; arrayOfKProperty[0] = (KProperty)Reflection.property1((PropertyReference1)new PropertyReference1Impl(ConfigLabel.class, "text", "getText()Lgg/essential/elementa/components/UIText;", 0)); $$delegatedProperties = (KProperty<Object>[])arrayOfKProperty; } public final void select() { this.gui.selectConfig(this.config); this.isSelected = true; UIComponent $this$animate$iv = (UIComponent)getText(); int $i$f$animate = 0; UIComponent uIComponent1 = $this$animate$iv, $this$animate_u24lambda_u2d0$iv = uIComponent1; int $i$a$-apply-AnimationsKt$animate$1$iv = 0;
/* 85 */     AnimatingConstraints anim$iv = $this$animate_u24lambda_u2d0$iv.makeAnimation();
/* 86 */     AnimatingConstraints $this$select_u24lambda_u2d3 = anim$iv; int $i$a$-animate-ConfigLabel$select$1 = 0; Color color = Color.WHITE; Intrinsics.checkNotNullExpressionValue(color, "WHITE"); AnimatingConstraints.setColorAnimation$default($this$select_u24lambda_u2d3, (AnimationStrategy)Animations.OUT_EXP, 0.5F, (ColorConstraint)UtilitiesKt.toConstraint(color), 0.0F, 8, null);
/* 87 */     $this$animate_u24lambda_u2d0$iv.animateTo(anim$iv); }
/*    */   public final boolean isSelected() { return this.isSelected; }
/* 89 */   public final void setSelected(boolean <set-?>) { this.isSelected = <set-?>; } public final void deselect() { this.isSelected = false; UIComponent $this$animate$iv = (UIComponent)getText(); int $i$f$animate = 0; UIComponent uIComponent1 = $this$animate$iv, $this$animate_u24lambda_u2d0$iv = uIComponent1; int $i$a$-apply-AnimationsKt$animate$1$iv = 0;
/* 90 */     AnimatingConstraints anim$iv = $this$animate_u24lambda_u2d0$iv.makeAnimation();
/* 91 */     AnimatingConstraints $this$deselect_u24lambda_u2d4 = anim$iv; int $i$a$-animate-ConfigLabel$deselect$1 = 0; Color color = ColorUtils.LABEL; Intrinsics.checkNotNullExpressionValue(color, "LABEL"); AnimatingConstraints.setColorAnimation$default($this$deselect_u24lambda_u2d4, (AnimationStrategy)Animations.OUT_EXP, 0.5F, (ColorConstraint)UtilitiesKt.toConstraint(color), 0.0F, 8, null);
/* 92 */     $this$animate_u24lambda_u2d0$iv.animateTo(anim$iv); }
/*    */ 
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\clickgui\ConfigLabel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */