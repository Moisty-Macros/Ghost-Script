/*    */ package xyz.apfelmus.cheeto.client.commands;
/*    */ 
/*    */ import xyz.apfelmus.cf4m.CF4M;
/*    */ import xyz.apfelmus.cf4m.annotation.command.Command;
/*    */ import xyz.apfelmus.cf4m.annotation.command.Exec;
/*    */ import xyz.apfelmus.cf4m.annotation.command.Param;
/*    */ 
/*    */ @Command(name = {"toggle", "t"}, description = "Toggles a module")
/*    */ public class ToggleCommand {
/*    */   @Exec
/*    */   private void exec(@Param("module") String name) {
/* 12 */     Object module = CF4M.INSTANCE.moduleManager.getModule(name);
/*    */     
/* 14 */     if (module == null) {
/* 15 */       CF4M.INSTANCE.configuration.message("The module &l" + name + "&r does not exist.");
/*    */       
/*    */       return;
/*    */     } 
/* 19 */     CF4M.INSTANCE.moduleManager.toggle(module);
/* 20 */     CF4M.INSTANCE.configManager.save();
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\commands\ToggleCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */