/*    */ package xyz.apfelmus.cheeto.client.commands;
/*    */ 
/*    */ import xyz.apfelmus.cf4m.CF4M;
/*    */ import xyz.apfelmus.cf4m.annotation.command.Command;
/*    */ import xyz.apfelmus.cf4m.annotation.command.Exec;
/*    */ import xyz.apfelmus.cf4m.annotation.command.Param;
/*    */ import xyz.apfelmus.cheeto.client.configs.ClientConfig;
/*    */ import xyz.apfelmus.cheeto.client.utils.client.ChatUtils;
/*    */ 
/*    */ @Command(name = {"config", "cfg"}, description = "Command to manage configs")
/*    */ public class ConfigCommand {
/*    */   @Exec
/*    */   public void exec(@Param("Action") String action) {
/* 14 */     if (action.equalsIgnoreCase("list") || action.equalsIgnoreCase("ls")) {
/* 15 */       ChatUtils.send("Available configs are: &7" + String.join(", ", ClientConfig.getConfigs()), new String[0]);
/* 16 */     } else if (action.equalsIgnoreCase("current") || action.equalsIgnoreCase("cur")) {
/* 17 */       ChatUtils.send("Current config: &a" + ClientConfig.getActiveConfig(), new String[0]);
/* 18 */     } else if (action.equalsIgnoreCase("set") || action.equalsIgnoreCase("rename") || action
/* 19 */       .equalsIgnoreCase("delete") || action.equalsIgnoreCase("remove") || action
/* 20 */       .equalsIgnoreCase("rm") || action.equalsIgnoreCase("create") || action
/* 21 */       .equalsIgnoreCase("new")) {
/* 22 */       ChatUtils.send("Not enough arguments!", new String[0]);
/*    */     } else {
/* 24 */       ChatUtils.send("Not a valid action, try: &7<list/ls>, <current/cur>, <set/load>, <delete/remove/rm>, <create/new>, <rename>", new String[0]);
/*    */     } 
/*    */   }
/*    */   
/*    */   @Exec
/*    */   public void exec(@Param("Action") String action, @Param("Config") String configName) {
/* 30 */     if (action.equalsIgnoreCase("set") || action.equalsIgnoreCase("load")) {
/* 31 */       boolean set = ClientConfig.setActiveConfig(configName);
/*    */       
/* 33 */       if (set) {
/* 34 */         ChatUtils.send("Switched to config: &a" + ClientConfig.getActiveConfig(), new String[0]);
/* 35 */         CF4M.INSTANCE.configManager.save();
/*    */       } else {
/* 37 */         ChatUtils.send("Config &7" + configName + "&f doesn't exist", new String[0]);
/* 38 */         exec("ls");
/*    */       } 
/* 40 */     } else if (action.equalsIgnoreCase("rename")) {
/* 41 */       if (ClientConfig.renameConfig(configName)) {
/* 42 */         ChatUtils.send("Renamed current config to: &7" + ClientConfig.getActiveConfig(), new String[0]);
/*    */       } else {
/* 44 */         ChatUtils.send("Something went wrong! ¯\\_(ツ)_/¯", new String[0]);
/*    */       } 
/* 46 */     } else if (action.equalsIgnoreCase("delete") || action.equalsIgnoreCase("remove") || action.equalsIgnoreCase("rm")) {
/* 47 */       if (ClientConfig.removeConfig(configName)) {
/* 48 */         ChatUtils.send("Removed current config, now using: &a" + ClientConfig.getActiveConfig(), new String[0]);
/*    */       } else {
/* 50 */         ChatUtils.send("Something went wrong! ¯\\_(ツ)_/¯", new String[0]);
/*    */       } 
/* 52 */     } else if (action.equalsIgnoreCase("create") || action.equalsIgnoreCase("new")) {
/* 53 */       if (ClientConfig.createConfig(configName)) {
/* 54 */         ChatUtils.send("Created new config: &a" + ClientConfig.getActiveConfig(), new String[0]);
/*    */       } else {
/* 56 */         ChatUtils.send("Config &7" + configName + "&f already exists!", new String[0]);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\commands\ConfigCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */