/*    */ package xyz.apfelmus.cheeto.client.commands;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import xyz.apfelmus.cf4m.CF4M;
/*    */ import xyz.apfelmus.cf4m.annotation.command.Command;
/*    */ import xyz.apfelmus.cf4m.annotation.command.Exec;
/*    */ import xyz.apfelmus.cf4m.annotation.command.Param;
/*    */ import xyz.apfelmus.cheeto.client.utils.client.ChatUtils;
/*    */ import xyz.apfelmus.cheeto.client.utils.math.VecUtils;
/*    */ import xyz.apfelmus.cheeto.client.utils.pathfinding.Pathfinder;
/*    */ 
/*    */ @Command(name = {"goto", "gt"}, description = "Pathfinds towards a block")
/*    */ public class GotoCommand {
/* 15 */   private static Minecraft mc = Minecraft.func_71410_x();
/*    */   
/*    */   @Exec
/*    */   public void exec(@Param("X") String x, @Param("Y") String y, @Param("Z") String z) {
/*    */     try {
/* 20 */       Pathfinder.setup(new BlockPos(VecUtils.floorVec(mc.field_71439_g.func_174791_d())), new BlockPos(Integer.parseInt(x), Integer.parseInt(y), Integer.parseInt(z)), 0.0D);
/* 21 */       if (Pathfinder.hasPath()) {
/* 22 */         CF4M.INSTANCE.moduleManager.toggle("Pathfinding");
/*    */       } else {
/* 24 */         ChatUtils.send(String.format("Could not find a path for X: %s, Y: %s, Z: %s", new Object[] { x, y, z }), new String[0]);
/*    */       } 
/* 26 */     } catch (NumberFormatException numberFormatException) {}
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\commands\GotoCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */