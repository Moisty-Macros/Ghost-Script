/*    */ package xyz.apfelmus.cheeto.client.commands;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import xyz.apfelmus.cf4m.CF4M;
/*    */ import xyz.apfelmus.cf4m.annotation.command.Command;
/*    */ import xyz.apfelmus.cf4m.annotation.command.Exec;
/*    */ import xyz.apfelmus.cf4m.annotation.command.Param;
/*    */ import xyz.apfelmus.cheeto.client.settings.BooleanSetting;
/*    */ import xyz.apfelmus.cheeto.client.settings.FloatSetting;
/*    */ import xyz.apfelmus.cheeto.client.settings.IntegerSetting;
/*    */ import xyz.apfelmus.cheeto.client.settings.ModeSetting;
/*    */ 
/*    */ @Command(name = {"set", "s"}, description = "Sets a setting of a module")
/*    */ public class SetCommand {
/*    */   private Object currentModule;
/*    */   
/*    */   @Exec
/*    */   public void exec(@Param("Module") String moduleName) {
/* 19 */     printModule(moduleName);
/*    */     
/* 21 */     CF4M.INSTANCE.configuration.message("No setting for &l" + moduleName + "&r specified.");
/* 22 */     printSettings();
/*    */   }
/*    */   private ArrayList<Object> settings; private Object currentSetting;
/*    */   private void printModule(@Param("Module") String moduleName) {
/* 26 */     this.currentModule = CF4M.INSTANCE.moduleManager.getModule(moduleName);
/* 27 */     if (this.currentModule == null) {
/* 28 */       CF4M.INSTANCE.configuration.message("The module &l" + moduleName + "&r does not exist");
/*    */       
/*    */       return;
/*    */     } 
/* 32 */     this.settings = CF4M.INSTANCE.settingManager.getSettings(this.currentModule);
/*    */     
/* 34 */     if (this.settings == null) {
/* 35 */       CF4M.INSTANCE.configuration.message("The module &l" + moduleName + "&r has no settings");
/*    */     }
/*    */   }
/*    */   
/*    */   private void printSettings() {
/* 40 */     CF4M.INSTANCE.configuration.message("Here is the list of settings:");
/*    */     
/* 42 */     for (Object s : this.settings) {
/* 43 */       CF4M.INSTANCE.configuration.message(CF4M.INSTANCE.settingManager.getName(this.currentModule, s) + "(" + s.getClass().getSimpleName() + ")" + CF4M.INSTANCE.settingManager.getDescription(this.currentModule, s));
/* 44 */       if (s instanceof ModeSetting) {
/* 45 */         ((ModeSetting)s).getModes().forEach(CF4M.INSTANCE.configuration::message);
/*    */       }
/*    */     } 
/*    */   }
/*    */   
/*    */   private void printModuleSettings(@Param("Module") String moduleName, @Param("Setting") String settingName) {
/* 51 */     printModule(moduleName);
/*    */     
/* 53 */     Object setting = CF4M.INSTANCE.settingManager.getSetting(this.currentModule, settingName);
/* 54 */     if (setting != null) {
/* 55 */       this.currentSetting = setting;
/* 56 */       CF4M.INSTANCE.configuration.message(CF4M.INSTANCE.settingManager.getName(this.currentModule, this.currentSetting) + " > " + this.currentSetting.getClass().getSimpleName());
/*    */     } else {
/* 58 */       CF4M.INSTANCE.configuration.message("The setting &7" + settingName + "&f does not exist");
/*    */       
/* 60 */       printSettings();
/*    */     } 
/*    */   }
/*    */   
/*    */   @Exec
/*    */   public void exec(@Param("Module") String moduleName, @Param("Setting") String settingName) {
/* 66 */     printModuleSettings(moduleName, settingName);
/*    */   }
/*    */   
/*    */   @Exec
/*    */   public void exec(@Param("Module") String moduleName, @Param("Setting") String settingName, @Param("SettingValue") String settingValue) {
/* 71 */     printModuleSettings(moduleName, settingName);
/*    */     
/*    */     try {
/* 74 */       if (this.currentSetting instanceof BooleanSetting) {
/* 75 */         ((BooleanSetting)this.currentSetting).setState(Boolean.parseBoolean(settingValue));
/* 76 */       } else if (this.currentSetting instanceof FloatSetting) {
/* 77 */         ((FloatSetting)this.currentSetting).setCurrent(Float.valueOf(Float.parseFloat(settingValue)));
/* 78 */       } else if (this.currentSetting instanceof IntegerSetting) {
/* 79 */         ((IntegerSetting)this.currentSetting).setCurrent(Integer.valueOf(Integer.parseInt(settingValue)));
/* 80 */       } else if (this.currentSetting instanceof ModeSetting) {
/* 81 */         ((ModeSetting)this.currentSetting).setCurrent(settingValue);
/*    */       } 
/*    */       
/* 84 */       CF4M.INSTANCE.configuration.message("&7" + CF4M.INSTANCE.settingManager.getName(this.currentModule, this.currentSetting) + "&f was set to &7" + settingValue);
/* 85 */       CF4M.INSTANCE.configManager.save();
/* 86 */     } catch (NumberFormatException e) {
/* 87 */       CF4M.INSTANCE.configuration.message("&cAn Error occured while trying to set &l" + settingName + " &r&cto &l" + settingValue);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\commands\SetCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */