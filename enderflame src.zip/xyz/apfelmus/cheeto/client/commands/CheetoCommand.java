/*    */ package xyz.apfelmus.cheeto.client.commands;
/*    */ 
/*    */ import net.minecraft.command.CommandBase;
/*    */ import net.minecraft.command.ICommandSender;
/*    */ import xyz.apfelmus.cheeto.client.utils.client.ChatUtils;
/*    */ 
/*    */ public class CheetoCommand
/*    */   extends CommandBase {
/*    */   public static final String COMMAND_NAME = "cheeto";
/*    */   public static final String COMMAND_USAGE = "/cheeto";
/*    */   
/*    */   public String func_71517_b() {
/* 13 */     return "cheeto";
/*    */   }
/*    */ 
/*    */   
/*    */   public String func_71518_a(ICommandSender sender) {
/* 18 */     return "/cheeto";
/*    */   }
/*    */ 
/*    */   
/*    */   public void func_71515_b(ICommandSender sender, String[] args) {
/* 23 */     ChatUtils.send("================================", new String[0]);
/* 24 */     ChatUtils.send("There's no command such as /cheeto you retard", new String[0]);
/* 25 */     ChatUtils.send("To bring up the GUI, type \",t ClickGUI\" in chat, or press the Right Control Key on your keyboard", new String[0]);
/* 26 */     ChatUtils.send("The Command prefix is \",\" and you can type \",help\" to get a list of commands", new String[0]);
/* 27 */     ChatUtils.send("Yeah, that's a fucking comma you dumbass bitch", new String[0]);
/* 28 */     ChatUtils.send("================================", new String[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean func_71519_b(ICommandSender sender) {
/* 33 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\commands\CheetoCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */