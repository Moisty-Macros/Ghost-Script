/*    */ package xyz.apfelmus.cheeto.client.listener;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraftforge.client.event.ClientChatReceivedEvent;
/*    */ import net.minecraftforge.client.event.GuiOpenEvent;
/*    */ import net.minecraftforge.client.event.GuiScreenEvent;
/*    */ import net.minecraftforge.client.event.RenderLivingEvent;
/*    */ import net.minecraftforge.client.event.RenderWorldLastEvent;
/*    */ import net.minecraftforge.event.entity.player.EntityInteractEvent;
/*    */ import net.minecraftforge.event.entity.player.PlayerInteractEvent;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ import net.minecraftforge.fml.common.gameevent.InputEvent;
/*    */ import net.minecraftforge.fml.common.gameevent.TickEvent;
/*    */ import xyz.apfelmus.cheeto.client.events.MouseInputEvent;
/*    */ import xyz.apfelmus.cheeto.client.events.Render3DEvent;
/*    */ import xyz.apfelmus.cheeto.client.events.WorldUnloadEvent;
/*    */ 
/*    */ public class EventListenerRegister {
/* 19 */   private static Minecraft mc = Minecraft.func_71410_x();
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onTick(TickEvent.ClientTickEvent event) {
/* 23 */     if (event.phase == TickEvent.Phase.END || mc.field_71439_g == null || mc.field_71441_e == null)
/* 24 */       return;  (new ClientTickEvent()).call();
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onRenderGui(TickEvent.RenderTickEvent event) {
/* 29 */     if (mc.field_71439_g == null || mc.field_71441_e == null || mc.field_71474_y.field_74330_P || (mc.field_71462_r != null && !(mc.field_71462_r instanceof net.minecraft.client.gui.GuiChat) && !(mc.field_71462_r instanceof xyz.apfelmus.cheeto.client.clickgui.ConfigGUI)))
/* 30 */       return;  (new Render2DEvent()).call();
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onRenderWorld(RenderWorldLastEvent event) {
/* 35 */     (new Render3DEvent(event.partialTicks)).call();
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onChatReceived(ClientChatReceivedEvent event) {
/* 40 */     (new ClientChatReceivedEvent(event.type, event.message)).call();
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onWorldUnload(WorldEvent.Unload event) {
/* 45 */     (new WorldUnloadEvent()).call();
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onGuiOpen(GuiOpenEvent event) {
/* 50 */     (new GuiOpenEvent(event.gui)).call();
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onBackgroundDrawn(GuiScreenEvent.BackgroundDrawnEvent event) {
/* 55 */     (new BackgroundDrawnEvent(event.gui)).call();
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onBeforeRenderEntity(RenderLivingEvent.Pre<EntityLivingBase> event) {
/* 60 */     (new RenderLivingEventPre(event.entity)).call();
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onInteract(PlayerInteractEvent event) {
/* 65 */     (new PlayerInteractEvent(event.action, event.pos)).call();
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onEntityInteract(EntityInteractEvent event) {
/* 70 */     (new EntityInteractEvent(event)).call();
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onMouseInput(InputEvent.MouseInputEvent event) {
/* 75 */     (new MouseInputEvent(event)).call();
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\listener\EventListenerRegister.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */