/*    */ package xyz.apfelmus.cheeto.client.configuration;
/*    */ 
/*    */ import xyz.apfelmus.cf4m.CF4M;
/*    */ import xyz.apfelmus.cf4m.annotation.Configuration;
/*    */ import xyz.apfelmus.cf4m.configuration.IConfiguration;
/*    */ import xyz.apfelmus.cheeto.client.configs.ClientConfig;
/*    */ import xyz.apfelmus.cheeto.client.utils.client.ChatUtils;
/*    */ 
/*    */ @Configuration
/*    */ public class CheetoConfig
/*    */   implements IConfiguration {
/*    */   public void message(String message) {
/* 13 */     ChatUtils.send(message, new String[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public void enable(Object module) {
/* 18 */     if (!CF4M.INSTANCE.moduleManager.isSilent(module) && !CF4M.INSTANCE.moduleManager.isEnabled("MuteNotifs") && !ClientConfig.swapping) {
/* 19 */       ChatUtils.send("&aEnabled &f&l%s", new String[] { CF4M.INSTANCE.moduleManager.getName(module) });
/*    */     }
/*    */   }
/*    */   
/*    */   public void disable(Object module) {
/* 24 */     if (!CF4M.INSTANCE.moduleManager.isSilent(module) && !CF4M.INSTANCE.moduleManager.isEnabled("MuteNotifs") && !ClientConfig.swapping)
/* 25 */       ChatUtils.send("&cDisabled &f&l%s", new String[] { CF4M.INSTANCE.moduleManager.getName(module) }); 
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\configuration\CheetoConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */