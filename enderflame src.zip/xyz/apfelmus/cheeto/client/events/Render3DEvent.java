/*    */ package xyz.apfelmus.cheeto.client.events;
/*    */ 
/*    */ import xyz.apfelmus.cf4m.event.Listener;
/*    */ 
/*    */ public class Render3DEvent extends Listener {
/*    */   public float partialTicks;
/*    */   
/*    */   public Render3DEvent(float partialTicks) {
/*  9 */     super(Listener.At.HEAD);
/* 10 */     this.partialTicks = partialTicks;
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\events\Render3DEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */