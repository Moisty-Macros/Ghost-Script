/*    */ package xyz.apfelmus.cheeto.client.events;
/*    */ 
/*    */ import net.minecraft.util.BlockPos;
/*    */ import xyz.apfelmus.cf4m.event.Listener;
/*    */ 
/*    */ public class PlayerInteractEvent
/*    */   extends Listener {
/*    */   public net.minecraftforge.event.entity.player.PlayerInteractEvent.Action action;
/*    */   public BlockPos pos;
/*    */   
/*    */   public PlayerInteractEvent(net.minecraftforge.event.entity.player.PlayerInteractEvent.Action action, BlockPos pos) {
/* 12 */     super(Listener.At.HEAD);
/* 13 */     this.action = action;
/* 14 */     this.pos = pos;
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\events\PlayerInteractEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */