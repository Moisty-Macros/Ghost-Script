/*    */ package xyz.apfelmus.cheeto.client.events;
/*    */ 
/*    */ import net.minecraft.network.Packet;
/*    */ import xyz.apfelmus.cf4m.event.Listener;
/*    */ 
/*    */ public class PacketReceivedEvent extends Listener {
/*    */   public Packet<?> packet;
/*    */   
/*    */   public PacketReceivedEvent(Packet<?> packet) {
/* 10 */     super(Listener.At.HEAD);
/* 11 */     this.packet = packet;
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\events\PacketReceivedEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */