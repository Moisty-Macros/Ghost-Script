/*   */ package xyz.apfelmus.cheeto.client.events;
/*   */ 
/*   */ import xyz.apfelmus.cf4m.event.Listener;
/*   */ 
/*   */ public class Render2DEvent extends Listener {
/*   */   public Render2DEvent() {
/* 7 */     super(Listener.At.HEAD);
/*   */   }
/*   */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\events\Render2DEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */