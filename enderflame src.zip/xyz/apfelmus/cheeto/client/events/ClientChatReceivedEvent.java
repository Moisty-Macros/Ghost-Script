/*    */ package xyz.apfelmus.cheeto.client.events;
/*    */ 
/*    */ import net.minecraft.util.IChatComponent;
/*    */ import xyz.apfelmus.cf4m.event.Listener;
/*    */ 
/*    */ public class ClientChatReceivedEvent extends Listener {
/*    */   public IChatComponent message;
/*    */   public final byte type;
/*    */   
/*    */   public ClientChatReceivedEvent(byte type, IChatComponent message) {
/* 11 */     super(Listener.At.HEAD);
/* 12 */     this.type = type;
/* 13 */     this.message = message;
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\events\ClientChatReceivedEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */