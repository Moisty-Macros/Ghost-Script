/*    */ package xyz.apfelmus.cheeto.client.events;
/*    */ 
/*    */ import net.minecraft.client.gui.GuiScreen;
/*    */ import xyz.apfelmus.cf4m.event.Listener;
/*    */ 
/*    */ public class BackgroundDrawnEvent extends Listener {
/*    */   public GuiScreen gui;
/*    */   
/*    */   public BackgroundDrawnEvent(GuiScreen gui) {
/* 10 */     super(Listener.At.HEAD);
/* 11 */     this.gui = gui;
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\events\BackgroundDrawnEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */