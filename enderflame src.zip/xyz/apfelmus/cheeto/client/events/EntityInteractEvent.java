/*   */ package xyz.apfelmus.cheeto.client.events;
/*   */ 
/*   */ import xyz.apfelmus.cf4m.event.Listener;
/*   */ 
/*   */ public class EntityInteractEvent
/*   */   extends Listener {
/*   */   public EntityInteractEvent(net.minecraftforge.event.entity.player.EntityInteractEvent event) {
/* 8 */     super(Listener.At.HEAD);
/* 9 */     this.event = event;
/*   */   }
/*   */   
/*   */   public net.minecraftforge.event.entity.player.EntityInteractEvent event;
/*   */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\events\EntityInteractEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */