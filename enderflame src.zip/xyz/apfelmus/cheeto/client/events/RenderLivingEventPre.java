/*    */ package xyz.apfelmus.cheeto.client.events;
/*    */ 
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import xyz.apfelmus.cf4m.event.Listener;
/*    */ 
/*    */ public class RenderLivingEventPre extends Listener {
/*    */   public EntityLivingBase entity;
/*    */   
/*    */   public RenderLivingEventPre(EntityLivingBase entity) {
/* 10 */     super(Listener.At.HEAD);
/* 11 */     this.entity = entity;
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\events\RenderLivingEventPre.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */