/*    */ package xyz.apfelmus.cheeto.client.events;
/*    */ 
/*    */ import net.minecraftforge.fml.common.gameevent.InputEvent;
/*    */ import xyz.apfelmus.cf4m.event.Listener;
/*    */ 
/*    */ public class MouseInputEvent
/*    */   extends Listener {
/*    */   public MouseInputEvent(InputEvent.MouseInputEvent event) {
/*  9 */     super(Listener.At.HEAD);
/* 10 */     this.event = event;
/*    */   }
/*    */   
/*    */   public InputEvent.MouseInputEvent event;
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\events\MouseInputEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */