/*    */ package xyz.apfelmus.cheeto.client.settings;
/*    */ 
/*    */ public class StringSetting {
/*    */   private String value;
/*    */   
/*    */   public StringSetting(String value) {
/*  7 */     this.value = value;
/*    */   }
/*    */   
/*    */   public String getCurrent() {
/* 11 */     return this.value;
/*    */   }
/*    */   
/*    */   public void setCurrent(String value) {
/* 15 */     this.value = value;
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\settings\StringSetting.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */