/*     */ package xyz.apfelmus.cheeto.client.configs;
/*     */ import com.google.common.collect.Maps;
/*     */ import com.google.gson.Gson;
/*     */ import com.google.gson.JsonArray;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Paths;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.io.FileUtils;
/*     */ import xyz.apfelmus.cf4m.CF4M;
/*     */ import xyz.apfelmus.cf4m.annotation.config.Save;
/*     */ import xyz.apfelmus.cheeto.client.settings.BooleanSetting;
/*     */ import xyz.apfelmus.cheeto.client.settings.FloatSetting;
/*     */ import xyz.apfelmus.cheeto.client.settings.IntegerSetting;
/*     */ import xyz.apfelmus.cheeto.client.settings.ModeSetting;
/*     */ import xyz.apfelmus.cheeto.client.settings.StringSetting;
/*     */ 
/*     */ @Config(name = "Client")
/*     */ public class ClientConfig {
/*  25 */   public static Map<String, JsonArray> configs = Maps.newHashMap();
/*  26 */   private static String activeConfig = "Default";
/*     */   public static boolean swapping = false;
/*     */   
/*     */   @Load
/*     */   public void load() {
/*  31 */     JsonObject fullCfg = new JsonObject();
/*     */     
/*  33 */     if (!Files.exists(Paths.get(CF4M.INSTANCE.configManager.getPath(this), new String[0]), new java.nio.file.LinkOption[0])) {
/*  34 */       save();
/*     */     }
/*     */     
/*     */     try {
/*  38 */       fullCfg = (JsonObject)(new Gson()).fromJson(read(CF4M.INSTANCE.configManager.getPath(this)), JsonObject.class);
/*  39 */     } catch (IOException e) {
/*  40 */       e.printStackTrace();
/*     */     } 
/*     */     
/*  43 */     activeConfig = fullCfg.get("activeConfig").getAsString();
/*     */     
/*  45 */     if (activeConfig == null) {
/*  46 */       System.out.println("Nah legit not possible");
/*     */       
/*     */       return;
/*     */     } 
/*  50 */     JsonArray configsArray = fullCfg.get("configs").getAsJsonArray();
/*     */     
/*  52 */     for (JsonElement config : configsArray) {
/*  53 */       JsonObject a = config.getAsJsonObject();
/*  54 */       configs.put(a.get("name").getAsString(), a.get("config").getAsJsonArray());
/*     */     } 
/*     */     
/*  57 */     activate(activeConfig);
/*     */   }
/*     */   
/*     */   @Save
/*     */   public void save() {
/*  62 */     JsonObject fullCfg = new JsonObject();
/*     */     
/*  64 */     if (configs.isEmpty()) {
/*  65 */       configs.put("Default", generateModuleJson());
/*     */     }
/*     */     
/*  68 */     fullCfg.addProperty("activeConfig", activeConfig);
/*     */     
/*  70 */     JsonArray configsArray = new JsonArray();
/*  71 */     for (Map.Entry<String, JsonArray> e : configs.entrySet()) {
/*  72 */       JsonObject config = new JsonObject();
/*  73 */       config.addProperty("name", e.getKey());
/*  74 */       if (((String)e.getKey()).equals(activeConfig)) {
/*  75 */         config.add("config", (JsonElement)generateModuleJson());
/*     */       } else {
/*  77 */         config.add("config", (JsonElement)e.getValue());
/*     */       } 
/*  79 */       configsArray.add((JsonElement)config);
/*     */     } 
/*  81 */     fullCfg.add("configs", (JsonElement)configsArray);
/*     */     
/*     */     try {
/*  84 */       write(CF4M.INSTANCE.configManager.getPath(this), (new Gson()).toJson((JsonElement)fullCfg));
/*  85 */     } catch (IOException e) {
/*  86 */       e.printStackTrace();
/*     */     } 
/*  88 */     load();
/*     */   }
/*     */   
/*     */   private JsonArray generateModuleJson() {
/*  92 */     JsonArray modules = new JsonArray();
/*  93 */     for (Object module : CF4M.INSTANCE.moduleManager.getModules()) {
/*  94 */       JsonObject jsonObject = new JsonObject();
/*  95 */       jsonObject.addProperty("name", CF4M.INSTANCE.moduleManager.getName(module));
/*  96 */       jsonObject.addProperty("enable", Boolean.valueOf(CF4M.INSTANCE.moduleManager.isEnabled(module)));
/*  97 */       jsonObject.addProperty("key", Integer.valueOf(CF4M.INSTANCE.moduleManager.getKey(module)));
/*     */       
/*  99 */       List<Object> settings = CF4M.INSTANCE.settingManager.getSettings(module);
/* 100 */       if (settings != null && settings.size() > 0) {
/* 101 */         JsonObject sets = getModuleSettings(module, settings);
/* 102 */         jsonObject.add("settings", (JsonElement)sets);
/*     */       } 
/* 104 */       modules.add((JsonElement)jsonObject);
/*     */     } 
/* 106 */     return modules;
/*     */   }
/*     */   
/*     */   private JsonObject getModuleSettings(Object module, List<Object> settings) {
/* 110 */     JsonObject sets = new JsonObject();
/*     */     
/* 112 */     for (Object set : settings) {
/* 113 */       String setName = CF4M.INSTANCE.settingManager.getName(module, set);
/* 114 */       if (set instanceof BooleanSetting) {
/* 115 */         sets.addProperty(setName, Boolean.valueOf(((BooleanSetting)set).isEnabled())); continue;
/* 116 */       }  if (set instanceof FloatSetting) {
/* 117 */         sets.addProperty(setName, ((FloatSetting)set).getCurrent()); continue;
/* 118 */       }  if (set instanceof IntegerSetting) {
/* 119 */         sets.addProperty(setName, ((IntegerSetting)set).getCurrent()); continue;
/* 120 */       }  if (set instanceof ModeSetting) {
/* 121 */         sets.addProperty(setName, ((ModeSetting)set).getCurrent()); continue;
/* 122 */       }  if (set instanceof StringSetting) {
/* 123 */         sets.addProperty(setName, ((StringSetting)set).getCurrent());
/*     */       }
/*     */     } 
/* 126 */     return sets;
/*     */   }
/*     */   
/*     */   public static boolean renameConfig(String configName) {
/* 130 */     JsonArray cfg = configs.get(activeConfig);
/* 131 */     configs.remove(activeConfig);
/* 132 */     configs.put(configName, cfg);
/* 133 */     activeConfig = configName;
/* 134 */     CF4M.INSTANCE.configManager.save();
/* 135 */     return true;
/*     */   }
/*     */   
/*     */   public static boolean removeConfig(String configName) {
/* 139 */     if (configs.size() > 1) {
/* 140 */       for (String s : configs.keySet()) {
/* 141 */         if (s.equalsIgnoreCase(configName)) {
/* 142 */           configName = s;
/*     */         }
/*     */       } 
/* 145 */       JsonArray cfg = configs.get(activeConfig);
/* 146 */       configs.remove(configName, cfg);
/* 147 */       if (activeConfig.equalsIgnoreCase(configName)) {
/* 148 */         Map.Entry<String, JsonArray> nextCfg = configs.entrySet().stream().findFirst().orElse(null);
/* 149 */         if (nextCfg == null) {
/* 150 */           return false;
/*     */         }
/* 152 */         activeConfig = nextCfg.getKey();
/*     */       } 
/* 154 */       if (!activate(activeConfig)) {
/* 155 */         return false;
/*     */       }
/* 157 */       CF4M.INSTANCE.configManager.save();
/* 158 */       return true;
/*     */     } 
/* 160 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean createConfig(String configName) {
/* 164 */     for (String s : configs.keySet()) {
/* 165 */       if (s.equalsIgnoreCase(configName)) {
/* 166 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 170 */     JsonArray cfg = configs.get(activeConfig);
/* 171 */     configs.put(configName, cfg);
/* 172 */     activeConfig = configName;
/* 173 */     CF4M.INSTANCE.configManager.save();
/* 174 */     return true;
/*     */   }
/*     */   
/*     */   private static boolean activate(String config) {
/* 178 */     if (!configs.containsKey(config)) return false;
/*     */     
/* 180 */     swapping = true;
/*     */     
/* 182 */     JsonArray jsonArray = configs.get(config);
/* 183 */     for (Object module : CF4M.INSTANCE.moduleManager.getModules()) {
/* 184 */       for (JsonElement jsonElement : jsonArray) {
/* 185 */         JsonObject jsonObject = jsonElement.getAsJsonObject();
/*     */         
/* 187 */         if (CF4M.INSTANCE.moduleManager.getName(module).equals(((JsonObject)(new Gson()).fromJson((JsonElement)jsonObject, JsonObject.class)).get("name").getAsString())) {
/* 188 */           CF4M.INSTANCE.moduleManager.setEnabled(module, jsonObject.get("enable").getAsBoolean());
/*     */           
/* 190 */           if (jsonObject.has("settings")) {
/* 191 */             JsonObject setObj = jsonObject.get("settings").getAsJsonObject();
/* 192 */             List<Object> settings = CF4M.INSTANCE.settingManager.getSettings(module);
/*     */             
/* 194 */             if (settings != null && settings.size() > 0) {
/* 195 */               for (Object set : settings) {
/* 196 */                 String setName = CF4M.INSTANCE.settingManager.getName(module, set);
/*     */                 
/* 198 */                 if (setObj.has(setName)) {
/* 199 */                   if (set instanceof BooleanSetting) {
/* 200 */                     ((BooleanSetting)set).setState(setObj.get(setName).getAsBoolean()); continue;
/* 201 */                   }  if (set instanceof FloatSetting) {
/* 202 */                     ((FloatSetting)set).setCurrent(Float.valueOf(setObj.get(setName).getAsFloat())); continue;
/* 203 */                   }  if (set instanceof IntegerSetting) {
/* 204 */                     ((IntegerSetting)set).setCurrent(Integer.valueOf(setObj.get(setName).getAsInt())); continue;
/* 205 */                   }  if (set instanceof ModeSetting) {
/* 206 */                     ((ModeSetting)set).setCurrent(setObj.get(setName).getAsString()); continue;
/* 207 */                   }  if (set instanceof StringSetting) {
/* 208 */                     ((StringSetting)set).setCurrent(setObj.get(setName).getAsString());
/*     */                   }
/*     */                 } 
/*     */               } 
/*     */             }
/*     */           } 
/* 214 */           CF4M.INSTANCE.moduleManager.setKey(module, jsonObject.get("key").getAsInt());
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 219 */     swapping = false;
/* 220 */     return true;
/*     */   }
/*     */   
/*     */   public static List<String> getConfigs() {
/* 224 */     return new ArrayList<>(configs.keySet());
/*     */   }
/*     */   
/*     */   private String read(String path) throws IOException {
/* 228 */     return FileUtils.readFileToString(new File(path));
/*     */   }
/*     */   
/*     */   private void write(String path, String string) throws IOException {
/* 232 */     FileUtils.writeStringToFile(new File(path), string, "UTF-8");
/*     */   }
/*     */   
/*     */   public static String getActiveConfig() {
/* 236 */     return activeConfig;
/*     */   }
/*     */   
/*     */   public static boolean setActiveConfig(String cfg) {
/* 240 */     for (String s : configs.keySet()) {
/* 241 */       if (s.equalsIgnoreCase(cfg)) {
/* 242 */         cfg = s;
/*     */       }
/*     */     } 
/*     */     
/* 246 */     if (activate(cfg)) {
/* 247 */       activeConfig = cfg;
/* 248 */       return true;
/*     */     } 
/* 250 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\client\configs\ClientConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */