/*    */ package xyz.apfelmus.cheeto.injection.mixins;
/*    */ 
/*    */ import net.minecraft.client.entity.EntityPlayerSP;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import xyz.apfelmus.cf4m.CF4M;
/*    */ 
/*    */ @Mixin({EntityPlayerSP.class})
/*    */ public class MixinEntityPlayerSP {
/*    */   @Inject(at = {@At("HEAD")}, method = {"sendChatMessage"}, cancellable = true)
/*    */   private void sendChatMessage(String message, CallbackInfo ci) {
/* 14 */     if (CF4M.INSTANCE.commandManager.isCommand(message))
/* 15 */       ci.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\injection\mixins\MixinEntityPlayerSP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */