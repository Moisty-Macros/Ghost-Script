/*    */ package xyz.apfelmus.cheeto.injection.mixins;
/*    */ 
/*    */ import net.minecraft.client.network.NetHandlerPlayClient;
/*    */ import net.minecraft.network.play.server.S2APacketParticles;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import xyz.apfelmus.cheeto.client.modules.player.AutoFish;
/*    */ 
/*    */ @Mixin({NetHandlerPlayClient.class})
/*    */ public class MixinNetHandlerPlayClient {
/*    */   @Inject(method = {"handleParticles"}, at = {@At("HEAD")})
/*    */   private void handleParticles(S2APacketParticles packetIn, CallbackInfo ci) {
/* 15 */     AutoFish.handleParticles(packetIn);
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\injection\mixins\MixinNetHandlerPlayClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */