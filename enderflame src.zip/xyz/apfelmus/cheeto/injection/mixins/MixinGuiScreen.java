package xyz.apfelmus.cheeto.injection.mixins;

import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin({GuiScreen.class})
public class MixinGuiScreen {
  @Shadow
  public Minecraft field_146297_k;
  
  @Shadow
  protected List<GuiButton> field_146292_n;
  
  @Shadow
  public int field_146294_l;
  
  @Shadow
  public int field_146295_m;
}


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\injection\mixins\MixinGuiScreen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */