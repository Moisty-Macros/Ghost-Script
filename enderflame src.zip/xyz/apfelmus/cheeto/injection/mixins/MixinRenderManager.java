/*    */ package xyz.apfelmus.cheeto.injection.mixins;
/*    */ 
/*    */ import net.minecraft.client.renderer.culling.ICamera;
/*    */ import net.minecraft.client.renderer.entity.RenderManager;
/*    */ import net.minecraft.entity.Entity;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ import xyz.apfelmus.cf4m.CF4M;
/*    */ import xyz.apfelmus.cheeto.client.modules.combat.GhostArm;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({RenderManager.class})
/*    */ public class MixinRenderManager
/*    */ {
/*    */   @Inject(method = {"shouldRender"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void shouldRender(Entity entityIn, ICamera camera, double camX, double camY, double camZ, CallbackInfoReturnable<Boolean> cir) {
/* 20 */     if (CF4M.INSTANCE.moduleManager.isEnabled("GhostArm")) {
/* 21 */       GhostArm ga = (GhostArm)CF4M.INSTANCE.moduleManager.getModule("GhostArm");
/* 22 */       if (ga.HideMobs.isEnabled()) {
/* 23 */         if (ga.Zombies.isEnabled() && 
/* 24 */           entityIn instanceof net.minecraft.entity.monster.EntityZombie) {
/* 25 */           cir.setReturnValue(Boolean.valueOf(false));
/*    */         }
/*    */ 
/*    */         
/* 29 */         if (ga.Players.isEnabled() && 
/* 30 */           entityIn instanceof net.minecraft.client.entity.EntityOtherPlayerMP) {
/* 31 */           cir.setReturnValue(Boolean.valueOf(false));
/*    */         }
/*    */       } 
/*    */     } 
/*    */     
/* 36 */     if (CF4M.INSTANCE.moduleManager.isEnabled("SnowballHider") && 
/* 37 */       entityIn instanceof net.minecraft.entity.projectile.EntitySnowball)
/* 38 */       cir.setReturnValue(Boolean.valueOf(false)); 
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\injection\mixins\MixinRenderManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */