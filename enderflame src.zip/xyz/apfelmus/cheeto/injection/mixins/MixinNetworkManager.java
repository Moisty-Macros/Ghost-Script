/*    */ package xyz.apfelmus.cheeto.injection.mixins;
/*    */ 
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.network.NetworkManager;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraft.network.play.server.S12PacketEntityVelocity;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import xyz.apfelmus.cf4m.CF4M;
/*    */ import xyz.apfelmus.cheeto.client.events.PacketReceivedEvent;
/*    */ 
/*    */ @Mixin({NetworkManager.class})
/*    */ public class MixinNetworkManager
/*    */ {
/*    */   @Inject(method = {"channelRead0"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void read(ChannelHandlerContext context, Packet<?> packet, CallbackInfo ci) {
/* 20 */     if ((Minecraft.func_71410_x()).field_71439_g != null) {
/* 21 */       if (CF4M.INSTANCE.moduleManager.isEnabled("AntiKB") && !(Minecraft.func_71410_x()).field_71439_g.func_180799_ab()) {
/* 22 */         if (packet instanceof net.minecraft.network.play.server.S27PacketExplosion) {
/* 23 */           ci.cancel();
/*    */         }
/* 25 */         if (packet instanceof S12PacketEntityVelocity && ((S12PacketEntityVelocity)packet).func_149412_c() == (Minecraft.func_71410_x()).field_71439_g.func_145782_y()) {
/* 26 */           ci.cancel();
/*    */         }
/*    */       } 
/*    */       
/* 30 */       (new PacketReceivedEvent(packet)).call();
/*    */     } 
/*    */   }
/*    */   
/*    */   @Inject(method = {"sendPacket(Lnet/minecraft/network/Packet;)V"}, at = {@At("HEAD")})
/*    */   private void send(Packet<?> packet, CallbackInfo ci) {}
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\injection\mixins\MixinNetworkManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */