package xyz.apfelmus.cheeto.injection.mixins;

import net.minecraft.client.renderer.entity.RenderManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({RenderManager.class})
public interface RenderManagerAccessor {
  @Accessor
  double getRenderPosX();
  
  @Accessor
  double getRenderPosY();
  
  @Accessor
  double getRenderPosZ();
}


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\injection\mixins\RenderManagerAccessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */