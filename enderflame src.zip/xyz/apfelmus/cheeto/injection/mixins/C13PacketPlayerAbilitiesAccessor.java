package xyz.apfelmus.cheeto.injection.mixins;

import net.minecraft.network.play.client.C13PacketPlayerAbilities;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({C13PacketPlayerAbilities.class})
public interface C13PacketPlayerAbilitiesAccessor {
  @Accessor
  float getFlySpeed();
}


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\injection\mixins\C13PacketPlayerAbilitiesAccessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */