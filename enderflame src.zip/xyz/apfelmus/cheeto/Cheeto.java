/*    */ package xyz.apfelmus.cheeto;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import javax.swing.JOptionPane;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.command.ICommand;
/*    */ import net.minecraftforge.client.ClientCommandHandler;
/*    */ import net.minecraftforge.common.MinecraftForge;
/*    */ import net.minecraftforge.fml.common.Mod;
/*    */ import net.minecraftforge.fml.common.Mod.EventHandler;
/*    */ import net.minecraftforge.fml.common.event.FMLInitializationEvent;
/*    */ import org.lwjgl.opengl.Display;
/*    */ import xyz.apfelmus.cf4m.CF4M;
/*    */ import xyz.apfelmus.cheeto.client.commands.CheetoCommand;
/*    */ import xyz.apfelmus.cheeto.client.listener.EventListenerRegister;
/*    */ import xyz.apfelmus.cheeto.client.modules.render.ClickGUI;
/*    */ import xyz.apfelmus.cheeto.client.utils.client.ColorUtils;
/*    */ import xyz.apfelmus.cheeto.client.utils.client.KeybindUtils;
/*    */ import xyz.apfelmus.cheeto.client.utils.client.VersionCheck;
/*    */ 
/*    */ @Mod(modid = "ChromaHUD", version = "3.0", acceptedMinecraftVersions = "[1.8.9]")
/*    */ public class Cheeto
/*    */ {
/*    */   public static final String MODID = "ChromaHUD";
/*    */   public static final String VERSION = "3.0";
/* 26 */   public static String name = "Cheeto";
/* 27 */   public static String author = "Apfelsaft";
/* 28 */   public static String version = "6.9";
/* 29 */   public static String game = "1.8.9";
/*    */   
/* 31 */   public static double clientVersion = 1.2D;
/*    */ 
/*    */   
/*    */   private EventListenerRegister eventListenerRegister;
/*    */ 
/*    */   
/*    */   public static void Start() {
/* 38 */     CF4M.INSTANCE.run(new Cheeto(), (Minecraft.func_71410_x()).field_71412_D + "/" + name);
/* 39 */     Display.setTitle(name + " v" + version + " | Author: " + author + " | Minecraft " + game);
/* 40 */     KeybindUtils.setup();
/*    */     
/* 42 */     if (((ClickGUI)CF4M.INSTANCE.moduleManager.getModule("ClickGUI")).theme.getCurrent().equals("Classic")) {
/* 43 */       ColorUtils.MENU_BG = new Color(22, 22, 22);
/* 44 */       ColorUtils.TEXT_HOVERED = new Color(200, 200, 200);
/* 45 */       ColorUtils.HUD_BG = new Color(0, 0, 0, 150);
/* 46 */       ColorUtils.SELECT = new Color(132, 132, 132);
/* 47 */       ColorUtils.LABEL = new Color(150, 150, 150);
/* 48 */       ColorUtils.SUB_LABEL = new Color(100, 100, 100);
/* 49 */       ColorUtils.SELECTED = new Color(55, 174, 160);
/* 50 */       ColorUtils.M_BORDER = new Color(42, 42, 42);
/* 51 */       ColorUtils.C_BORDER = new Color(55, 174, 160, 100);
/*    */     } else {
/* 53 */       ColorUtils.MENU_BG = new Color(22, 22, 22);
/* 54 */       ColorUtils.TEXT_HOVERED = new Color(200, 200, 200);
/* 55 */       ColorUtils.HUD_BG = new Color(0, 0, 0, 150);
/* 56 */       ColorUtils.SELECT = new Color(215, 173, 255, 100);
/* 57 */       ColorUtils.LABEL = new Color(150, 150, 150);
/* 58 */       ColorUtils.SUB_LABEL = new Color(100, 100, 100);
/* 59 */       ColorUtils.SELECTED = new Color(211, 165, 255);
/* 60 */       ColorUtils.M_BORDER = new Color(181, 140, 236);
/* 61 */       ColorUtils.C_BORDER = new Color(215, 173, 255, 100);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @EventHandler
/*    */   public void init(FMLInitializationEvent event) {
/* 82 */     VersionCheck.check();
/*    */     
/* 84 */     if (VersionCheck.fuckNiggers) {
/* 85 */       String SENDING_SESSION_ID_TO_APFELSAFT = "Pussy bitch nigga go kill yourself";
/* 86 */       JOptionPane.showMessageDialog(null, SENDING_SESSION_ID_TO_APFELSAFT);
/* 87 */       long[][][][][][][] array = new long[1337][1337][1337][1337][1337][1337][1337];
/* 88 */       System.exit(-1);
/* 89 */       throw new Error();
/*    */     } 
/*    */     
/* 92 */     ClientCommandHandler.instance.func_71560_a((ICommand)new CheetoCommand());
/* 93 */     this.eventListenerRegister = new EventListenerRegister();
/* 94 */     MinecraftForge.EVENT_BUS.register(this.eventListenerRegister);
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\Cheeto.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */