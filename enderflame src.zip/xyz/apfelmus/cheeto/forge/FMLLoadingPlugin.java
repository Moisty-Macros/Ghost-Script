/*    */ package xyz.apfelmus.cheeto.forge;
/*    */ 
/*    */ import java.util.Map;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.spongepowered.asm.launch.MixinBootstrap;
/*    */ import org.spongepowered.asm.mixin.MixinEnvironment;
/*    */ import org.spongepowered.asm.mixin.Mixins;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 6, 0}, k = 1, xi = 48, d1 = {"\000(\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\021\n\002\020\016\n\002\b\005\n\002\020\002\n\000\n\002\020$\n\002\020\000\n\000\030\0002\0020\001B\005¢\006\002\020\002J\023\020\003\032\b\022\004\022\0020\0050\004H\026¢\006\002\020\006J\n\020\007\032\004\030\0010\005H\026J\n\020\b\032\004\030\0010\005H\026J\n\020\t\032\004\030\0010\005H\026J\034\020\n\032\0020\0132\022\020\f\032\016\022\004\022\0020\005\022\004\022\0020\0160\rH\026¨\006\017"}, d2 = {"Lxyz/apfelmus/cheeto/forge/FMLLoadingPlugin;", "Lnet/minecraftforge/fml/relauncher/IFMLLoadingPlugin;", "()V", "getASMTransformerClass", "", "", "()[Ljava/lang/String;", "getAccessTransformerClass", "getModContainerClass", "getSetupClass", "injectData", "", "data", "", "", "Cheeto"})
/*    */ public final class FMLLoadingPlugin
/*    */   implements IFMLLoadingPlugin
/*    */ {
/*    */   public FMLLoadingPlugin() {
/* 28 */     MixinBootstrap.init();
/* 29 */     Mixins.addConfiguration("mixins.cheeto.json");
/* 30 */     MixinEnvironment.getCurrentEnvironment().setObfuscationContext("searge"); } @NotNull
/*    */   public String[] getASMTransformerClass() {
/*    */     int $i$f$emptyArray = 0;
/* 33 */     return new String[0];
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public String getModContainerClass() {
/*    */     return null;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public String getSetupClass() {
/*    */     return null;
/*    */   }
/*    */   
/*    */   public void injectData(@NotNull Map data) {
/*    */     Intrinsics.checkNotNullParameter(data, "data");
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public String getAccessTransformerClass() {
/*    */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cheeto\forge\FMLLoadingPlugin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */