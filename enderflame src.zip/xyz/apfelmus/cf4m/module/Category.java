/*   */ package xyz.apfelmus.cf4m.module;
/*   */ 
/*   */ public enum Category {
/* 4 */   COMBAT, RENDER, MOVEMENT, PLAYER, WORLD, MISC, NONE;
/*   */ }


/* Location:              C:\Users\James\OneDrive\Desktop\ChromaHUD-3.0.jar!\xyz\apfelmus\cf4m\module\Category.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */